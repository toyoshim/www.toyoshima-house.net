#ifndef _STDLIB_H
#define _STDLIB_H
#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>

typedef unsigned short wchar_t;
typedef wchar_t        wint_t;
typedef wchar_t        wctype_t;

#ifndef _TIME_T_DEFINED
typedef unsigned long  time_t;
#define _TIME_T_DEFINED
#endif

void free(void *);
void *malloc(size_t);
size_t _msize(void *);
void *realloc(void *, size_t);

void *_alloca(size_t);

void exit(int code);
void _exit(int code);
void _cexit(void);
void _c_exit(void);

#ifdef __cplusplus
}
#endif
#endif
