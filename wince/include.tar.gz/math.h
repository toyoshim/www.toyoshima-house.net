#ifndef _MATH_H
#define _MATH_H
#ifdef __cplusplus
extern "C" {
#endif

struct _exception {
  int type;
  char *name;
  double arg1;
  double arg2;
  double retval;
};

#define exception _exception

struct _complex {
  double x,y;
};

#define complex _complex

extern double _HUGE;
#define HUGE_VAL _HUGE

int abs(int);
long labs(long);
double acos(double);
double asin(double);
double atan(double);
double atan2(double, double);
double cos(double);
double cosh(double);
double exp(double);
double fabs(double);
double fmod(double, double);
double log(double);
double log10(double);
double pow(double, double);
double sin(double);
double sinh(double);
double sqrt(double);
double tan(double);
double tanh(double);
double _cabs(struct _complex);
double ceil(double);
double floor(double);
double frexp(double, int *);
double _hypot(double, double);
double _j0(double);
double _j1(double);
double _jn(int, double);
double ldexp(double, int);
int _matherr(struct _exception *);
double modf(double, double *);
double _y0(double);
double _y1(double);
double _yn(int, double);

#define acosl(x)    ((long double)acos((double)(x)))
#define asinl(x)    ((long double)asin((double)(x)))
#define atanl(x)    ((long double)atan((double)(x)))
#define atan2l(x,y) ((long double)atan2((double)(x), (double)(y)))
#define ceill(x)    ((long double)ceil((double)(x)))
#define cosl(x)     ((long double)cos((double)(x)))
#define coshl(x)    ((long double)cosh((double)(x)))
#define expl(x)     ((long double)exp((double)(x)))
#define fabsl(x)    ((long double)fabs((double)(x)))
#define floorl(x)   ((long double)floor((double)(x)))
#define fmodl(x,y)  ((long double)fmod((double)(x), (double)(y)))
#define frexpl(x,y) ((long double)frexp((double)(x), (y)))
#define hypotl(x,y) ((long double)hypot((double)(x), (double)(y)))
#define ldexpl(x,y) ((long double)ldexp((double)(x), (y)))
#define logl(x)     ((long double)log((double)(x)))
#define log10l(x)   ((long double)log10((double)(x)))
#define _matherrl   _matherr
#define modfl(x,y)  ((long double)modf((double)(x), (double *)(y)))
#define powl(x,y)   ((long double)pow((double)(x), (double)(y)))
#define sinl(x)     ((long double)sin((double)(x)))
#define sinhl(x)    ((long double)sinh((double)(x)))
#define sqrtl(x)    ((long double)sqrt((double)(x)))
#define tanl(x)     ((long double)tan((double)(x)))
#define tanhl(x)    ((long double)tanh((double)(x)))

#ifdef __cplusplus
}
#endif
#endif

