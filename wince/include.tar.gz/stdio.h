#ifndef _STDIO_H
#define _STDIO_H
#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>

#define _MAX_PATH MAX_PATH

#define EOF (-1)
#define WEOF (wchar_t)(0xFFFF)

#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2

#define _O_TEXT   0x4000
#define _O_BINARY 0x8000

#ifndef _FILE_DEFINED
typedef void FILE;
#define _FILE_DEFINED
#endif

typedef long fpos_t;

#define stdin  _getstdfilex(0)
#define stdout _getstdfilex(1)
#define stderr _getstdfilex(2)

int sscanf(const char *, const char *, ...);
int sprintf(char *, const char *, ...);
int vsprintf(char *, const char *, va_list);
int _snprintf(char *, size_t, const char *, ...);
int _vsnprintf(char *, size_t, const char *, va_list);

int swscanf(const wchar_t *, const wchar_t *, ...);
int swprintf(wchar_t *, const wchar_t *, ...);
int vswprintf(wchar_t *, const wchar_t *, va_list);
int _snwprintf(wchar_t *, size_t, const wchar_t *, ...);
int _vsnwprintf(wchar_t *, size_t, const wchar_t *, va_list);

int scanf(const char *, ...);
int printf(const char *, ...);
int vprintf(const char *, va_list);
int getchar(void);
char *gets(char *);
int putchar(int);
int puts(const char *);

int fgetc(FILE *);
char *fgets(char *, int, FILE *);
int fputc(int, FILE *);
int fputs(const char *, FILE *);
int ungetc(int, FILE *);

FILE *fopen(const char *, const char *);
int fscanf(FILE *, const char *, ...);
int fprintf(FILE *, const char *, ...);
int vfprintf(FILE *, const char *, va_list);

#define getc(_stream)     fgetc(_stream)
#define putc(_i, _stream) fputc(_i, _stream)

FILE *_getstdfilex(int);
int fclose(FILE *);
int _fcloseall(void);
size_t fread(void *, size_t, size_t, FILE *);
size_t fwrite(const void *, size_t, size_t, FILE *);
int fflush(FILE *);
int _flushall(void);
int feof(FILE *);
int ferror(FILE *);
voidclearerr(FILE *);
int fgetpos(FILE *, fpos_t *);
int fsetpos(FILE *, const fpos_t *);
int fseek(FILE *, long, int);
longftell(FILE *);
void *_fileno(FILE *);
int _setmode(FILE *, int mode);
FILE *_wfdopen(void*, const wchar_t*);
FILE *_wfreopen(const wchar_t *path, const wchar_t *mode, FILE *stream);

#define fcloseall _fcloseall
#define fileno    _fileno
#define flushall  _flushall

int wscanf(const wchar_t *, ...);
int wprintf(const wchar_t *, ...);
int vwprintf(const wchar_t *, va_list);
wchar_t getwchar(void);
wchar_t putwchar(wchar_t);
wchar_t *_getws(wchar_t *);
int _putws(const wchar_t *);

wchar_t fgetwc(FILE *);
wchar_t fputwc(wchar_t, FILE *);
wchar_t ungetwc(wchar_t, FILE *);
wchar_t *fgetws(wchar_t *, int, FILE *);
int fputws(const wchar_t *, FILE *);

#define getwc(_stm)    fgetwc(_stm)
#define putwc(_c,_stm) fputwc(_c,_stm)

FILE *_wfopen(const wchar_t *, const wchar_t *);
int fwscanf(FILE *, const wchar_t *, ...);
int fwprintf(FILE *, const wchar_t *, ...);
int vfwprintf(FILE *, const wchar_t *, va_list);

#ifdef __cplusplus
}
#endif
#endif

