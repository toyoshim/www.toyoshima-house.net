#ifndef _STRING_H
#define _STRING_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _WCHAR_T_DEFINED
#define _WCHAR_T_DEFINED
#ifndef _WCHAR_T_
#define _WCHAR_T_
#undef __need_wchar_t
typedef unsigned short wchar_t;
#endif
#endif

#ifndef _SIZE_T_DEFINED
#define _SIZE_T_DEFINED
#ifndef _SIZE_T_
#define _SIZE_T_
#undef __need_size_t
typedef unsigned long size_t;
#endif
#endif

wchar_t *wcscat(wchar_t *, const wchar_t *);
wchar_t *wcschr(const wchar_t *, wchar_t);
int      wcscmp(const wchar_t *, const wchar_t *);
wchar_t *wcscpy(wchar_t *, const wchar_t *);
size_t   wcscspn(const wchar_t *, const wchar_t *);
size_t   wcslen(const wchar_t *);

size_t   mbstowcs(wchar_t *, const char *, size_t);
size_t   wcstombs(char *, const wchar_t *, size_t);

wchar_t *wcsncat(wchar_t *, const wchar_t *, size_t);
int      wcsncmp(const wchar_t *, const wchar_t *, size_t);
wchar_t *wcsncpy(wchar_t *, const wchar_t *, size_t);
wchar_t *wcspbrk(const wchar_t *, const wchar_t *);
wchar_t *wcsrchr(const wchar_t *, wchar_t);
size_t   wcsspn(const wchar_t *, const wchar_t *);
wchar_t *wcsstr(const wchar_t *, const wchar_t *);
wchar_t *wcstok(wchar_t *, const wchar_t *);
wchar_t *_wcsdup(const wchar_t *);
int      _wcsicmp(const wchar_t *, const wchar_t *);
int      _wcsnicmp(const wchar_t *, const wchar_t *, size_t);
wchar_t *_wcsnset(wchar_t *, wchar_t, size_t);
wchar_t *_wcsrev(wchar_t *);
wchar_t *_wcsset(wchar_t *, wchar_t);
wchar_t *_wcslwr(wchar_t *);
wchar_t *_wcsupr(wchar_t *);

#define wcsdup    _wcsdup
#define wcsicmp   _wcsicmp
#define wcsnicmp  _wcsnicmp
#define wcsnset   _wcsnset
#define wcsrev    _wcsrev
#define wcsset    _wcsset
#define wcslwr    _wcslwr
#define wcsupr    _wcsupr

size_t strlen(const char *);
int    strcmp(const char *, const char *);
char  *strcat(char *, const char *);
char  *strcpy(char *, const char *);

char  *strchr(const char *, int);
size_t strcspn(const char *, const char *);
char  *strncat(char *, const char *, size_t);
int    strncmp(const char *, const char *, size_t);
char  *strncpy(char *, const char *, size_t);
char  *strstr(const char *, const char *);
char  *strtok(char *, const char *);

#ifdef __cplusplus
}
#endif
#endif

