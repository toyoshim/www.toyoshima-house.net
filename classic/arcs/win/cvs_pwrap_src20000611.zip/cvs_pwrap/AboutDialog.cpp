/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: AboutDialog.cpp,v 1.1 2000/06/10 18:20:42 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [AboutDialog.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "AboutDialog.h"

AboutDialog::AboutDialog
(void):
parentWnd(NULL),
message(NULL)
{
	DOUT("AboutDialog\n");
}

AboutDialog::~AboutDialog
(void)
{
	DOUT("~AboutDialog\n");
}

BOOL
AboutDialog::Open
(HINSTANCE hInstance, LPCTSTR lpTemplate, HWND parentWnd, UINT message)
{
	this->parentWnd = parentWnd;
	this->message = message;
	if (!DialogWindow::Open(hInstance, lpTemplate)) {
		PostMessage(parentWnd, message, 0, 0);
		return false;
	}
	return true;
}

BOOL
AboutDialog::InitDialog
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("InitDialog\n");
	return true;
}

BOOL
AboutDialog::LButtonDown
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("LButtonDown\n");
	PostMessage(parentWnd, message, 0, 0);	// �j���v��
	return true;
}

BOOL
AboutDialog::RButtonDown
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("RButtonDown\n");
	PostMessage(parentWnd, message, 0, 0);	// �j���v��
	return true;
}
