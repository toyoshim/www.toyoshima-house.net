/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: SettingDialog.cpp,v 1.2 2000/06/10 21:49:18 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [SettingDialog.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "SettingDialog.h"
#include "resource.h"
#include "default.h"
#include "regname.h"

SettingDialog::SettingDialog
(void)
{
	DOUT("SettingDialog\n");
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	filename[0] = 0;
}

SettingDialog::~SettingDialog
(void)
{
	SetData(WINTCPD_REG_OFN, (const char *)&ofn, sizeof(OPENFILENAME));
	Registry::Close();
	DOUT("~SettingDialog\n");
}

BOOL
SettingDialog::Open
(HINSTANCE hInstance, LPCTSTR lpTemplate, HWND parentWnd, UINT message)
{
	this->parentWnd = parentWnd;
	this->message = message;
	if (!Registry::Open(WINTCPD_REG_ROOT)) {
		DOUT("Registry::Open failed\n");
		PostMessage(parentWnd, message, 0, 0);
		return false;
	}
	if (!DialogWindow::Open(hInstance, lpTemplate)) {
		DOUT("failed\n");
		PostMessage(parentWnd, message, 0, 0);
		return false;
	}
	return true;
}

BOOL
SettingDialog::InitDialog
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("InitDialog\n");

	// �t�@�C���I�[�v���_�C�A���O
	GetData(WINTCPD_REG_OFN, (const char *)&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hDlg;
	ofn.lpstrFilter = "CVS Pserver (*,exe)\0*.exe\0���ׂẴt�@�C�� (*.*)\0*.*\0";
	ofn.lpstrFile = filename;
	ofn.nMaxFile = _MAX_PATH;

	// �|�[�g
	int iparam;
	GetInt(WINTCPD_REG_PORT, iparam, WINTCPD_DEFAULT_PORT);
	SetDlgItemInt(hDlg, IDC_EDIT1, iparam, false);

	// CVS
	char sparam[4096];
	int paramsize = 4096;
	GetStr(WINTCPD_REG_EXE, sparam, paramsize, WINTCPD_DEFAULT_EXE);
	SetDlgItemText(hDlg, IDC_EDIT2, sparam);

	// �R�}���h���C��
	paramsize = 4096;
	GetStr(WINTCPD_REG_OPT, sparam, paramsize, WINTCPD_DEFAULT_OPT);
	SetDlgItemText(hDlg, IDC_EDIT3, sparam);
	return true;
}

BOOL
SettingDialog::Command
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM result = 0;
	switch (LOWORD(wParam)) {
	case IDC_BUTTON1:	// �Q��
		if (GetOpenFileName(&ofn)) {
			SetDlgItemText(hDlg, IDC_EDIT2, (LPCTSTR)filename);
		}
		break;
	case IDC_BUTTON3:{	// OK
		if (IDNO == MessageBox(hDlg, 
				"�ݒ��ύX����ہA���ݐڑ����̃Z�b�V�������������ꍇ�ɂ́A���̃Z�b�V�����͋����ؒf����܂�����낵���ł����H",
				"�m�F",
				MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2)) break;
		// �|�[�g
		BOOL translated;
		int param = GetDlgItemInt(hDlg, IDC_EDIT1, &translated, false);
		SetInt(WINTCPD_REG_PORT, param);

		// CVS
		char sparam[4096];
		int paramsize = 4096;
		GetDlgItemText(hDlg, IDC_EDIT2, (LPTSTR)sparam, paramsize);
		SetStr(WINTCPD_REG_EXE, sparam);

		// �R�}���h���C��
		GetDlgItemText(hDlg, IDC_EDIT3, (LPTSTR)sparam, paramsize);
		SetStr(WINTCPD_REG_OPT, sparam);

		result = 1;
		}
	case IDC_BUTTON2:	// �L�����Z��
		PostMessage(parentWnd, message, result, 0);	// �j���v��
		break;
	default:
		return false;
	}
	return true;
}
