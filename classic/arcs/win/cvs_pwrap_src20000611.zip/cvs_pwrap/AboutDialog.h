/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: AboutDialog.h,v 1.1 2000/06/10 18:20:42 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [AboutDialog.h]
 *   DialogWindow���p�����č쐬����About�_�C�A���O�B�I�����ɂ�parentWnd��message��������B
 * -------------------------------------------------------------------------------------------- */

#if !defined(__AboutDialog_h__)
#	define	__AboutDialog_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__DialogWindow_h__)
#		include "DialogWindow.h"
#	endif	// !defined(__DialogWindow_h__)

class AboutDialog: public DialogWindow{
	HWND parentWnd;
	UINT message;
public:
	AboutDialog(void);
	~AboutDialog(void);
	BOOL Open(HINSTANCE hInstance, LPCTSTR lpTemplate, HWND parentWnd, UINT message);
protected:
	BOOL InitDialog(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam);	// DialogWindow
	BOOL LButtonDown(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam);	// DialogWindow
	BOOL RButtonDown(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam);	// DialogWindow
};

#	if !defined(__AboutDialog__)
#		define	__AboutDialog__
#	endif	// !defined(__AboutDialog__)

#endif	// !defined(__AboutDialog_h__)
