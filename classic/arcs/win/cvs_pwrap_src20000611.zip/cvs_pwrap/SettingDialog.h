/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: SettingDialog.h,v 1.2 2000/06/10 21:49:18 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [SettingDialog.h]
 *   DialogWindow���p�����č쐬�����ݒ�_�C�A���O�B�I�����ɂ�parentWnd��message��������B
 * -------------------------------------------------------------------------------------------- */

#if !defined(__SettingDialog_h__)
#	define	__SettingDialog_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__DialogWindow_h__)
#		include "DialogWindow.h"
#	endif	// !defined(__DialogWindow_h__)

#	if !defined(__Registry_h__)
#		include "Registry.h"
#	endif	// !defined(__Registry_h__)

class SettingDialog: public DialogWindow, private Registry{
private:
	HWND parentWnd;
	UINT message;
	OPENFILENAME ofn;
	char filename[_MAX_PATH];
public:
	SettingDialog(void);
	~SettingDialog(void);
	BOOL Open(HINSTANCE hInstance, LPCTSTR lpTemplate, HWND parentWnd, UINT message);
protected:
	BOOL InitDialog(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam);	// DialogWindow
	BOOL Command(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam);	// DialogWindow
};

#	if !defined(__SettingDialog__)
#		define	__SettingDialog__
#	endif	// !defined(__SettingDialog__)

#endif	// !defined(__SettingDialog_h__)
