/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 *  $Id: HashedWindowProcDivider.cpp,v 1.4 2000/06/10 18:20:46 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [HashedWindowProcDivider.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "HashedWindowProcDivider.h"

HashedWindowProcDivider::LPENTRY
HashedWindowProcDivider::table[256];

bool
HashedWindowProcDivider::initialize = false;

bool
HashedWindowProcDivider::WndEntryAdd
(HWND hWnd, HashedWindowProcDivider *instance)
{
	DOUT("WndEntryAdd: %08x\n", hWnd);
	if (!initialize) Initialize();
	if (NULL != Search(hWnd)) return false;
	unsigned char hash = (int)hWnd & 0xff;
	LPENTRY entry = table[hash];
	if (NULL == entry) {
		table[hash] = new ENTRY;
		if (NULL == table[hash]) return false;
		entry = table[hash];
		entry->before = NULL;
	} else {
		while (NULL != entry->next) entry = entry->next;
		entry->next = new ENTRY;
		if (NULL == entry->next) return false;
		entry->next->before = entry;
		entry = entry->next;
	}
	entry->hWnd = hWnd;
	entry->instance = instance;
	entry->next = NULL;
	return true;
}

bool
HashedWindowProcDivider::WndEntryDel
(HWND hWnd)
{
	DOUT("WndEntryDel: %08x\n", hWnd);
	if (!initialize) Initialize();
	LPENTRY entry = Search(hWnd);
	if (NULL == entry) return false;
	if (NULL == entry->before) {
		LPENTRY next = entry->next;
		delete entry;
		table[(int)hWnd & 0xff] = next;
	} else {
		LPENTRY next = entry->next;
		LPENTRY before = entry->before;
		delete entry;
		before->next = next;
		if (NULL != next) next->before = before;
	}
	return true;
}

LRESULT
HashedWindowProcDivider::WindowProcWrap
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	LPENTRY entry = Search(hWnd);
	if (NULL == entry) return 0;
	return entry->instance->WindowProc(hWnd, nMsg, wParam, lParam);
}

LRESULT
HashedWindowProcDivider::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

BOOL
HashedWindowProcDivider::DialogProcWrap
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	LPENTRY entry = Search(hDlg);
	if (NULL == entry) return 0;
	return entry->instance->DialogProc(hDlg, nMsg, wParam, lParam);
}

BOOL
HashedWindowProcDivider::DialogProc
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

void
HashedWindowProcDivider::Initialize
(void)
{
	for (int i = 0; i < 256; i++) {
		table[i] = NULL;
	}
	initialize = true;
}

HashedWindowProcDivider::LPENTRY
HashedWindowProcDivider::Search
(HWND hWnd)
{
	for (LPENTRY entry = table[(int)hWnd & 0xff]; NULL != entry; entry = entry->next) if (entry->hWnd == hWnd) return entry;
	return NULL;
}
