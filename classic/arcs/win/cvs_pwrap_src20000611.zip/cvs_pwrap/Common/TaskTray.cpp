/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: TaskTray.cpp,v 1.2 2000/06/10 13:23:27 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [TaskTray.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "TaskTray.h"

TaskTray::TaskTray
(void):
messageWnd(NULL),
state(false)
{
	ZeroMemory(&nid, sizeof(NOTIFYICONDATA));
}

TaskTray::~TaskTray
(void)
{
	if (state) AddIconTaskTray(false);
}

BOOL
TaskTray::AddIconTaskTray
(BOOL add, HICON hIcon, TCHAR szTips[64])
{
	DOUT("TaskTray [%s]\n", add? "ADD": "DELETE");
	if ((NULL == messageWnd) && !OpenWindow(messageWnd, NULL)) return false;
	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = messageWnd;
	nid.uID = 0;
	nid.uCallbackMessage = MSG_TASKTRAY_NOTIFY;
	nid.hIcon = hIcon;
	if (NULL != szTips) memcpy(nid.szTip, szTips, 64);
	nid.uFlags = NIF_ICON | NIF_MESSAGE | ((NULL != szTips)? NIF_TIP: 0);
	BOOL result = Shell_NotifyIcon(add? NIM_ADD: NIM_DELETE, &nid);
	if (result) {
		state = add;
		if (state) SetTimer(messageWnd, TIMER_TASKBAR_CHECK, 10000, NULL);
		else KillTimer(messageWnd, TIMER_TASKBAR_CHECK);
	}
	return result;
}

LRESULT
TaskTray::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
//	DOUT("TaskTray::WindowProc($%08x, $%08x, $%08x, $%08x)\n", hWnd, nMsg, wParam, lParam);
	if (hWnd != messageWnd) return 0;
	switch (nMsg) {
	case WM_TIMER:	// 10�b�Ԋu�̃|�[�����O
		DOUT("check taskbar\n");
		if (!state) break;
		if (Shell_NotifyIcon(NIM_MODIFY, &nid)) break;
		Shell_NotifyIcon(NIM_ADD, &nid);	// �^�X�N�o�[�����������̕��A����
		DOUT("reentry\n");
		break;
	case MSG_TASKTRAY_NOTIFY:
		if (lParam == WM_LBUTTONDOWN) return TaskTrayLButtonDown(hWnd, nMsg, wParam, lParam);
		else if (lParam == WM_RBUTTONDOWN) return TaskTrayRButtonDown(hWnd, nMsg, wParam, lParam);
		break;
	default:
		return MessageWindow::WindowProc(hWnd, nMsg, wParam, lParam);
	}
	return 0;
}

LRESULT
TaskTray::TaskTrayLButtonDown
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

LRESULT
TaskTray::TaskTrayRButtonDown
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

const HWND
TaskTray::GetMessageWnd
(void) const
{
	return messageWnd;
}
