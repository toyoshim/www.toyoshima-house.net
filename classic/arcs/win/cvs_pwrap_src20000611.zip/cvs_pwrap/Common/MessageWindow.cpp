/* --------------------------------------------------------------------------------------------
 *  Pop'n Pop - hotmail to pop3 gateway -
 *  �E�F�u�E�T�C���A�b�v (C) ACENET, Inc.
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 1999,2000 �Ƃ悵��
 *  $Id: MessageWindow.cpp,v 1.3 2000/06/08 23:14:38 uid500 Exp $
 * --------------------------------------------------------------------------------------------
 *  [MessageWindow.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "MessageWindow.h"

int
MessageWindow::nInstance = 0;

BOOL
MessageWindow::fInitialize = false;

MessageWindow *
MessageWindow::pInstance = NULL;

HWND *
MessageWindow::pHWnd = NULL;

MessageWindow::MessageWindow
(void):
lastError(ERROR_SUCCESS)
{
	nInstance++;
	if (!fInitialize) {
		// �ŏ��Ȃ̂ŏ�����
		HINSTANCE hInstance;
		_verify(hInstance, GetModuleHandle(NULL), _throw(ERROR_GET_INSTANCE));
		WNDCLASSEX wcex;
		ZeroMemory(&wcex, sizeof(WNDCLASSEX));
		wcex.cbSize = sizeof(WNDCLASSEX);
		wcex.lpfnWndProc = (WNDPROC)WindowProcWrap;
		wcex.hInstance = hInstance;
		wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
		wcex.lpszClassName = MESSAGEWINDOW_CLASSNAME;
		if (0 == RegisterClassEx(&wcex)) _throw(ERROR_REGISTER_CLASS);
		fInitialize = true;
	}
}

MessageWindow::~MessageWindow
(void)
{
	BOOL result = CloseWindow();
	DOUT("CloseMessageWindow -> %s\n", result? "OK": "FAILED");
	nInstance--;
	if ((0 == nInstance) && fInitialize) {
		// �Ō�Ȃ̂ŏI������
		HINSTANCE hInstance;
		_verify(hInstance, GetModuleHandle(NULL), _throw(ERROR_GET_INSTANCE));
		if (!UnregisterClass(MESSAGEWINDOW_CLASSNAME, hInstance)) _throw(ERROR_UNREGISTER_CLASS);
		fInitialize = false;
	}
}

BOOL
MessageWindow::OpenWindow
(HWND &hWnd, HWND parentHWnd, LPCSTR windowName)
{
	if (NULL != pInstance) _return(ERROR_INSTANCE_BUSY);
	HINSTANCE hInstance;
	_verify(hInstance, GetModuleHandle(NULL), _return(ERROR_GET_INSTANCE));
	pInstance = this;
	pHWnd = &hWnd;
	this->hWnd = CreateWindowEx(0, MESSAGEWINDOW_CLASSNAME, (NULL == windowName)? MESSAGEWINDOW_CLASSNAME: windowName, WS_POPUP,
		0, 0, 1, 1, parentHWnd, NULL, hInstance, NULL);
	if (NULL == hWnd) {
		pInstance = NULL;
		pHWnd = NULL;
		_return(ERROR_CREATEWINDOW);
	}
	return true;
}

BOOL
MessageWindow::CloseWindow
(void)
{
	if (NULL == hWnd) return true;
	HWND tmp = hWnd;
	hWnd = NULL;
	BOOL result = DestroyWindow(tmp);
	if (!result) {
		DERR();
		DOUT("WindowHandle = $%08X\n", tmp);
	}
	return result;
}

int
MessageWindow::GetLastError
(void)
{
	return lastError;
}

LRESULT CALLBACK
MessageWindow::WindowProcWrap
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	MessageWindow *hw = (MessageWindow *)GetWindowLong(hWnd, GWL_USERDATA);
	if (NULL == hw) {
		hw = pInstance;
		pInstance = NULL;
		if (NULL != pHWnd) {
			*pHWnd = hWnd;
			pHWnd = NULL;
		}
		SetWindowLong(hWnd, GWL_USERDATA, (LONG)hw);
	}
	return hw->WindowProc(hWnd, nMsg, wParam, lParam);
}

LRESULT
MessageWindow::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
//	DOUT("$%08x, $%08x, $%08x, $%08x\n", hWnd, nMsg, wParam, lParam);
	if (nMsg == WM_DESTROY) {
#	if defined(_DEBUG)
		char tmp[1024];
		GetWindowText(hWnd, tmp, 1024);
		DOUT("WM_DESTROY on HWND $%08X ( %s )\n", hWnd, tmp);
#	endif	// defined(_DEBUG)
		this->hWnd = NULL;
	}
	return DefWindowProc(hWnd, nMsg, wParam, lParam);
}
