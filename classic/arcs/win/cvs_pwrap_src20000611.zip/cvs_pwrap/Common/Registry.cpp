/* --------------------------------------------------------------------------------------------
 *  EL-POINT subset version for KARIHITO
 *  (C) 1999,2000 �Ƃ悵��
 *  $Id: Registry.cpp,v 1.3 2000/06/10 21:49:22 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [Registry.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "Registry.h"

Registry::~Registry
(void)
{
	Close();
}

bool
Registry::Open
(const char *name, int type)
{
	Close();
	DOUT("Open %s, %d\n", name, type);
	HKEY parent;
	switch (type) {
	case CRTYPE_MACHINE:
		parent = HKEY_LOCAL_MACHINE;
		break;
	case CRTYPE_USER:
		parent = HKEY_CURRENT_USER;
		break;
	default:
		return false;
	}
	DWORD disposition;
	return ERROR_SUCCESS == RegCreateKeyEx(parent, name, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, &disposition);
}

void
Registry::Close
(void)
{
	if (NULL == hKey) return;
	RegCloseKey(hKey);
	hKey = NULL;
}

bool
Registry::SetInt
(const char *name, int param)
{
	if ((NULL == hKey) || (NULL == name)) return false;
	DWORD data = param;
	return ERROR_SUCCESS == RegSetValueEx(hKey, name, 0, REG_DWORD, (CONST BYTE *)&data, sizeof(DWORD));
}

bool
Registry::GetInt
(const char *name, int &param, int default_value)
{
	DOUT("GetInt: %s\n", name);
	if ((NULL == hKey) || (NULL == name)) return false;
	DWORD type;
	DWORD data;
	DWORD size = sizeof(DWORD);
	bool result =  (ERROR_SUCCESS == RegQueryValueEx(hKey, name, NULL, &type, (LPBYTE)&data, (LPDWORD)&size));
	if (result && (type != REG_DWORD)) result = false;
	if (result) param = data;
	else param = default_value;
	return result;
}

bool
Registry::SetStr
(const char *name, const char *param)
{
	if ((NULL == hKey) || (NULL == name) || (NULL == param)) return false;
	return ERROR_SUCCESS == RegSetValueEx(hKey, name, 0, REG_SZ, (CONST BYTE *)param, strlen(param) + 1);
}

bool
Registry::GetStr
(const char *name, char *param, int &paramsize, const char *default_value)
{
	DOUT("GetStr: %s\n", name);
	if ((NULL == hKey) || (NULL == name) || (NULL == param)) return false;
	DWORD type;
	DWORD size = paramsize;
	LONG result = RegQueryValueEx(hKey, name, NULL, &type, (LPBYTE)param, (LPDWORD)&size);
	if (!result && (type != REG_SZ)) {
		paramsize = 0;
		return false;
	}
	if (ERROR_MORE_DATA == result) {
		paramsize = size;
		return false;	// �o�b�t�@������������
	} else if (ERROR_SUCCESS != result) {
		if (NULL == default_value) return false;	// ���݂��Ȃ���Ύ��s
		// �f�t�H���g�̒l���R�s�[
		paramsize = snprintf(param, paramsize, "%s", default_value);
		return true;
	}
	paramsize = size;
	return true;
}

bool
Registry::SetData
(const char *name, const char *param, int paramsize)
{
	if ((NULL == hKey) || (NULL == name) || (NULL == param)) return false;
	return ERROR_SUCCESS == RegSetValueEx(hKey, name, 0, REG_BINARY, (CONST BYTE *)param, paramsize);
}

bool
Registry::GetData
(const char *name, const char *param, int paramsize)
{
	if ((NULL == hKey) || (NULL == name) || (NULL == param)) return false;
	DWORD type;
	DWORD size = paramsize;
	bool result = ERROR_SUCCESS == RegQueryValueEx(hKey, name, NULL, &type, (LPBYTE)param, (LPDWORD)&size);
	if (!result) return false;
	if ((type != REG_BINARY) || (size != (DWORD)paramsize)) return false;
	return true;
}
