/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: DialogWindow.cpp,v 1.3 2000/06/10 21:49:22 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [DialogWindow.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "DialogWindow.h"

DialogWindow::DialogWindow
(void):
hWnd(NULL)
{
}

DialogWindow::~DialogWindow
(void)
{
	if (NULL != hWnd) EndDialog(hWnd, 0);
	WndEntryDel(hWnd);
}

BOOL
DialogWindow::Open
(HINSTANCE hInstance, LPCTSTR lpTemplate, HWND parentWnd)
{
	hWnd = CreateDialog(hInstance, lpTemplate, parentWnd, DialogProcWrap);
	if (NULL == hWnd) return false;
	if (!WndEntryAdd(hWnd, this)) return false;
	if (!InitDialog(hWnd, WM_INITDIALOG, 0, 0)) return false;
	ShowWindow(hWnd, SW_SHOW);
	return true;
}

BOOL
DialogWindow::DialogProc
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	switch(nMsg){
	case WM_INITDIALOG:
		return true;	// ���ۂɂ�WndEntryAdd�ȑO�ɃC�x���g���N���邽�߁A�n���h���ł��Ȃ�
	case WM_LBUTTONDOWN:
		return LButtonDown(hDlg, nMsg, wParam, lParam);
	case WM_RBUTTONDOWN:
		return RButtonDown(hDlg, nMsg, wParam, lParam);
	case WM_COMMAND:
		return Command(hDlg, nMsg, wParam, lParam);
	default:
		return false;
	}
	return true;
}

BOOL
DialogWindow::InitDialog
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("InitDialog\n");
	return false;
}

BOOL
DialogWindow::LButtonDown
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("LButtonDown\n");
	return false;
}

BOOL
DialogWindow::RButtonDown
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("RButtonDown\n");
	return false;
}

BOOL
DialogWindow::Command
(HWND hDlg, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("Command\n");
	return false;
}
