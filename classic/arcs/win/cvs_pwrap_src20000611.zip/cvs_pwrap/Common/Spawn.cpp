/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: Spawn.cpp,v 1.2 2000/06/10 21:49:22 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [Spawn.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "Spawn.h"

Spawn::Spawn
(HWND parentWnd, UINT message):
parentWnd(parentWnd),
message(message),
hReadPipe(INVALID_HANDLE_VALUE),
hWritePipe(INVALID_HANDLE_VALUE),
hChildReadPipe(INVALID_HANDLE_VALUE),
hChildWritePipe(INVALID_HANDLE_VALUE),
hProcess(INVALID_HANDLE_VALUE),
hThread(INVALID_HANDLE_VALUE),
hTermEvent(INVALID_HANDLE_VALUE),
hWaitThread(INVALID_HANDLE_VALUE),
hReadThread(INVALID_HANDLE_VALUE),
hReadEvent(INVALID_HANDLE_VALUE),
hReadNextEvent(INVALID_HANDLE_VALUE)
{
}

Spawn::~Spawn
(void)
{
	// �e�X���b�h�ւ̏I���v��
	DOUT("Set TermEvent\n");
	if (INVALID_HANDLE_VALUE != hTermEvent) SetEvent(hTermEvent);

	// �ҋ@�X���b�h�̏I��
	DOUT("Waiting WaitThread ...");
	if (INVALID_HANDLE_VALUE != hWaitThread) {
		// �Œ��R�b�܂őҋ@
		if (WAIT_OBJECT_0 != WaitForSingleObject(hWaitThread, 1000)) {
			DOUT("waiting thread forcely terminated!");
			TerminateThread(hWaitThread, 0);
			WaitForSingleObject(hWaitThread, 1000);
		}
		CloseHandle(hWaitThread);
	}
	DOUTR("OK");

	// �ǂݍ��݃X���b�h�̏I��
	DWORD writeSize;
	WriteFile(hChildWritePipe, "\0", 1, &writeSize, NULL);
	DOUT("Waiting ReadThread ...");
	if (INVALID_HANDLE_VALUE != hReadThread) {
		// �Œ��R�b�܂őҋ@
		if (WAIT_OBJECT_0 != WaitForSingleObject(hReadThread, 1000)) {
			DOUT("reading thread forcely terminated!");
			TerminateThread(hReadThread, 0);
			WaitForSingleObject(hReadThread, 1000);
		}
		CloseHandle(hReadThread);
	}
	DOUTR("OK");

	// �p�C�v�̃N���[�Y
	DOUT("Close Pipes\n");
	if (INVALID_HANDLE_VALUE != hReadPipe) CloseHandle(hReadPipe);
	if (INVALID_HANDLE_VALUE != hWritePipe) CloseHandle(hWritePipe);
	if (INVALID_HANDLE_VALUE != hChildReadPipe) CloseHandle(hChildReadPipe);
	if (INVALID_HANDLE_VALUE != hChildWritePipe) CloseHandle(hChildWritePipe);

	// �q�v���Z�X�̃n���h�������
	DOUT("Close Child\n");
	if (NULL != hProcess) {
		DOUT("hProcess: %08x\n", hProcess);
		DWORD exitCode;
		if (GetExitCodeProcess(hProcess, &exitCode)) {
			if (STILL_ACTIVE == exitCode) {
				DOUT("child process still active\n");
				DOUT("terminate proces ... ");
				TerminateProcess(hProcess, 0);
				DOUT("OK\n");
			} else {
				DOUT("child process exit with %d\n", exitCode);
			}
		} else {
			DOUT("GetExitCodeProcess failed\n");
		}
		CloseHandle(hProcess);
	}
	if (NULL != hThread) CloseHandle(hThread);

	// �C�x���g�I�u�W�F�N�g�̔j��
	DOUT("delete Event Object\n");
	if (INVALID_HANDLE_VALUE != hReadEvent) CloseHandle(hReadEvent);
	if (INVALID_HANDLE_VALUE != hReadNextEvent) CloseHandle(hReadNextEvent);
	if (INVALID_HANDLE_VALUE != hTermEvent) CloseHandle(hWaitThread);
}

void
Spawn::SetMessage
(HWND parentWnd, UINT message)
{
	this->parentWnd = parentWnd;
	this->message = message;
}

bool
Spawn::Execute(const char *app, const char *args)
{
	// �W�����o�͗p�̃p�C�v���쐬
	SECURITY_ATTRIBUTES sec;
	ZeroMemory(&sec, sizeof(SECURITY_ATTRIBUTES));
	sec.nLength = sizeof(SECURITY_ATTRIBUTES);
	sec.bInheritHandle = true;
	if (!CreatePipe(&hReadPipe, &hChildWritePipe, &sec, 0)) {
		DOUT("can not create pipe\n");
		hReadPipe = hChildWritePipe = NULL;
		return false;
	}
	if (!CreatePipe(&hChildReadPipe, &hWritePipe, &sec, 0)) {
		DOUT("can not create pipe\n");
		hWritePipe = hChildReadPipe = NULL;
		return false;
	}

	// �q�v���Z�X�̋N��
	char *cmdline;
	int cmdlinesize = strlen(app);
	if (NULL != args) cmdlinesize += strlen(args);
	cmdline = (char *)malloc(cmdlinesize + 2);
	if (NULL == cmdline) return false;
	snprintf(cmdline, cmdlinesize + 2, "%s %s\0", app, args);
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(STARTUPINFO));
	si.cb = sizeof(STARTUPINFO);
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = hChildReadPipe;
	si.hStdOutput = hChildWritePipe;
	si.hStdError = hChildWritePipe;
	PROCESS_INFORMATION pi;
	ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
	if (!CreateProcess(NULL, cmdline, &sec, &sec, true, NORMAL_PRIORITY_CLASS | DETACHED_PROCESS, NULL, NULL, &si, &pi)) {
		DERR();
		DOUT("can not create process : %s\n", cmdline);
		free(cmdline);
		return false;
	}
	free(cmdline);
	hProcess = pi.hProcess;
	hThread = pi.hThread;

	// �ҋ@�X���b�h��~�p�̃C�x���g�I�u�W�F�N�g�̍쐬
	hTermEvent = CreateEvent(&sec, true, false, NULL);
	if (INVALID_HANDLE_VALUE == hTermEvent) return false;

	// �ҋ@�p�X���b�h�̍쐬
	DWORD threadId;
	hWaitThread = CreateThread(&sec, 0, WaitThreadStart, (LPVOID)this, 0, &threadId);
	if (INVALID_HANDLE_VALUE == hWaitThread) {
		DOUT("can not create thread\n");
		return false;
	}

	// �ǂݍ��ݓ����p�C�x���g�I�u�W�F�N�g�̍쐬
	hReadEvent = CreateEvent(&sec, false, false, NULL);
	hReadNextEvent = CreateEvent(&sec, false, false, NULL);
	if ((INVALID_HANDLE_VALUE == hReadEvent) || (INVALID_HANDLE_VALUE == hReadNextEvent)) return false;

	// �ǂݍ��݊Ď��p�X���b�h�̍쐬
	hReadThread = CreateThread(&sec, 0, ReadThreadStart, (LPVOID)this, 0, &threadId);
	if (INVALID_HANDLE_VALUE == hReadThread) {
		DOUT("can not create thread\n");
		return false;
	}
	return true;
}

bool
Spawn::SpawnRead
(char *buffer, int &size)
{
	DWORD readSize;
	bool result = true;
	if (!ReadFile(hReadPipe, buffer, size, &readSize, NULL)) {
		DOUT("read failed\n");
		result = false;
	} else {
		size = readSize;
	}
	if (INVALID_HANDLE_VALUE != hReadNextEvent) SetEvent(hReadNextEvent);
	return result;
}

bool
Spawn::SpawnWrite
(const char *buffer, int &size)
{
	DWORD writeSize;
	if (!WriteFile(hWritePipe, buffer, size, &writeSize, NULL)) {
		DOUT("write failed\n");
		return false;
	}
	size = writeSize;
	return true;
}

DWORD WINAPI
Spawn::WaitThreadStart
(LPVOID obj)
{
	DOUT("START WAIT THREAD\n");
	return ((Spawn *)obj)->WaitThreadMain();
}

DWORD
Spawn::WaitThreadMain
(void)
{
	// �ҋ@�p�I�u�W�F�N�g�̗�
	HANDLE handles[3];
	handles[0] = hTermEvent;
	handles[1] = hProcess;
	handles[2] = hReadEvent;

	for (;;) {
		DWORD rc = WaitForMultipleObjects(3, handles, false, INFINITE);
		switch (rc) {
		case WAIT_OBJECT_0:		// hTermEvent �I���v��
			DOUT("wait thread detect term event\n");
			ExitThread(0);
		case WAIT_OBJECT_0 + 1:	// hProcess �q�v���Z�X�̏I��
			DOUT("wait thread detect child process exit\n");
			if (NULL != parentWnd) PostMessage(parentWnd, message, CS_MSG_DELETE_REQUEST, 0);
			break;
		case WAIT_OBJECT_0 + 2:	// hReadEvent �ǂݍ��݉\�ʒm
			DOUT("wait thread detect read event\n");
			if (NULL != parentWnd) PostMessage(parentWnd, message, CS_MSG_PREPARED_TO_READ, 0);
			break;
		}
	}
	return 0;
}

DWORD WINAPI
Spawn::ReadThreadStart
(LPVOID obj)
{
	DOUT("START READ THREAD\n");
	return ((Spawn *)obj)->ReadThreadMain();
}

DWORD
Spawn::ReadThreadMain
(void)
{
	// �ҋ@�p�I�u�W�F�N�g�̗�
	HANDLE handles[2];
	handles[0] = hTermEvent;
	handles[1] = hReadNextEvent;

	for (;;) {
		DWORD readSize;
		DOUT("READ\n");
		if (!ReadFile(hReadPipe, NULL, 0, &readSize, NULL)) {
			DOUT("read failed\n");
			ExitThread(0);
		} else {
			DOUT("can read\n");
			SetEvent(hReadEvent);
			// ���C���X���b�h���ǂނ܂ő҂�
			DWORD rc = WaitForMultipleObjects(2, handles, false, INFINITE);
			switch (rc) {
			case WAIT_OBJECT_0:		// hTermEvent �I���v��
				DOUT("read thread detect term event\n");
				ExitThread(0);
			case WAIT_OBJECT_0 + 1:	// hReadNextEvent ���̓ǂݍ��ݑ҂��v��
				DOUT("read thread detect read next event\n");
				break;
			}
		}
	}
}
