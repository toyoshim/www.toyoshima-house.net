/* --------------------------------------------------------------------------------------------
 *  Pop'n Pop - hotmail to pop3 gateway -
 *  EL-POINT subset version for KARIHITO
 *  �E�F�u�E�T�C���A�b�v (C) ACENET, Inc.
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in) / BeOS
 *  LwXML - Light weight XML Library -
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 1999,2000 �Ƃ悵��
 *  $Id: Common.h,v 1.11 2000/06/10 21:49:22 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [Common.h]
 *   ���ʂɃC���N���[�h�����B
 *  ��Ƀf�o�b�O�p�̃g���b�N�����S�B���C�����[�`���̎������ɂ�__Main__���`���ăC���N���[�h
 *  ����ƁA�f�o�b�O���[�`���̎�������荞�܂��B
 *  VisualC++�p�ɓ�������Ă��邪�A�t�ɂ��̃t�@�C�����C�����邾���ő��̊��ł��R���p�C��
 *  �\�Ȃ͂��B
 *  DOUT�n���b�Z�[�W�̓f�o�b�K������E�����Ƃ��ł��邪�Awww.sysinternals.com ��DebugView��
 *  �g���Ɩڂ���؁B
 *  ���C�����[�`���𔲂���ۂ́Aexit���g�����ƁB���̍ۃf�o�b�O�p�̃R�[�h�ł́A�J�����Y��Ă���
 *  ���������`�F�b�N���A�K�v�ȏ����_���v���Ă����B
 * -------------------------------------------------------------------------------------------- */

#if !defined(__Common_h__)
#	define	__Common_h__

#   if !defined(__WIN32__) && defined(_WIN32)
#       define  __WIN32__
#   endif   // !defined(__WIN32__) && defined(_WIN32)

#   if !defined(__VISUALC__) && defined(_MSC_VER)
#       define  __VISUALC__
#   endif   // !defined(__VISUALC__) && defined(_MSC_VER)

//
// �W���C���N���[�h�t�@�C��
// �iVisualC++�̂��߂̃f�o�b�O�p�g���b�N����j
//////////////////////////////////////////////////////////////////////////////////////////////////
#	include <stdio.h>
#	if defined(__VISUALC__) && defined(_DEBUG)
#		define	_CRTDBG_MAP_ALLOC
#	endif	// defined(__VISUALC__) && defined(_DEBUG)
#	include <stdlib.h>
#	if defined(__VISUALC__) && defined(_DEBUG)
#		include <crtdbg.h>
#	endif	// defined(__VISUALC__) && defined(_DEBUG)
#	include <stdarg.h>
#	include <string.h>
#	include <math.h>
#	include <fcntl.h>
#	include <time.h>
#	include <sys/types.h>
#	include <sys/stat.h>

//
// Windows�p�����`
//////////////////////////////////////////////////////////////////////////////////////////////////
#	if defined(__WIN32__)
//
// VisualC++�p build ���ԒZ�k�̃g���b�N
#		if defined(__VISUALC__)
#			if !defined(WIN32_LEAN_AND_MEAN)
#				define	WIN32_LEAN_AND_MEAN
#			endif	// !defined(WIN32_LEAN_AND_MEAN)
#		endif	// defined(__VISUALC__)

//
// Windows �o�[�W�����錾
#		define	_WIN32_IE	    0x0300
#       define  _WIN32_WINNT    0x0400
#		define	WINVER		    0x0400

//
// Windows �C���N���[�h
// �i�}�N������WinSock2���g���g���b�N����j
#		define _WINSOCKAPI_
#		include <windows.h>
#		include <windowsx.h>
#		undef	_WINSOCKAPI_
#		include <winsock2.h>
#		include <mmsystem.h>
#		include <ras.h>
#		include <raserror.h>
#		include <shellapi.h>
#		include <commdlg.h>

//
// DirectX �o�[�W�����錾
#		define	DIRECTDRAW_VERSION		0x0300
#		define	DIRECTSOUND_VERSION		0x0300

//
// DirectX �C���N���[�h
#		include <ddraw.h>
#		include <dsound.h>

#	endif	// defined(__WIN32__)

//
// BeOS �C���N���[�h
//////////////////////////////////////////////////////////////////////////////////////////////////
#	if defined(__BEOS__)
#		include <Be.h>
#	endif	// defined(__BEOS__)

//
// VisualC++�̂��߂̒��ۃN���X�̍œK���������邨�܂��Ȃ�
//////////////////////////////////////////////////////////////////////////////////////////////////
#	if defined(__VISUALC__)
#		define	abstract	__declspec(novtable)
#		pragma warning(disable: 4091)
#	else	// defined(__VISUALC__)
#		define	abstract
#	endif	// defined(__VISUALC__)

//
// �萔�E�^�E�}�N����`
//////////////////////////////////////////////////////////////////////////////////////////////////
#	if !defined(NULL)
#		if defined(__cplusplus)
#			define	NULL (0)
#		else	// defined(__cplusplus)
#			define	NULL ((void *)0)
#		endif	// defined(__cplusplus)
#	endif	// !defined(NULL)
#	if !defined(_MAX_PATH)
#		define	_MAX_PATH	(4096)
#	endif	// !defined(_MAX_PATH)
#	if !defined(O_SHLOCK)
#		define	O_SHLOCK	(0)
#	endif	// !defined(O_SHLOCK)
#   define  NOUSE(v)    (void)v;

//
// Windows�n�̒萔�E�^�E�}�N����`
//////////////////////////////////////////////////////////////////////////////////////////////////
#	if !defined(__WIN32__)
typedef unsigned char BYTE, *LPBYTE, UCHAR, *LPUCHAR;
typedef unsigned short WORD, *LPWORD, USHORT, *LPUSHORT;
typedef unsigned int WPARAM, *LPWPARAM, UINT, *LPUINT;
typedef unsigned long DWORD, *LPDWORD, ULONG, *LPULONG;
typedef char CHAR, *LPCHAR, STR, *LPSTR;
typedef short SHORT, *LPSHORT;
typedef long LONG, LPARAM, *LPLONG, *LPLPARAM;
typedef const char CSTR, *LPCSTR;
typedef void VOID, *LPVOID;
typedef LPVOID HANDLE;
typedef HANDLE HINSTANCE, HWND, HDC;
#		if defined(UNICODE)
typedef char TSTR, *LPTSTR;
typedef const char CTSTR, *LPCTSTR;
#		else	// defined(UNICODE)
typedef unsigned short TSTR, *LPTSTR;
typedef const char CTSTR, *LPCTSTR;
#		endif	// defined(UNICODE)
#		define	ZeroMemory(ptr, size)	memset(ptr, 0, size)
#		define	RGB(r,g,b)				((r << 8) | (g << 16) | (b << 24))
#	endif	// !defined(__WIN32__)


#	if defined(__WIN32__)
typedef HBITMAP	BITMAP_HANDLE;
#		define	vsnprintf	_vsnprintf
#	elif defined(__BEOS__)
class BBitmap;
typedef BBitmap *BITMAP_HANDLE;
#	else	// defined(__WIN32__)
typedef void *BITMAP_HANDLE;
#	endif	// defined(__WIN32__)

//
// �\�[�X�݊����ێ��p�̒��ی^�錾
//////////////////////////////////////////////////////////////////////////////////////////////////
#	if defined(__WIN32__)
#		define	FILE_HANDLE			HANDLE
#		define	INVALID_FILE_HANDLE	((FILE_HANDLE)INVALID_HANDLE_VALUE)
#           if defined(FILE_READ_ONLY)
#               undef FILE_READ_ONLY
#           endif   // defined(FILE_READ_ONLY)
#		define	FILE_READ_ONLY		(GENERIC_READ)
#		define	FILE_WRITE_ONLY		(GENERIC_WRITE)
#		define	FILE_READ_WRITE		(GENERIC_READ | GENERIC_WRITE)
#		define	FILE_FORCE_CREATE	(CREATE_ALWAYS)
#		define	FILE_CREATE_NEW		(CREATE_NEW)
#		define	FILE_FORCE_OPEN		(OPEN_ALWAYS)
#		define	FILE_OPEN_ONLY		(OPEN_EXISTING)
#		define	FILE_POS_BEGIN		(FILE_BEGIN)
#		define	FILE_POS_CURRENT	(FILE_CURRENT)
#		define	FILE_POS_END		(FILE_END)
#	else	// defined(__WIN32__)
#		define	FILE_HANDLE			int
#		define	INVALID_FILE_HANDLE	((FILE_HANDLE)(-1))
#		define	FILE_READ_ONLY		(O_RDONLY)
#		define	FILE_WRITE_ONLY		(O_WRONLY)
#		define	FILE_READ_WRITE		(O_RDWR)
#		define	FILE_SHARE_READ		(O_SHLOCK)
#		define	FILE_FORCE_CREATE	(O_CREAT | O_TRUNC)
#		define	FILE_CREATE_NEW		(O_CREAT | O_EXCL)
#		define	FILE_FORCE_OPEN		(O_CREAT)
#		define	FILE_OPEN_ONLY		(0)
#		define	FILE_POS_BEGIN		(SEEK_SET)
#		define	FILE_POS_CURRENT	(SEEK_CUR)
#		define	FILE_POS_END		(SEEK_END)
#	endif	// !defined(__WIN32__)

//
// �\�[�X�݊����ێ��p�̒��ۊ֐�
//////////////////////////////////////////////////////////////////////////////////////////////////
//
// �}�N���֐�
#	if defined(__WIN32__)
#		define	file_open(name, access, share, disp)	::CreateFile(name, access, share, NULL, disp, FILE_ATTRIBUTE_ARCHIVE, NULL)
#		define	file_close(fh)							(TRUE == ::CloseHandle(fh))
#		define	file_seek(fh, offset, mode)				::SetFilePointer(fh, offset, NULL, mode)
#		define	file_size(fh)							::GetFileSize(fh, NULL)
#		define	file_remove(name)						::DeleteFile(name)
#		define	snprintf								_snprintf
#	else	// defined(__WIN32__)
#		define	file_open(name, access, share, disp)	open(name, access | share | disp)
#		define	file_close(fh)							(0 == close(fh))
#		define	file_seek(fh, offset, mode)				lseek(fh, offset, mode)
#		define	file_read(fh, buf, size)				read(fh, buf, size)
#		define	file_write(fh, buf, size)				write(fh, buf, size)
#		define	file_remove(name)						remove(name)
#	endif	// defined(__WIN32__)

//
// �݊��p�֐��̐錾
#	if defined(__BEOS__) && defined(__POWERPC__)	// CodeWarrior�n��
int snprintf(char *str, size_t size, const char *format, ...);
#	endif	// defined(__BEOS__) && defined(__POWERPC__)
#	if defined(__WIN32__)
size_t file_read(FILE_HANDLE fh, char *buf, size_t size);
size_t file_write(FILE_HANDLE fh, char *buf, size_t size);
#	else	// defined(__WIN32__)
size_t file_size(FILE_HANDLE fh);
#	endif	// defined(__WIN32__)

//
// �݊��p�֐��̎���
#	if defined(__Main__)
#		if defined(__BEOS__) && defined(__POWERPC__)
int
snprintf
(char *str, size_t size, const char *format, ...)
{
	va_list list;
	int result;

	va_start(list, format);
	result = vsprintf(str, format, list);
	va_end(list);
	return result;
}
#		endif	// defined(__BEOS__) && defined(__POWERPC__)
#		if defined(__WIN32__)
size_t
file_read
(FILE_HANDLE fh, char *buf, size_t size)
{
	DWORD readsize;
	if (0 == ReadFile(fh, (LPVOID)buf, size, &readsize, NULL)) return 0;
	return readsize;
}

size_t
file_write
(FILE_HANDLE fh, char *buf, size_t size)
{
	DWORD writesize;
	if (0 == WriteFile(fh, (LPVOID)buf, size, &writesize, NULL)) return 0;
	return writesize;
}
#		else	// defined(__WIN32__)
size_t
file_size
(FILE_HANDLE fh)
{
	unsigned long filesize;
	struct stat sb;
	if (0 == fstat(fh, &sb)) filesize = sb.st_size;
	else filesize = (unsigned long)-1;
	return filesize;
}
#		endif	// defined(__WIN32__)
#	endif	// defined(__Main__)

//
// �f�o�b�O�p�̒�`
//////////////////////////////////////////////////////////////////////////////////////////////////
#	if defined(_DEBUG)

//
// �f�o�b�O�p�֐��̐錾
#		if !defined(__BORLANDC__)
#			if defined(__VISUALC__)
#				define  ___debug_malloc(size, file, line)	_malloc_dbg(size, _CLIENT_BLOCK, file, line)
#				define  ___debug_free(pv)					_free_dbg(pv, _CLIENT_BLOCK)
#				define	___debug_realloc(v, s, f, l)		realloc(v, s)
#				define	___debug_strdup(c, f, l)			strdup(c)
#			else    // defined(__VISUALC__)
void *___debug_malloc(size_t size, const char *file, int line);
void ___debug_free(void *pv);
void *___debug_realloc(void *pv, size_t size);
char *___debug_strdup(const char *c, const char *fname, int line);
#			endif   // defined(__VISUALC__)
void *operator new(size_t stAllocateBlock, const char *file, int line);
void *operator new[](size_t stAllocateBlock, const char *file, int line);
void operator delete(void *pv, const char *file, int line);
void operator delete[](void *pv, const char *file, int line);
#		endif   // !defined(__BORLANDC__)
int ___debug_message(const char *format, ...);
int ___debug_message_n(const char *buffer, int size);
void ___debug_exit(int _int);
void ___error_message(const char *file, int line);
#		if !defined(__WIN32__)
void ___debug_puts(const char *s);
#			define	OutputDebugString(s)	___debug_puts(s)
#		endif	// !defined(__WIN32__)

//
// �f�o�b�O�p�֐��̎���
#		if defined(__Main__)
#			define	___MAX_MESSAGE_BUFFER	1024

//
// ���������[�N�`�F�b�N�@�\
#           if !defined(__VISUALC__) && !defined(__BORLANDC__)

struct ___debug_meminfo{
    unsigned long magic;
    const char *fname;
    int line;
    size_t size;
	struct ___debug_meminfo *next;
	struct ___debug_meminfo *before;
};

static struct ___debug_meminfo *___debug_meminfo_first = NULL;
static struct ___debug_meminfo *___debug_meminfo_last = NULL;
static FILE *___debug_file_handle = 0;

void *
___debug_malloc
(size_t size, const char *file, int line)
{
//    ___debug_message("allocate memory %d byte(s): %s(%d)\n", size, file, line);
    void *pv = malloc(size + sizeof(struct ___debug_meminfo));
    if (NULL == pv) {
        ___debug_message("%s(%d):%s\n", file, line, "**********************************");
        ___debug_message("%s(%d):%s\n", file, line, "*** memory allocation failed ! ***");
        ___debug_message("%s(%d):%s\n", file, line, "**********************************");
        return NULL;
    }
    struct ___debug_meminfo *info = (struct ___debug_meminfo *)pv;
    info->magic = 'sAMy';
    info->fname = file;
    info->line = line;
    info->size = size;
	info->next = NULL;
	info->before = NULL;
	if (NULL == ___debug_meminfo_first) {
		___debug_meminfo_first = ___debug_meminfo_last = info;
	} else {
		___debug_meminfo_last->next = info;
		info->before = ___debug_meminfo_last;
		___debug_meminfo_last = info;
	}
    info++;
    return (void *)info;
}

void
___debug_free
(void *pv)
{
    if (NULL == pv) return;
    struct ___debug_meminfo *info = (struct ___debug_meminfo *)pv;
    info--;
    if (info->magic != 'sAMy') {
    	// Common.h���e�����y�ڂ��\�[�X�O��new���ꂽ�I�u�W�F�N�g��delete����ۂɋN������
        ___debug_message("*** \'free\' called with invalid memory pointer. ***\n");
		free(pv);
        return;
    }
//    ___debug_message("free: %s(%d)[%d]\n", info->fname, info->line, info->size);
	if (NULL != info->next) info->next->before = info->before;
	if (NULL != info->before) info->before->next = info->next;
	if (___debug_meminfo_first == info) ___debug_meminfo_first = info->next;
	if (___debug_meminfo_last == info) ___debug_meminfo_last = info->before;
//	___debug_message("first: %08x / last: %08x / next: %08x / before: %08x\n", ___debug_meminfo_first, ___debug_meminfo_last, info->next, info->before);
	free(info);
}

void *
___debug_realloc
(void *pv, size_t size, const char *fname, int line)
{
	struct ___debug_meminfo *info = (struct ___debug_meminfo *)pv;
	info--;
	if (info->magic != 'sAMy') {
        ___debug_message("*** \'realloc\' called with invalid memory pointer. ***\n");
		___debug_free(pv);
        return NULL;
	}
	void *result = ___debug_malloc(size, fname, line);
	if (NULL == result) {
		___debug_free(pv);
		return NULL;
	}
	memcpy(result, pv, info->size);
	info->size = size;
	return result;
}

char *
___debug_strdup
(const char *c, const char *fname, int line)
{
	int size = strlen(c);
	char *result = (char *)___debug_malloc(size + 1, fname, line);
	if (NULL != result) {
		memcpy(result, c, size);
		result[size] = 0;
	}
	return result;
}

#			endif   // !defined(__VISUALC__) && !defined(__BORLANDC__)

#           if !defined(__BORLANDC__)
void *
operator new
(size_t stAllocateBlock, const char *file, int line)
{
	return ___debug_malloc(stAllocateBlock, file, line);
}

void *
operator new[]
(size_t stAllocateBlock, const char *file, int line)
{
	return ___debug_malloc(stAllocateBlock, file, line);
}

void
operator delete
(void *pv, const char *file, int line)
{
    NOUSE(file);
    NOUSE(line);
    ___debug_free(pv);
}

void
operator delete[]
(void *pv, const char *file, int line)
{
    NOUSE(file);
    NOUSE(line);
    ___debug_free(pv);
}

#				if !defined(__VISUALC__)

void
operator delete
(void *pv)
{
    ___debug_free(pv);
}

void
operator delete[]
(void *pv)
{
    ___debug_free(pv);
}

#				endif   // !defined(__VISUALC__)
#           endif   // !defined(__BORLANDC__)

char ___debug_message_buffer[___MAX_MESSAGE_BUFFER];

int
___debug_message
(const char *format, ...)
{
	va_list list;
	int result;

	va_start(list, format);
	result = vsnprintf(___debug_message_buffer, ___MAX_MESSAGE_BUFFER, format, list);
	OutputDebugString(___debug_message_buffer);
	va_end(list);
	return result;
}

int
___debug_message_n
(const char *buffer, int size)
{
	if (-1 == size) size = strlen(buffer);
	char *tmp = (char *)malloc(size + 1);
	if (NULL == tmp) return 0;
	memcpy(tmp, buffer, size);
	tmp[size] = 0;
	OutputDebugString(tmp);
	free(tmp);
	return size;
}

void
___debug_exit
(int _int)
{
#           if defined(__VISUALC__)
	_CrtDumpMemoryLeaks();
#			elif !defined(__BORLANDC__)
	struct ___debug_meminfo *p = ___debug_meminfo_first;
	if (NULL != p) {
		___debug_message("*** memory leak detented ! ***\n");
		for (struct ___debug_meminfo *p = ___debug_meminfo_first; NULL != p; p = p->next) {
			char *data = (char *)(&p[1]);
			___debug_message("%s(%d): %dbyte(s) [", p->fname, p->line, p->size);
			unsigned int i;
			for (i = 0; i < p->size; i++) {
				___debug_message("%c", data[i]);
				if (i == 7) {
					___debug_message("...");
					break;
				}
			}
			___debug_message("(");
			for (i = 0; i < p->size; i++) {
				___debug_message("%02X,", (data[i] & 0xff));
				if (i == 7) {
					___debug_message("...");
					break;
				}
			}
			___debug_message(")]\n");
		}
	}
#           endif   // defined(__VISUALC__)
#			if !defined(__WIN32__)
	if (NULL != ___debug_file_handle) {
		fclose(___debug_file_handle);
		___debug_file_handle = NULL;
	}
#			endif	// !defined(__WIN32__)
	_exit(_int);
}

void
___error_message
(const char *file, int line)
{
#if			defined(__WIN32__)
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf,
		0,
		NULL
		);
	___debug_message("%s (%d) *Error*: %s\n", file, line, lpMsgBuf);
	LocalFree(lpMsgBuf);
#			endif	// defined(__WIN32__)
}

#			if !defined(__WIN32__)
void
___debug_puts
(const char *str)
{
		if (NULL == ___debug_file_handle) {
			___debug_file_handle = fopen("/dev/tt/sf", "w");
		}
		if (NULL != ___debug_file_handle) {
			fprintf(___debug_file_handle, "%s", str);
		}
}
#			endif	// !defined(__WIN32__)

#		endif	// !defined(__Main__)

//
// �f�o�b�O�p�̃}�N����`
#		define	DOUT			___debug_message("%s (%d) : ", __FILE__, __LINE__) && ___debug_message
#		define	DOUTN(b, s)		___debug_message("%s (%d) : ", __FILE__, __LINE__) && ___debug_message_n((const char *)b, s)
#		define	DOUTR			___debug_message
#		define	DOUTRN(b, s)	___debug_message_n((const char *)b, s)
#		define	DERR()			___error_message(__FILE__, __LINE__)
#       if !defined(__BORLANDC__)
#           define	new		new(__FILE__, __LINE__)
#       endif   // !defined(__BORLANDC__)
#		define	exit(i)	___debug_exit(i)
#		if !defined(__BORLANDC__) && !defined(__VISUALC__)
#			define	malloc(s)		___debug_malloc(s, __FILE__, __LINE__)
#			define	realloc(v, s)	___debug_realloc(v, s, __FILE__, __LINE__)
#			define	strdup(c)		___debug_strdup(c, __FILE__, __LINE__)
#			define	free(v)			___debug_free(v)
#		endif	// !defined(__BORLANDC__) && !defined(__VISUALC__)

#	else	// defined(_DEBUG)

//
// VisualC++�p�̌x���}��
#		if defined(__VISUALC__)
#			pragma warning(disable: 4390)
#		endif	// defined(__VISUALC__)

#		define	DOUT	(void)
#		define	DOUTN	(void)
#		define	DOUTR	(void)
#		define	DOUTRN	(void)
#		define	DERR()	(void)(0);

#	endif	// defined(_DEBUG)

//
// �ȗ��p�}�N���̒�`
//////////////////////////////////////////////////////////////////////////////////////////////////
#	define	_throw(x)				{ lastError = x; throw x; }	
#	define	_return(x)				{ lastError = x; return false; }
#	define	_verify(x, s, r)		x = s; if (NULL == x) { r; }
#	define	_verifysock(x, s, r)	x = s; if (INVALID_SOCKET == x) { r; }
#	define	_post(x)				{ lastError = x; PostMessage(hWnd, MSG_ERROR, (WPARAM)x, 0); return 0; }
#	define	_error(x)				{ lastError = x; Error(x); return 0; }
#	define	_null(x, f)				{ if (NULL != x) { f(x); x = NULL; } }
#	define	_nulldelete(x)			{ if (NULL != x) { delete x; x = NULL; } }

#	if !defined(__Errors_h__)
#		include "Errors.h"
#	endif	// !defined(__Errors_h__)

#endif	// !defined(__Common_h__)
