/* --------------------------------------------------------------------------------------------
 *  Pop'n Pop - hotmail to pop3 gateway -
 *  �E�F�u�E�T�C���A�b�v (C) ACENET, Inc.
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 1999,2000 �Ƃ悵��
 *  $Id: TCPServer.cpp,v 1.4 2000/06/10 21:49:22 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [TCPServer.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "TCPServer.h"

TCPServer::TCPServer
(const char *name):
MessageWindow(),
messageHWnd(NULL),
parentHWnd(NULL),
parentThread(0),
messageMode(MESSAGEMODE_HWND),
messageWindowName(NULL),
serverSocket(INVALID_SOCKET),
server(~0),
port(-1)
{
	if (NULL != name) {
		int len = strlen(name);
		messageWindowName = new char[len + 1];
		if (NULL != messageWindowName) strcpy(messageWindowName, name);
	}
}

TCPServer::~TCPServer
(void)
{
	Stop();
	if (NULL != messageWindowName) delete messageWindowName;
}

BOOL
TCPServer::Start
(unsigned long server, int port, DWORD parentThread, UINT message)
{
	this->server = server;
	this->port = port;
	messageId = message;
	this->parentThread = parentThread;
	messageMode = MESSAGEMODE_THREAD;
	if (!OpenWindow(messageHWnd, NULL, messageWindowName)) return false;
	DOUT("START\n");
	return true;
}

BOOL
TCPServer::Start
(unsigned long server, int port, HWND parentHWnd, UINT message)
{
	this->server = server;
	this->port = port;
	messageId = message;
	this->parentHWnd = parentHWnd;
	messageMode = MESSAGEMODE_HWND;
	if (!OpenWindow(messageHWnd)) return false;
	DOUT("START\n");
	return true;
}

BOOL
TCPServer::Stop
(void)
{
	if (NULL != messageHWnd) {
		BOOL result = DestroyWindow(messageHWnd);
		if (result) return true;
		_return(ERROR_DESTROYWINDOW);
	}
	_return(ERROR_ALREADY_STOP);
}

LRESULT
TCPServer::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
//	DOUT("TCPServer::WindowProc($%08x, $%08x, $%08x, $%08x)\n", hWnd, nMsg, wParam, lParam);
	LRESULT r = 0;
	switch (nMsg) {
	case WM_CREATE:
		r = ServerInit(hWnd, nMsg, wParam, lParam);
		break;
	case WM_CLOSE:
		DOUT("CLOSE...\n");
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		DOUT("DESTROY...\n");
		messageHWnd = NULL;
		r = ServerTrash(hWnd, nMsg, wParam, lParam);
		break;
	case MSG_ERROR:
		DOUT("TCPServer::WindowProc - MSG_ERROR : %d\n", wParam);
		if (MESSAGEMODE_HWND == messageMode) PostMessage(parentHWnd, messageId, wParam, lParam);
		else PostThreadMessage(parentThread, messageId, wParam, lParam);
		break;
	case MSG_WINSOCK:
		return WinSock(hWnd, nMsg, wParam, lParam);
	}
	return (0 == r) && MessageWindow::WindowProc(hWnd, nMsg, wParam, lParam);
}

LRESULT
TCPServer::ServerInit
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	_verifysock(serverSocket, socket(AF_INET, SOCK_STREAM, 0), _post(ERROR_CREATE_SOCK));
	if (WSAAsyncSelect(serverSocket, hWnd, MSG_WINSOCK, FD_ACCEPT)) _post(ERROR_ASYNCSELECT);

	SOCKADDR_IN sa;
	ZeroMemory(&sa, sizeof(SOCKADDR_IN));
	sa.sin_family = AF_INET;
	memcpy(&sa.sin_addr, &server, sizeof(unsigned long));
	sa.sin_port = htons((u_short)port);
	if (bind(serverSocket, (SOCKADDR *)&sa, sizeof(SOCKADDR_IN))) _post(ERROR_BIND);
	if (listen(serverSocket, 4)) _post(ERROR_LISTEN);
	DOUT("Server Start on Port %d\n", port);
	return 0;
}

LRESULT
TCPServer::ServerTrash
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	if (INVALID_SOCKET != serverSocket) {
		if (0 != closesocket(serverSocket)) _post(ERROR_CLOSESOCKET);
		serverSocket = INVALID_SOCKET;
	}
	return 0;
}

LRESULT
TCPServer::WinSock
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	int nEvent = WSAGETSELECTEVENT(lParam);
	int nError = WSAGETSELECTERROR(lParam);
	DOUT("WinSock: %08x / %08x\n");
	if (0 != nError) {
		PostMessage(hWnd, MSG_ERROR, ERROR_WINSOCK, nError);
		return 0;
	}
	if (FD_ACCEPT != nEvent) _post(ERROR_INVALID_WINSOCK);

	// accept
	Accept(serverSocket);
	return 0;
}

void
TCPServer::Accept(SOCKET server)
{
	DOUT("ACCEPT\n");
	SOCKADDR addr;
	int addrlen = sizeof(SOCKADDR);
	SOCKET s = accept(server, &addr, &addrlen);
	if (INVALID_SOCKET == s) {
		PostMessage(messageHWnd, MSG_ERROR, ERROR_ACCEPT, 0);
		return;
	}
	if (0 != closesocket(s)) PostMessage(messageHWnd, MSG_ERROR, ERROR_CLOSESOCKET, 0);
}
