/* --------------------------------------------------------------------------------------------
 *  EL-POINT subset version for KARIHITO
 *  (C) 1999,2000 �Ƃ悵��
 *  $Id: Registry.h,v 1.3 2000/06/10 21:49:22 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [Registry.h]
 *   ���W�X�g���𑀍삷��N���X
 * -------------------------------------------------------------------------------------------- */

#if !defined(__Registry_h__)
#	define	__Registry_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

class Registry{
#	define	CRTYPE_MACHINE	0
#	define	CRTYPE_USER		1
private:
	HKEY hKey;
public:
	Registry(void): hKey(NULL) {};
	~Registry(void);

	bool Open(const char *name, int type = CRTYPE_USER);
	void Close(void);

	bool SetInt(const char *name, int param);
	bool GetInt(const char *name, int &param, int default_value = 0);
	bool SetStr(const char *name, const char *param);
	bool GetStr(const char *name, char *param, int &paramsize, const char *default_value = NULL);
	bool SetData(const char *name, const char *param, int paramsize);
	bool GetData(const char *name, const char *param, int paramsize);
};

#	if !defined(__Registry__)
#		define	__Registry__
#	endif	// !defined(__Registry__)

#endif	// !defined(__Registry_h__)
