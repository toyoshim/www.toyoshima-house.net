/* --------------------------------------------------------------------------------------------
 *  Pop'n Pop - hotmail to pop3 gateway -
 *  �E�F�u�E�T�C���A�b�v (C) ACENET, Inc.
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 1999,2000 �Ƃ悵��
 *  $Id: AsyncSocket.cpp,v 1.4 2000/06/10 21:49:22 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [AsyncSocket.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "AsyncSocket.h"

AsyncSocket::AsyncSocket
(SOCKET socket):
MessageWindow(),
socket(socket),
writeBuffer(NULL),
writeBufferSize(0),
messageHWnd(NULL)
{
}

AsyncSocket::~AsyncSocket
(void)
{
	if (NULL != messageHWnd) {
		if (!DestroyWindow(messageHWnd)) _throw(ERROR_DESTROYWINDOW);
	}
	if (INVALID_SOCKET != socket) {
		if (!SocketClose()) _throw(ERROR_CLOSESOCKET);
	}
	if (NULL != writeBuffer) free(writeBuffer);
}

BOOL
AsyncSocket::Start
(HWND hWnd)
{
	if (!OpenWindow(messageHWnd, hWnd)) return false;
	DOUT("HWND = $%08X\n", messageHWnd);
	return true;
}

LRESULT
AsyncSocket::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
//	DOUT("AsyncSocket::WindowProc($%08x, $%08x, $%08x, $%08x)\n", hWnd, nMsg, wParam, lParam);
	LRESULT r = 0;
	switch (nMsg) {
	case WM_CREATE:
		r = SocketInit(hWnd, nMsg, wParam, lParam);
		break;
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		messageHWnd = NULL;
		r = SocketTrash(hWnd, nMsg, wParam, lParam);
		break;
	case MSG_ASYNC_WINSOCK:
		return WinSock(hWnd, nMsg, wParam, lParam);
	}
	return (0 == r) && MessageWindow::WindowProc(hWnd, nMsg, wParam, lParam);
}

LRESULT
AsyncSocket::SocketInit
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	if (WSAAsyncSelect(socket, hWnd, MSG_ASYNC_WINSOCK, FD_READ | FD_WRITE | FD_CLOSE)) _error(ERROR_ASYNCSELECT);
	return 0;
}

LRESULT
AsyncSocket::SocketTrash
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	if (INVALID_SOCKET != socket) {
		if (!SocketClose()) _error(ERROR_CLOSESOCKET);
	}
	return 0;
}

LRESULT
AsyncSocket::WinSock
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	int nEvent = WSAGETSELECTEVENT(lParam);
	int nError = WSAGETSELECTERROR(lParam);

	switch (nError) {
	case 0:
		break;
	case WSAECONNABORTED:
		DOUT("WinSock: Connection Aborted\n");
		break;
	default:
		DOUT("WinSockError: %08X\n", nError);
		_error(ERROR_WINSOCK);
	}
	switch (nEvent) {
	case FD_CLOSE:
	case FD_READ:
		for (;;) {
			int size = recv(socket, readBuffer, MAX_ASYNC_BUFFER, 0);
			if (0 == size) break;
			if (SOCKET_ERROR == size) {
				if (WSAEWOULDBLOCK != WSAGetLastError()) {
					if (FD_READ == nEvent) {
						DOUT("FD_READ : %d\n", WSAGetLastError());
						break;
					} else {
						if (!SocketClose()) _error(ERROR_CLOSESOCKET);
						break;
					}
				}
				break;
			}
			SocketRead(readBuffer, size);
		}
		if (FD_CLOSE == nEvent) {
			if (INVALID_SOCKET != socket) {
				if (!SocketClose()) _error(ERROR_CLOSESOCKET);
			}
		}
		break;
	case FD_WRITE:
		if (0 == writeBufferSize) break;
		for (;;) {
			int size = send(socket, writeBuffer, writeBufferSize, 0);
			DOUT("FD_WRITE %d BYTES\n", size);
			if (0 == size) break;
			if (SOCKET_ERROR == size) {
				if (WSAEWOULDBLOCK != WSAGetLastError()) _error(ERROR_FD_WRITE);
				break;
			}
			writeBufferSize -= size;
			if (0 == writeBufferSize) {
				free(writeBuffer);
				writeBuffer = NULL;
				break;
			} else {
				memmove(writeBuffer, &writeBuffer[size], writeBufferSize);
			}
		}
		break;
	}
	return 0;
}

void
AsyncSocket::SocketRead
(char *buffer, int size)
{
}

void
AsyncSocket::SocketWrite
(const char *buffer, int size)
{
//	DOUT("AsyncSocket::SocketWrite\n");
	if (-1 == size) size = strlen(buffer);

	if (NULL == writeBuffer) {
		// �L���[����Ȃ珑���邾������
		int sendsize = send(socket, buffer, size, 0);
		if (SOCKET_ERROR == sendsize) {
			DWORD error = WSAGetLastError();
			if (WSAEWOULDBLOCK != error) {
				if (WSAECONNABORTED == error) {
					SocketShutdown();
				} else {
					lastError = ERROR_FD_WRITE;
					Error(ERROR_FD_WRITE);
				}
				return;
			}
			sendsize = 0;
		}
		buffer += sendsize;
		size -= sendsize;
//		DOUT("WRITE %d BYTES\n", sendsize);
	}
	if (0 == size) return;
	// ��������Ȃ�����
	if (NULL == writeBuffer) {
		writeBuffer = (char *)malloc(size);
		writeBufferSize = size;
	} else {
		writeBuffer = (char *)realloc(writeBuffer, writeBufferSize + size);
		writeBufferSize += size;
	}
	if (NULL == writeBuffer) {
		writeBufferSize = 0;
		lastError = ERROR_FD_WRITE;
		Error(ERROR_FD_WRITE);
		return;
	}
//	DOUT("STOCK %d BYTES\n", writeBufferSize);
	memcpy(&writeBuffer[writeBufferSize - size], buffer, size);
}

BOOL
AsyncSocket::SocketShutdown
(void)
{
	if (INVALID_SOCKET == socket) return false;
	if (0 != shutdown(socket, SD_SEND)) _return(ERROR_SHUTDOWN);
	return true;	// ���̌�AFD_CLOSE���z������ASocketClose�Ɉڍs����
}

BOOL
AsyncSocket::SocketClose
(void)
{
	if (INVALID_SOCKET == socket) return true;
	if (0 != shutdown(socket, SD_BOTH)) _return(ERROR_SHUTDOWN);
	int result = closesocket(socket);
	DOUT("socket closed\n");
	socket = INVALID_SOCKET;
	SocketClosed();
	return (0 == result);
}

void
AsyncSocket::SocketClosed
(void)
{
}

void
AsyncSocket::Error
(int code)
{
}
