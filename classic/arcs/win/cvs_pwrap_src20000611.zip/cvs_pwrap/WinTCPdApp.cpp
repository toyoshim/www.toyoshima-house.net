/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: WinTCPdApp.cpp,v 1.4 2000/06/10 21:49:19 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [WinTCPdApp.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "WinTCPdApp.h"
#include "SuperServer.h"
#include "AboutDialog.h"
#include "SettingDialog.h"
#include "resource.h"
#include "default.h"
#include "regname.h"

WinTCPdApp::WinTCPdApp
(void):
ad(NULL),
sd(NULL),
ss(NULL)
{
	HINSTANCE hInstance = GetModuleHandle(NULL);
	hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
	hMenu = LoadMenu(hInstance, MAKEINTRESOURCE(IDR_MENU1));
	hPopup = GetSubMenu(hMenu, 0);

	if (!Open(WINTCPD_REG_ROOT)) {
		DOUT("registry can not opened\n");
	}
	if (!StartServer()) {
		MessageBox(NULL, "�T�[�o�[�̏������Ɏ��s���܂����B", "WinTCPd", MB_OK);
		PostQuitMessage(0);
	}

	AddIconTaskTray(true, hIcon, "CVS pserver");
}

WinTCPdApp::~WinTCPdApp
(void)
{
	if (INVALID_HANDLE_VALUE != hIcon) CloseHandle(hIcon);
	if (INVALID_HANDLE_VALUE != hPopup) CloseHandle(hPopup);
	if (INVALID_HANDLE_VALUE != hMenu) CloseHandle(hMenu);
	if (NULL != ad) delete ad;
	if (NULL != sd) delete sd;
	StopServer();
	Close();
}

LRESULT
WinTCPdApp::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	if (nMsg == WM_COMMAND) {
		switch (wParam) {
		case ID_MENUITEM40001:	// �v���p�e�B
			if (NULL != sd) break;
			sd = new SettingDialog();
			if (NULL == sd) break;
			sd->Open(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG2), hWnd, CWTA_MSG_DELETE_SETTING);
			break;
		case ID_MENUITEM40002:	// ���
			if (NULL != ad) break;
			ad = new AboutDialog();
			if (NULL == ad) break;
			ad->Open(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG1), hWnd, CWTA_MSG_DELETE_ABOUT);
			break;
		case ID_MENUITEM40003:	// �L�����Z��
			break;
		case ID_MENUITEM40004:	// �I��
			PostQuitMessage(0);
			break;
		default:
			return TaskTray::WindowProc(hWnd, nMsg, wParam, lParam);
		}
		return 0;
	} else if (nMsg == CWTA_MSG_DELETE_ABOUT) {
		if (NULL != ad) {
			delete ad;
			ad = NULL;
		}
		return 0;
	} else if (nMsg == CWTA_MSG_DELETE_SETTING) {
		if (NULL != sd) {
			delete sd;
			sd = NULL;
		}
		if (0 != wParam) {
			// �ݒ�ύX
			if (!StartServer()) {
				MessageBox(NULL, "�T�[�o�[�̏������Ɏ��s���܂����B", "WinTCPd", MB_OK);
				PostQuitMessage(0);
			}
		}
		return 0;
	}	
	return TaskTray::WindowProc(hWnd, nMsg, wParam, lParam);
}

LRESULT
WinTCPdApp::TaskTrayLButtonDown
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	return MouseDown(hWnd, TPM_LEFTBUTTON);
}

LRESULT
WinTCPdApp::TaskTrayRButtonDown
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	return MouseDown(hWnd, TPM_RIGHTBUTTON);
}

LRESULT
WinTCPdApp::MouseDown
(HWND hWnd, UINT which)
{
	POINT pt;
	GetCursorPos(&pt);
	SetForegroundWindow(hWnd);
	TrackPopupMenu(hPopup, which, pt.x, pt.y, 0, hWnd, NULL);
	return 0;
}

bool
WinTCPdApp::StartServer
(void)
{
	StopServer();

	ss = new SuperServer("WinTCPd Server");

	DWORD threadId = GetCurrentThreadId();
	int port;
	GetInt(WINTCPD_REG_PORT, port, WINTCPD_DEFAULT_PORT);
	DOUT("... port %d\n", port);

	char exe[4096];
	char opt[4096];
	int size = 4096;
	GetStr(WINTCPD_REG_EXE, exe, size, WINTCPD_DEFAULT_EXE);

	size = 4096;
	GetStr(WINTCPD_REG_OPT, opt, size, WINTCPD_DEFAULT_OPT);

	if (!ss->SetServer(exe, opt) || !ss->Start(0, port, threadId, WM_QUIT)) {
		delete ss;
		ss = NULL;
		return false;
	}
	return true;
}

bool
WinTCPdApp::StopServer
(void)
{
	if (NULL != ss) {
		delete ss;
		ss = NULL;
	}
	return true;
}
