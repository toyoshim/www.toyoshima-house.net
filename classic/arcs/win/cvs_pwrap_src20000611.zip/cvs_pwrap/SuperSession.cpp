/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: SuperSession.cpp,v 1.3 2000/06/10 21:49:19 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [SuperSession.cpp]
 *   �ėp��TCP�Z�b�V�����B�\�P�b�g��W�����͂ɂ��Ďq�v���Z�X�ɓn���B
 * -------------------------------------------------------------------------------------------- */
#include "SuperSession.h"

SuperSession::SuperSession
(SOCKET sock, HWND parent, UINT message):
AsyncSocket(sock),
Spawn(),
parent(parent),
message(message)
{
}

SuperSession::~SuperSession
(void)
{
}

BOOL
SuperSession::Start
(HWND hWnd, const char *app, const char *opt)
{
	BOOL result = AsyncSocket::Start(hWnd);
	if (result) {
		SetMessage(messageHWnd, MSG_SS_SPAWN);
		if (!Execute(app, opt)) {
			char text[4096];
			snprintf(text, 4096, "\'%s %s\'�����s���悤�Ƃ��Ď��s���܂���", app, opt);
			MessageBox(NULL, text, "�q�v���Z�X�N���̎��s", MB_OK);
			DOUT("Execute failed\n");
			result = false;
		}
	}
	return result;
}

void
SuperSession::SocketRead
(char *buffer, int size)
{
	DOUT("<< ");
	DOUTRN(buffer, size);
	DOUTR("\n");
	int rest = size;
	for (;0 != rest; rest -= size) {
		if (!SpawnWrite(buffer, size)) break;
		buffer += size;
	}
}

void
SuperSession::SocketClosed
(void)
{
	DOUT("Close\n");
	PostMessage(parent, message, 0, 0);
}

void
SuperSession::Error
(int code)
{
	DOUT("ERROR: %d\n", code);
	PostMessage(parent, message, code, 0);
}

LRESULT
SuperSession::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	if (nMsg == MSG_SS_SPAWN) {
		switch (wParam) {
		case CS_MSG_DELETE_REQUEST:
			DOUT("delete request\n");
			PostMessage(parent, message, 0, 1);
			break;
		case CS_MSG_PREPARED_TO_READ:{
			char buffer[4096];
			int size = 4096;
			if (!SpawnRead(buffer, size)) break;
			DOUT(">> ");
			DOUTRN(buffer, size);
			DOUTR("\n");
			SocketWrite(buffer, size);
			break;}
		default:
			DOUT("default\n");
			break;
		}
		return 0;
	}
	return AsyncSocket::WindowProc(hWnd, nMsg, wParam, lParam);
}

