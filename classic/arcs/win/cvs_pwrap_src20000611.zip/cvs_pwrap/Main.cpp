/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: Main.cpp,v 1.3 2000/06/10 13:23:04 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [Main.cpp]
 * -------------------------------------------------------------------------------------------- */
#define	__Main__
#include "Common.h"
#undef	__Main__
#include "WinTCPdApp.h"

int WINAPI
WinMain
(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	// WinSock 1.1
	WORD wVersionRequired = MAKEWORD(1, 1);	
	WSADATA wsaData;
	if (WSAStartup(wVersionRequired, &wsaData) || (wsaData.wVersion != wVersionRequired)) {
		MessageBox(NULL, "WinSock�̏������Ɏ��s���܂����i�v������o�[�W����1.1�ɑΉ����Ă��܂���j�B", "WinTCPd", MB_OK);
		exit(1);
	}

	WinTCPdApp *app = new WinTCPdApp();
	if (NULL == app) {
		MessageBox(NULL, "�T�[�o�[�̏������Ɏ��s���܂����B", "WinTCPd", MB_OK);
		exit(1);
	}

	MSG Msg;
	while (GetMessage(&Msg, NULL, 0, 0)) {
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	if (NULL != app) delete app;

	if (WSACleanup()) exit(1);
	exit(0);
	return 0;
}
