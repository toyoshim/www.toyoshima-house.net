#!/bin/sh

for f in \
	Common.h \
	Errors.h \
	TCPServer.h \
	TCPServer.cpp \
	MessageWindow.h \
	MessageWindow.cpp \
	AsyncSocket.h \
	AsyncSocket.cpp \
	Spawn.h \
	Spawn.cpp \
	TaskTray.h \
	TaskTray.cpp \
	HashedWindowProcDivider.h \
	HashedWindowProcDivider.cpp \
	DialogWindow.h \
	DialogWindow.cpp \
	Registry.h \
	Registry.cpp \
; do
	cvs co Common/$f
done

