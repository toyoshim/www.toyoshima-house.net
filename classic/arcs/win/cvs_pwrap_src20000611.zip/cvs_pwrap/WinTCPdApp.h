/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: WinTCPdApp.h,v 1.4 2000/06/10 21:49:19 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [WinTCPdApp.h]
 * -------------------------------------------------------------------------------------------- */

#if !defined(__WinTCPdApp_h__)
#	define	__WinTCPdApp_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__TaskTray_h__)
#		include "TaskTray.h"
#	endif	// !defined(__TaskTray_h__)

#	if !defined(__Registry_h__)
#		include "Registry.h"
#	endif	// !defined(__Registry_h__)

#	if !defined(__SuperServer__)
class SuperServer;
#		define	__SuperServer__
#	endif	// !defined(__SuperServer__)

#	if !defined(__AboutDialog__)
class AboutDialog;
#		define	__AboutDialog__
#	endif	// !defined(__AboutDialog__)

#	if !defined(__SettingDialog__)
class SettingDialog;
#		define	__SettingDialog__
#	endif	// !defined(__SettingDialog__)

class WinTCPdApp: public TaskTray, private Registry{
#	define	CWTA_MSG_TOP			(WM_USER + 700)
#	define	CWTA_MSG_DELETE_ABOUT	(CWTA_MSG_TOP + 0)
#	define	CWTA_MSG_DELETE_SETTING	(CWTA_MSG_TOP + 1)
private:
	HICON hIcon;
	HMENU hMenu;
	HMENU hPopup;
	SuperServer *ss;
	AboutDialog *ad;
	SettingDialog *sd;
public:
	WinTCPdApp(void);
	~WinTCPdApp(void);

	LRESULT WindowProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);	// TaskTray
	LRESULT TaskTrayLButtonDown(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);	// TaskTray
	LRESULT TaskTrayRButtonDown(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);	// TaskTray
private:
	LRESULT MouseDown(HWND hWnd, UINT which);

	bool StartServer(void);
	bool StopServer(void);
};

#	if !defined(__WinTCPdApp__)
#		define	__WinTCPdApp__
#	endif	// !defined(__WinTCPdApp__)

#endif	// !defined(__WinTCPdApp_h__)
