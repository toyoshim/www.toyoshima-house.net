/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: regname.h,v 1.1 2000/06/10 21:49:19 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [regname.h]
 * -------------------------------------------------------------------------------------------- */

#if !defined(__regname_h__)
#	define	__regname_h__

#	define	WINTCPD_REG_ROOT		"Software\\Sasami-chan\\WinTCPd"

#	define	WINTCPD_REG_PORT		"port"
#	define	WINTCPD_REG_EXE			"cvs"
#	define	WINTCPD_REG_OPT			"command line"
#	define	WINTCPD_REG_OFN			"ofn"

#endif	// !defined(__regname_h__)
