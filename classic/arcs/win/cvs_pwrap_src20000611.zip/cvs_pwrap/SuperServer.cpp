/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: SuperServer.cpp,v 1.2 2000/06/10 21:49:19 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [SuperServer.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "SuperServer.h"
#include "SuperSession.h"

SuperServer::SuperServer
(const char *name):
TCPServer(name),
ss(NULL),
app(NULL),
opt(NULL)
{
}

SuperServer::~SuperServer
(void)
{
	if (NULL != ss) delete ss;
	if (NULL != app) free(app);
	if (NULL != opt) free(opt);
}

BOOL
SuperServer::SetServer
(const char *app, const char *opt)
{
	if (NULL != this->app) free(this->app);
	if (NULL != this->opt) free(this->opt);
	this->app = strdup(app);
	this->opt = strdup(opt);
	return ((NULL != this->app) && (NULL != this->opt));
}

LRESULT
SuperServer::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
	DOUT("*** %08X %08X %08X %08X\n", hWnd, nMsg, wParam, lParam);
	if (nMsg == MSG_DELETE_REQUEST) {
		DOUT("DELETE REQUEST\n");
		if (NULL != ss) {
			delete ss;
			ss = NULL;
		}
		return 0;
	}
	return TCPServer::WindowProc(hWnd, nMsg, wParam, lParam);
}

void
SuperServer::Accept
(SOCKET server)
{
	DOUT("Accept\n");
	SOCKADDR addr;
	int addrlen = sizeof(SOCKADDR);
	SOCKET s = accept(server, &addr, &addrlen);
	if (INVALID_SOCKET == s) {
		DOUT("invalid socket\n");
		return;
	}
	if (NULL != ss) {
		DOUT("max session\n");
		if (0 != closesocket(s)) DOUT("close failed\n");
		return;
	}
	ss = new SuperSession(s, messageHWnd, MSG_DELETE_REQUEST);
	if (NULL == ss) {
		DOUT("new SuperSession(%d) failed\n", s);
		return;
	}
	if (!ss->Start(messageHWnd, app, opt)) {
		DOUT("can not start session\n");
		delete ss;
		ss = NULL;
	}
}
