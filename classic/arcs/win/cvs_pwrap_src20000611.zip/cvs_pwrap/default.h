/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: default.h,v 1.1 2000/06/10 18:20:43 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [default.h]
 * -------------------------------------------------------------------------------------------- */

#if !defined(__default_h__)
#	define	__default_h__

#	define	WINTCPD_DEFAULT_PORT	2401
#	define	WINTCPD_DEFAULT_EXE		"cvs_pserver.exe"
#	define	WINTCPD_DEFAULT_OPT		"--allow-root=//CHIYO/cvsroot -d //CHIYO/cvsroot pserver"

#endif	// !defined(__default_h__)
