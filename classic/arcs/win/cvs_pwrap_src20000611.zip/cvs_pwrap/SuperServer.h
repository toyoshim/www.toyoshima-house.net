/* --------------------------------------------------------------------------------------------
 *  WinTCPd - Tiny TCP daemon for Win32
 *  (C) 2000 �Ƃ悵��
 *  $Id: SuperServer.h,v 1.2 2000/06/10 21:49:19 ai7t-tysm Exp $
 * --------------------------------------------------------------------------------------------
 *  [SuperServer.h]
 *   �ėpTCP�T�[�o�[�BUNIX��inetd�̂悤�ȋ@�\���������Ă���B
 * -------------------------------------------------------------------------------------------- */

#if !defined(__SuperServer_h__)
#	define	__SuperServer_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__TCPServer_h__)
#		include "TCPServer.h"
#	endif	// !defined(__TCPServer_h__)

#	if !defined(__SuperSession__)
class SuperSession;
#		define	__SuperSession__
#	endif	// !defined(__SuperSession__)

class SuperServer: public TCPServer{
#	define	MSG_SUPERSERVER_TOP	(WM_USER + 200)
#	define	MSG_DELETE_REQUEST	(MSG_SUPERSERVER_TOP + 0)
private:
	SuperSession *ss;
	char *app;
	char *opt;
public:
	SuperServer(const char *name = NULL);
	virtual ~SuperServer(void);
	BOOL SetServer(const char *app, const char *opt);

protected:
	virtual LRESULT WindowProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);
private:
	virtual void Accept(SOCKET server);
};

#	if !defined(__SuperServer__)
#		define	__SuperServer__
#	endif	// !defined(__SuperServer__)

#endif	// !defined(__SuperServer_h__)
