#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

extern const char *crypt(const char *key, const char *setting);

int
main
(int argc, char **argv)
{
	const char *passwd;

	if (argc < 2) {
		puts("Usage: md5passwd <username>\n");
		exit(1);
	}
	passwd = getpass("Password: ");
	passwd = crypt(passwd, NULL);
	printf("%s:%s\n", argv[1], passwd);
	
	exit(0);
	return 0;
}
