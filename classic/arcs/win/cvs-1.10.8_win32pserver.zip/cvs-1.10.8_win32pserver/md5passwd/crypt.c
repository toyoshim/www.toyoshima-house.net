#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "md5.h"

const char *crypt(const char *key, const char *setting)
{
	struct cvs_MD5Context ctx;
	unsigned char sum[16];
	static char digest[33];
	char *p;
	int i;

	cvs_MD5Init (&ctx);
	cvs_MD5Update (&ctx, key, strlen(key));
	cvs_MD5Final (sum, &ctx);
	for (p = digest, i = 0; i < 16; i++, p += 2)
	{
		sprintf (p, "%02x", sum[i]);
	}
	return digest;
}

