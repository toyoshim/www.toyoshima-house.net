#ifndef __PROCESS_H__
#define	__PROCESS_H__

#ifndef __I86INFO_H__
#include "i86info.h"
#endif /* __I86INFO_H__ */

typedef struct {
	i86_Regs regs;
	int psp_seg;
	int text_seg;	/* psp + 0x10 */
	int env_seg;
} process_info;

process_info *process_open(const char *name, int env_seg, const unsigned char *cmd);

#endif /* __PROCESS_H__ */

