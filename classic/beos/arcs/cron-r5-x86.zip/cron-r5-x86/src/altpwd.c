#include <stdio.h>
#include <stdlib.h>
#include <pwd.h>
#include <sys/types.h>
#include <syslog.h>

struct passwd *
_getpwnam(const char *name)
{
	struct passwd *p;
	setpwent();
	p = getpwent();
	if ((NULL != p) && (0 == strcmp(name, p->pw_name))) return p;
	return NULL;
}

struct passwd *
_getpwuid(uid_t uid)
{
	struct passwd *p;
	setpwent();
	p = getpwent();
	if ((NULL != p) && (uid == p->pw_uid)) return p;
	return NULL;
}


