#define getpwnam(x)	_getpwnam(x)
#define	getpwuid(x)	_getpwuid(x)

extern struct passwd *_getpwnam(const char *name);
extern struct passwd *_getpwuid(uid_t uid);
