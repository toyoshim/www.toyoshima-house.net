less version 332+iso248

日本語対応lessですが、UTF-8に対応していたりはしません。
とってきてコンパイルしただけ。
LESSCHARSET=japanese-jis
とかしておくと、MuTermならどのモードでも表示できて
便利かもしれません。
