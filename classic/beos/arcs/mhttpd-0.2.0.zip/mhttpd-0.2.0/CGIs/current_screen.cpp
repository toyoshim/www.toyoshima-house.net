#include <Be.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/*
 * CGIとしてそのまま実行すると環境変数の問題で変換に失敗する。引数でリサイズできるので、以下のような
 * スクリプトを挟むと良い。
 * #/bin/sh
 * export ADDON_PATH='%A:/add-ons:/boot/home/config/add-ons:/boot/beos/system/add-ons'
 * export LIBRARY_PATH='/boot/beos/system/lib:/boot/home/config/lib'
 * /boot/home/public_html/cgi-bin/current_screen 640 480
 * exit "$?"
 *
 * $Id: current_screen.cpp,v 1.2 2000/10/13 08:25:01 toyoshim Exp $
 */

int
main
(int argc, char **argv)
{
	int width;
	int height;
	bool resize = true;
	bool debug = false;
	if (argc == 2) {
		width = atoi(argv[1]);
		height = (int)((double)width * 3.0 / 4.0) - 1;
		width--;
	} else if (argc > 2) {
		width = atoi(argv[1]) - 1;
		height = atoi(argv[2]) - 1;
		if ((argc > 3) && (0 == strcmp(argv[3], "debug"))) debug = true;
	} else {
		resize = false;
	}
	BApplication app("application/x-vnd.toyoshima-house.current_screen");
	try {
		// Get Screen-Shot
		BScreen bscr;
		BBitmap *bbmp;
		bscr.GetBitmap(&bbmp, true);
		if (NULL == bbmp) throw "can not get sccreen shot";

		// Resize
		BBitmap *bbmp_s;
		if (resize) {
			bbmp_s = new BBitmap(BRect(0, 0, width, height), bbmp->ColorSpace(), true);
			if (NULL == bbmp_s) throw "can not create bbitmap";
			BView *bv = new BView(BRect(0, 0, width, height), "", B_FOLLOW_NONE, 0);
			if (NULL == bv) throw "can not create bview";
			bbmp_s->AddChild(bv);
			bbmp_s->Lock();
			bv->DrawBitmap(bbmp, bbmp->Bounds(), bbmp_s->Bounds());
			bbmp_s->Unlock();
		} else {
			bbmp_s = bbmp;
		}

		// BBitmap to JPEG conversion
		BBitmapStream *bbs = new BBitmapStream(bbmp_s);
		if (NULL == bbs) throw "can not create bbitmapstream";
		BMallocIO bmio;
		BTranslatorRoster *roster = BTranslatorRoster::Default();
		if (NULL == roster) throw "can not get default roster";
		status_t rc = roster->Translate(bbs, NULL, NULL, &bmio, B_JPEG_FORMAT);
		if (rc != B_OK) throw "translate failed";

		// Output Data
		const char *buf = (const char *)bmio.Buffer();
		size_t len = bmio.BufferLength();
		if (NULL == buf) throw "can not get io buffer";
		if (!debug) {
			puts("Status: 200 OK\r");
			puts("Content-Type: image/jpeg\r");
			puts("\r");
			//printf("Content-Length: %d\r\n\r\n", len);
			fflush(stdout);
		}
		int wsize = fwrite(buf, 1, len, stdout);
		if (wsize != len) throw "write failed";
	} catch (const char *e) {
		// operation failed
		puts("Status: 500 Internal Error");
		puts("Content-Type: text/html\n");
		puts("<html><head><title>500 Internal Server Error</title></head><body><h1>operation failed</h1>");
		fflush(stdout);
		dup2(1,2);
		perror(e);
		puts("</body></html>");
	}
	return 0;
}

