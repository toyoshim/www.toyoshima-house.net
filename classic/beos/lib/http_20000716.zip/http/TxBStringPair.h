/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBStringPair.h,v 1.2 2000/07/15 23:26:42 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBStringPair.h]
 *   文字列の対を表現します。
 * -------------------------------------------------------------------------------------------- */

#if !defined(__TxBStringPair_h__)
#	define __TxBStringPair_h__

#	include <Be.h>

class TxBStringPair{
private:
	int *refCount;
	char *name;
	char *value;
public:
	TxBStringPair(const char *name, const char *value);
	TxBStringPair(const TxBStringPair &anotherPair);
	~TxBStringPair(void);
	
	const char *GetName(void) const;
	const char *GetValue(void) const;
};

#	if !defined(__TxBStringPair__)
#		define __TxBStringPair__
#	endif	// !defined(__TxBStringPair__)

#endif	// !defined(__TxBStringPair_h__)
