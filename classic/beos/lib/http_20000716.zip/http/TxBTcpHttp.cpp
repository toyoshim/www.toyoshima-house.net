/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBTcpHttp.cpp,v 1.4 2000/07/16 08:51:43 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBTcpHttp.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "TxBTcpHttp.h"
#include "TxBStringPair.h"
#include "TxBStringPairList.h"
#include <errno.h>

TxBTcpHttp::TxBTcpHttp
(BLooper *receiver):
headers(NULL),
responseHeaders(NULL),
userAgent(NULL),
receiver(receiver),
body(NULL),
bodySize(0),
socketThread(-1),
sock(-1),
responseStatus(-1),
contentLength(-1),
readableLength(0),
readPointer(0),
canReadPointer(0),
fWaitHeader(false),
fCompleteHeader(false)
{
}

TxBTcpHttp::~TxBTcpHttp
(void)
{
	if (NULL != userAgent) free(userAgent);
	if (NULL != headers) delete headers;
	if (NULL != body) delete body;
	if (socketThread >= B_OK) ThreadStop();
}

status_t
TxBTcpHttp::SetUserAgent
(const char *name)
{
	lockHeader.Lock();
	if (NULL != userAgent) free(userAgent);
	userAgent = strdup(name);
	lockHeader.Unlock();
	return (NULL != userAgent)? B_OK: B_NO_MEMORY;
}

status_t
TxBTcpHttp::SetExtraHeader
(const char *name, const char *value)
{
	if ((NULL == name) || (NULL == value)) return B_BAD_VALUE;
	return SetExtraHeader(TxBStringPair(name, value));
}

status_t
TxBTcpHttp::SetExtraHeader
(const TxBStringPair pair)
{
	lockHeader.Lock();
	if (NULL == headers) {
		headers = new TxBStringPairList();
		if (NULL == headers) {
			lockHeader.Unlock();
			return B_NO_MEMORY;
		}
	}
	TxBStringPair *newPair = new TxBStringPair(pair);
	if (NULL == newPair) {
		lockHeader.Unlock();
		return B_NO_MEMORY;
	}
	if (headers->AddItem(newPair)) {
		lockHeader.Unlock();
		return B_OK;
	}
	lockHeader.Unlock();
	delete newPair;
	return B_NO_MEMORY;
}

status_t
TxBTcpHttp::SetExtraHeaders
(const TxBStringPairList *list)
{
	if (NULL == list) return B_BAD_VALUE;
	lockHeader.Lock();
	if (NULL == headers) {
		headers = new TxBStringPairList();
		if (NULL == headers) {
			lockHeader.Unlock();
			return B_NO_MEMORY;
		}
	}
	if (headers->AddList((BList *)list)) {
		lockHeader.Unlock();
		return B_OK;
	}
	lockHeader.Unlock();
	return B_NO_MEMORY;
}

status_t
TxBTcpHttp::SetBody
(const void *buffer, size_t size)
{
	lockHeader.Lock();
	if (NULL != body) delete body;
	body = new char[size];
	if (NULL == body) {
		lockHeader.Unlock();
		return B_NO_MEMORY;
	}
	bodySize = size;
	memcpy(body, buffer, size);
	lockHeader.Unlock();
	return B_OK;
}

status_t
TxBTcpHttp::SetServer
(const char *server, short port)
{
	lockAddress.Lock();
	status_t rc = address.SetTo(server, port);
	lockAddress.Unlock();
	return rc;
}

status_t
TxBTcpHttp::SetServer
(unsigned long s_addr, short port)
{
	struct sockaddr_in sa;
	
	memset(&sa, 0, sizeof(struct sockaddr_in));
	sa.sin_family = AF_INET;
	sa.sin_port = htons(port);
	*(unsigned long *)(&sa.sin_addr) = htonl(s_addr);

	lockAddress.Lock();
	status_t rc = address.SetTo(sa);
	lockAddress.Unlock();
	return rc;
}

status_t
TxBTcpHttp::Get
(const char *path)
{
	if (socketThread >= B_OK) ThreadStop();
	responseStatus = -1;
	contentLength = -1;
	readableLength = 0;
	readPointer = 0;
	canReadPointer = 0;
	fWaitHeader = false;
	fCompleteHeader = false;
	if (!waitHeader.IsLocked()) waitHeader.Lock();
	if (!waitBody.IsLocked()) waitBody.Lock();
	if (NULL != responseHeaders) {
		delete responseHeaders;
		responseHeaders = NULL;
	}
	buffer.SetSize(0);
	if (NULL != body) {
		delete body;
		body = NULL;
	}
	bodySize = 0;
	request = "GET ";
	request += path;
	request += " HTTP/1.0\r\n";
	socketThread = spawn_thread(ThreadMain, "HTTP Socket", suggest_thread_priority(), (void *)this);
	if (socketThread < B_OK) return socketThread;	// Error Code
	return resume_thread(socketThread);
}

status_t
TxBTcpHttp::Post
(const char *path)
{
	return B_ERROR;	// Not Implemented.
}

int
TxBTcpHttp::GetStatus
(void) const
{
	((TxBTcpHttp *)this)->lockBuffer.Lock();
	int rc = responseStatus;
	((TxBTcpHttp *)this)->lockBuffer.Unlock();
	return rc;
}

const char *
TxBTcpHttp::GetHeader
(const char *name) const
{
	((TxBTcpHttp *)this)->lockBuffer.Lock();
	TxBStringPair *item;
	for (int i = 0; (NULL != (item = (TxBStringPair *)responseHeaders->ItemAt(i))) && fCompleteHeader; i++) {
		if (NULL == item) {
			((TxBTcpHttp *)this)->fWaitHeader = true;
			((TxBTcpHttp *)this)->lockBuffer.Unlock();
			((TxBTcpHttp *)this)->waitHeader.Lock();	// block
			((TxBTcpHttp *)this)->lockBuffer.Lock();
			item = (TxBStringPair *)responseHeaders->ItemAt(i);
			if (NULL == item) break;
		}
		if (0 == strcmp(item->GetName(), name)) {
			((TxBTcpHttp *)this)->lockBuffer.Unlock();
			return item->GetValue();
		}
	}
	((TxBTcpHttp *)this)->lockBuffer.Unlock();
	return NULL;	// Not fond
}

const TxBStringPairList *
TxBTcpHttp::GetHeaders
(void) const
{
	((TxBTcpHttp *)this)->lockBuffer.Lock();
	while (!fCompleteHeader) {
		((TxBTcpHttp *)this)->lockBuffer.Unlock();
		((TxBTcpHttp *)this)->waitHeader.Lock();	// block
		((TxBTcpHttp *)this)->lockBuffer.Lock();
	}
	((TxBTcpHttp *)this)->lockBuffer.Unlock();
	return responseHeaders;
}

status_t
TxBTcpHttp::AsyncRead
(void *buffer, size_t &buffer_size)
{
	lockBuffer.Lock();
	if (readableLength <= readPointer) {
		canReadPointer = readPointer;
		lockBuffer.Unlock();
		return B_WOULD_BLOCK;
	}
	int readsize = buffer_size;
	if (readsize > (readableLength - readPointer)) readsize = readableLength - readPointer;
	status_t rc = this->buffer.ReadAt(readPointer, buffer, readsize);
	readPointer += readsize;
	buffer_size = readsize;
	lockBuffer.Unlock();
	if (rc < B_OK) return rc;
	return B_OK;
}

status_t
TxBTcpHttp::AsyncCancelRead
(void)
{
	lockBuffer.Lock();
	canReadPointer = 0;
	lockBuffer.Unlock();
	return B_OK;
}

ssize_t
TxBTcpHttp::Read
(void *buf, size_t size)
{
	lockBuffer.Lock();
	ssize_t rc = _ReadAt(readPointer, buf, size);
	lockBuffer.Unlock();
	return rc;
}

ssize_t
TxBTcpHttp::ReadAt
(off_t pos, void *buf, size_t size)
{
	lockBuffer.Lock();
	ssize_t rc = _ReadAt(readPointer, buf, size);
	lockBuffer.Unlock();
	return rc;
}

off_t
TxBTcpHttp::Seek
(off_t position, uint32 seek_mode)
{
	lockBuffer.Lock();
	switch (seek_mode) {
	case SEEK_SET:
		readPointer = position;
		break;
	case SEEK_CUR:
		readPointer += position;
		break;
	case SEEK_END:
		if (contentLength < 0) {
			if (!fCompleteHeader) {
				// blocking wait for reading header
				fWaitHeader = true;
				lockBuffer.Unlock();
				waitHeader.Lock();	// block
				lockBuffer.Lock();
			}
			while (contentLength < 0) {
				// blocking wait for reading body
				lockBuffer.Unlock();
				waitBody.Lock();	// block
				lockBuffer.Lock();
			}
		}
		readPointer = contentLength + position;
		break;
	default:
		lockBuffer.Unlock();
		return B_ERROR;
	}
	lockBuffer.Unlock();
	return readPointer;
}

off_t
TxBTcpHttp::Position
(void) const
{
	int position;
	((TxBTcpHttp *)this)->lockBuffer.Lock();
	position = readPointer;
	((TxBTcpHttp *)this)->lockBuffer.Unlock();
	return position;
}

void
TxBTcpHttp::ThreadStop
(void)
{
	// anti dead lock
	lockAddress.Lock();
	lockBuffer.Lock();
	lockSocket.Lock();
	lockHeader.Lock();
	lockMessage.Lock();
	
	// kill socket thread
	kill_thread(socketThread);
	
	lockAddress.Unlock();
	lockBuffer.Unlock();
	lockSocket.Unlock();
	lockHeader.Unlock();
	lockMessage.Unlock();
	
	socketThread = -1;
	
	// close socket
	if (sock >= B_OK) {
		closesocket(sock);
		sock = -1;
	}
}

int32
TxBTcpHttp::ThreadMain
(void *data)
{
	TxBTcpHttp *object = (TxBTcpHttp *)data;
	if (NULL == object) exit_thread(B_BAD_VALUE);
	
	// create socket
	object->lockSocket.Lock();
	int sock = object->sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < B_OK) exit_thread(errno);
	object->lockSocket.Unlock();

	// server address
	object->lockAddress.Lock();
	struct sockaddr_in sa;
	status_t rc = object->address.GetAddr(sa);
	object->lockAddress.Unlock();
	if (B_OK != rc) {
		// failure
		object->PostErrorMessage(rc, "NetAddress.GetAddr(): failed");
		exit_thread(rc);
	}
	// message: host resolved
	object->lockMessage.Lock();
	BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
	msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_HOST_RESOLVED);
	msg->AddInt32(TxB_HTTP_NOTIFY_ADDRESS, ntohl(*(unsigned long *)&sa.sin_addr));
	msg->AddInt16(TxB_HTTP_NOTIFY_PORT, ntohs(sa.sin_port));
	object->PostMessage(msg);
	delete msg;
	object->lockMessage.Unlock();
	
	// connect
	rc = connect(sock, (struct sockaddr *)&sa, sizeof(struct sockaddr_in));
	if (B_OK != rc) {
		// failure
		object->PostErrorMessage(rc, "connect(): fauled");
		exit_thread(rc);
	}
	// message: connected
	object->lockMessage.Lock();
	msg = new BMessage(TxB_HTTP_NOTIFY);
	msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_CONNECTED);
	object->PostMessage(msg);
	delete msg;
	object->lockMessage.Unlock();

	// generate request
	object->lockHeader.Lock();
	if (NULL != object->userAgent) {
		object->request += "User-Agent: ";
		object->request += object->userAgent;
		object->request += "\r\n";
	}
	if (NULL != object->headers) {
		TxBStringPair *item;
		for (int i = 0; NULL != (item = (TxBStringPair *)object->headers->ItemAt(i)); i++) {
			object->request += item->GetName();
			object->request += ": ";
			object->request += item->GetValue();
			object->request += "\r\n";
		}
	}
	object->request += "\r\n";
	object->lockHeader.Unlock();
	
	// send request
	const char *request = object->request.String();
	const char *requestEnd = request + object->request.Length();
	do {
		rc = send(sock, request, requestEnd - request, 0);
		if (rc < 0) {
			// failure
			object->PostErrorMessage(errno, "send(): fauled");
			exit_thread(errno);
		}
		request += rc;
	} while (request != requestEnd);

	// receive response
	char buffer[4097];
	char *readptr = buffer;
	int state = 0;
	do {
		rc = recv(sock, readptr, 4096 - (readptr - buffer), 0);
		if (rc < 0) {
			// failure
			object->PostErrorMessage(errno, "recv(): failed");
			exit_thread(errno);
		}
		if (rc == 0) {
			// end
			int length;
			object->lockBuffer.Lock();
			if (object->contentLength < 0) object->contentLength = object->readableLength;
			object->waitBody.Unlock();
			length = object->contentLength;
			object->lockBuffer.Unlock();
			object->lockMessage.Lock();
			BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
			msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_COMPLETE);
			msg->AddInt32(TxB_HTTP_NOTIFY_LENGTH, length);
			object->PostMessage(msg);
			object->lockMessage.Unlock();
			exit_thread(B_OK);
		}
		readptr[rc] = 0;
		char *p = buffer;
		switch (state) {
		case 0:{	// status
			char *end = strstr(p, "\r\n");
			if (NULL == end) {
				readptr += rc;
				break;
			}
			*end = 0;
			if (((end - p) < 10) || (0 != strncmp("HTTP/1.", p, 7)) ||
					((p[7] != '0') && (p[7] != '1')) || (p[8] != ' ')) {
				// invalid status
				object->PostErrorMessage(B_ERROR, "Invalid response status header");
				exit_thread(B_ERROR);
			}
			int code = 0;
			int o;
			for (o = 9; ('0' <= p[o]) && (p[o] <= '9'); o++) {
				code *= 10;
				code += p[o] - '0';
			}
			o++;
			object->lockBuffer.Lock();
			object->responseStatus = code;
			object->lockBuffer.Unlock();
			
			// message: status
			object->lockMessage.Lock();
			BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
			msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_STATUS);
			msg->AddInt16(TxB_HTTP_NOTIFY_STATUS, code);
			msg->AddString(TxB_HTTP_NOTIFY_MESSAGE, &p[o]);
			object->PostMessage(msg);
			delete msg;
			object->lockMessage.Unlock();
			state++;
			p = end + 2;}
		case 1:	// header
			for (;;) {
				char *end = strstr(p, "\r\n");
				if (NULL == end) break;
				if (p == end) {
					// header end
					p += 2;
					state++;
					
					object->lockBuffer.Lock();
					object->fCompleteHeader = true;
					if (object->fWaitHeader) {
						object->fWaitHeader = false;
						object->waitHeader.Unlock();	// blocking release
					}
					object->lockBuffer.Unlock();
					
					// message: header complete
					object->lockMessage.Lock();
					BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
					msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_HEADER_COMPLETE);
					object->PostMessage(msg);
					delete msg;
					object->lockMessage.Unlock();
					break;
				}
				char *name_end = strpbrk(p, " :");
				char *value;
				char *value_end = NULL;
				if (NULL != name_end) {
					value = name_end;
					if (' ' == *value) value++;
					if (':' == *value) {
						value++;
						if (' ' == *value) value++;
						value_end = end;
					}
				}
				if (NULL == value_end) {
					// message: invalid header line
					object->PostErrorMessage(B_ERROR, "Invalid response header");
					exit_thread(B_ERROR);
				}
				*name_end = 0;
				*value_end = 0;
				// header append
				object->lockBuffer.Lock();
				if (NULL == object->responseHeaders) {
					object->responseHeaders = new TxBStringPairList();
					if (NULL == object->responseHeaders) {
						object->lockBuffer.Unlock();
						object->PostErrorMessage(B_NO_MEMORY, "new TxBStringPairList(): failed");
						exit_thread(B_NO_MEMORY);
					}
					TxBStringPair *pair = new TxBStringPair(p, value);
					if ((NULL == pair) || !object->responseHeaders->AddItem((void *)pair)) {
						// failure
						if (NULL != pair) delete pair;
						object->lockBuffer.Unlock();
						object->PostErrorMessage(B_NO_MEMORY, "TxBStringPairList::AddItem(): fauled");
						exit_thread(B_NO_MEMORY);
					}
				}
				if (object->fWaitHeader) {
					object->fWaitHeader = false;
					object->waitHeader.Unlock();	// blocking release
				}
				if (0 == strcasecmp("content-length", p)) {
					// Content-Length
					int length = object->contentLength = atoi(value);
					object->buffer.SetSize(length);
					object->lockBuffer.Unlock();
					object->lockMessage.Lock();
					BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
					msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_CONTENT_LENGTH);
					msg->AddInt32(TxB_HTTP_NOTIFY_LENGTH, length);
					object->PostMessage(msg);
					delete msg;
					object->lockMessage.Unlock();
				} else {
					object->lockBuffer.Unlock();
				}
				p = end + 2;
			}
			if (1 == state) {
				if (p == (readptr + rc)) readptr = buffer;
				else {
					int size = p - (readptr + rc);
					memmove(buffer, p, size);
					readptr = buffer + size;
				}
				break;
			}
		case 2:{	// body
			int length = readptr + rc - p;
			object->lockBuffer.Lock();
			object->buffer.WriteAt(object->readableLength, p, length);
			int currentLength = object->readableLength += length;
			int contentLength = object->contentLength;
			object->lockBuffer.Unlock();
			object->lockMessage.Lock();
			BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
			msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_BUFFER_CHANGED);
			msg->AddInt32(TxB_HTTP_NOTIFY_NEWBY, length);
			msg->AddInt32(TxB_HTTP_NOTIFY_CURRENT, currentLength);
			msg->AddInt32(TxB_HTTP_NOTIFY_LENGTH, contentLength);
			object->PostMessage(msg);
			delete msg;
			object->lockMessage.Unlock();
			object->lockBuffer.Lock();
			
			// Async read notify
			if ((object->canReadPointer > 0) && (object->canReadPointer < currentLength)) {
				object->canReadPointer = 0;
				object->lockBuffer.Unlock();
				object->lockMessage.Lock();
				BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
				msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_CAN_READ);
				object->PostMessage(msg);
				delete msg;
				object->lockMessage.Unlock();
			} else {
				object->lockBuffer.Unlock();
			}
			break;}
		}
		if (4096 == (readptr - buffer)) {
			// buffer full.
			object->PostErrorMessage(B_ERROR, "Header buffer full(invalid response header)");
			exit_thread(B_ERROR);
		}
	} while (1);
	
	return B_OK;
}

void
TxBTcpHttp::PostErrorMessage
(status_t code, const char *message)
{
	lockMessage.Lock();
	BMessage *msg = new BMessage(TxB_HTTP_NOTIFY);
	msg->AddInt8(TxB_HTTP_NOTIFY_TYPE, TxB_HTTP_ERROR);
	msg->AddInt32(TxB_HTTP_NOTIFY_ERRNO, code);
	msg->AddString(TxB_HTTP_NOTIFY_MESSAGE, message);
	PostMessage(msg);
	delete msg;
	lockMessage.Unlock();
}

void
TxBTcpHttp::PostMessage
(BMessage *msg)
{
	msg->AddPointer(TxB_HTTP_NOTIFY_WHO, this);
	if (NULL != receiver) receiver->PostMessage(msg);
}

ssize_t
TxBTcpHttp::_ReadAt
(off_t pos, void *buf, size_t size)
{
	while (((pos + size) > (size_t)readableLength) && (contentLength != readableLength)) {
		// block
		lockBuffer.Unlock();
		waitBody.Lock();
		lockBuffer.Lock();
	}
	if ((contentLength > 0) && ((pos + size) > (size_t)contentLength)) size = contentLength - pos;
	ssize_t rc = buffer.ReadAt(pos, buf, size);
	readPointer = pos + rc;
	return rc;
}
