#include <Be.h>
#include "TxBTcpHttp.h"

// 同期モデル
class MyApp2: public BApplication{
public:
	MyApp2(void): BApplication("application/x-vnd.toyoshima-house.http_test2") {
	};
	virtual void ReadyToRun(void) {
		TxBTcpHttp *http = new TxBTcpHttp();
		http->SetUserAgent("HTTP Test Client / BeOS");
		http->SetServer("www.tk.xaxon.ne.jp", 80);
		http->Get("/~toyoshim/cg/title_mai.jpg");
		
		BWindow *win = new BWindow(BRect(100, 100, 100 + 320, 100 + 240), "HTTP TEST 2", B_TITLED_WINDOW, B_NOT_RESIZABLE);
		BView *view = new BView(win->Bounds(), "graphic", B_FOLLOW_ALL_SIDES, B_WILL_DRAW);
		win->AddChild(view);
		BBitmap *bmp = BTranslationUtils::GetBitmap(http);	// BPosionIOとしてTranslatorにぶち込む
		delete http;
		view->SetViewBitmap(bmp);
		win->Show();
	};
};

int
main(int argc, char **argv)
{
	MyApp2 app;
	
	return app.Run();
}
