/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBStringPairList.cpp,v 1.2 2000/07/15 23:26:42 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBStringPairList.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "TxBStringPairList.h"

TxBStringPairList::TxBStringPairList
(int32 count):
BList(count)
{
	refCount = new int();
	if (NULL != refCount) *refCount = 1;
}

TxBStringPairList::TxBStringPairList
(const TxBStringPairList &anotherList):
BList(anotherList)
{
	refCount = anotherList.refCount;
	if (NULL == refCount) return;
	*refCount += 1;
}

TxBStringPairList::~TxBStringPairList
(void)
{
	if (NULL == refCount) return;
	*refCount -= 1;
	if (0 != *refCount) return;
	
	void *item;
	for (int i = 0; item = ItemAt(i); i++) delete item;
}
