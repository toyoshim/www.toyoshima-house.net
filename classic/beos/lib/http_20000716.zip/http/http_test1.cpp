#include <Be.h>
#include "TxBTcpHttp.h"

// 非同期モデル
class MyApp: public BApplication{
private:
	TxBTcpHttp *http;
public:
	MyApp(void):
		BApplication("application/x-vnd.toyoshima-house.http_test1"),
		http(NULL) {
	};
	~MyApp(void) {
		if (NULL != http) delete http;
	}
	virtual void ReadyToRun(void) {
		http = new TxBTcpHttp(this);
		http->SetUserAgent("HTTP Test Client / BeOS");
		http->SetServer("www.be.com", 80);
		http->Get("/");
	};
	virtual void DispatchMessage(BMessage *msg, BHandler *target) {
		switch (msg->what) {
		case TxB_HTTP_NOTIFY:
			int8 type;
			if (B_OK != msg->FindInt8(TxB_HTTP_NOTIFY_TYPE, &type)) break;
			switch (type) {
			case TxB_HTTP_ERROR:{
				int32 code;
				const char *str;
				msg->FindInt32(TxB_HTTP_NOTIFY_ERRNO, &code);
				msg->FindString(TxB_HTTP_NOTIFY_MESSAGE, &str);
				printf("Error %d: %s\n", code, str);
				Quit();}
			case TxB_HTTP_HOST_RESOLVED:{
				int32 addr;
				int16 port;
				msg->FindInt32(TxB_HTTP_NOTIFY_ADDRESS, &addr);
				msg->FindInt16(TxB_HTTP_NOTIFY_PORT, &port);
				printf("Connecting %d.%d.%d.%d:%d ... ", (addr >> 24) & 0xff, (addr >> 16) & 0xff,
						(addr >> 8) & 0xff, addr & 0xff, port);
				fflush(stdout);
				break;}
			case TxB_HTTP_CONNECTED:
				puts("Connected");
				break;
			case TxB_HTTP_STATUS:{
				int16 status;
				const char *str;
				msg->FindInt16(TxB_HTTP_NOTIFY_STATUS, &status);
				msg->FindString(TxB_HTTP_NOTIFY_MESSAGE, &str);
				printf("Status: %d %s\n", status, str);
				break;}
			case TxB_HTTP_HEADER_COMPLETE:
				puts("Header Complete");
				break;
			case TxB_HTTP_CONTENT_LENGTH:{
				int32 length;
				msg->FindInt32(TxB_HTTP_NOTIFY_LENGTH, &length);
				printf("Content-Length: %d\n", length);
				break;}
			case TxB_HTTP_COMPLETE:{
				int32 length;
				msg->FindInt32(TxB_HTTP_NOTIFY_LENGTH, &length);
				printf("Complete: %d\n", length);
				char *buffer = new char[length + 1];
				size_t slen = length;
				if (NULL != buffer) {
					http->AsyncRead(buffer, slen);
					buffer[length] = 0;
					puts(buffer);
				}
				Quit();}
			case TxB_HTTP_BUFFER_CHANGED:{
				int32 newby;
				int32 current;
				int32 length = -1;
				msg->FindInt32(TxB_HTTP_NOTIFY_NEWBY, &newby);
				msg->FindInt32(TxB_HTTP_NOTIFY_CURRENT, &current);
				msg->FindInt32(TxB_HTTP_NOTIFY_LENGTH, &length);
				printf("Read %d bytes: %d/%d\n", newby, current, length);
				break;}
			}
			break;
		default:
			BApplication::DispatchMessage(msg, target);
			break;
		}
	};
};

int
main(int argc, char **argv)
{
	MyApp app;
	
	return app.Run();
}
