/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBStringPairList.h,v 1.2 2000/07/15 23:26:43 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBStringPairList.h]
 *   文字列対のリストを表現します。これは例えばMIMEヘッダなどの内部保存形式として
 *  適しています。
 *   BListクラスを継承していますが、BListとは異なり、最終的にリストにぶら下がっている
 *  文字列対は自動的に破棄されます（コピーコンストラクタによりStringPairListオブジェクト
 *  が複製されている場合には、最後のStringPairListオブジェクトが破棄された場合のみ
 *  自動的に破棄します）
 * -------------------------------------------------------------------------------------------- */

#if !defined(__TxBStringPairList_h__)
#	define __TxBStringPairList_h__

#	include <Be.h>

class TxBStringPairList: public BList{
private:
	int *refCount;
public:
	TxBStringPairList(int32 count = 0);
	TxBStringPairList(const TxBStringPairList &anotherList);
	virtual ~TxBStringPairList(void);
};

#	if !defined(__TxBStringPairList__)
#		define	__TxBStringPairList__
#	endif	// !defined(__TxBStringPairList__)

#endif	// !defined(__TxBStringPairList_h__)
