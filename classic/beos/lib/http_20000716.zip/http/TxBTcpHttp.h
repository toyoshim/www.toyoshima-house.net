/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBTcpHttp.h,v 1.5 2000/07/16 08:51:43 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBTcpHttp.h]
 *   HTTP Protocolを実装したクラス。
 *   関数は非同期に実行される。関数の結果はコンストラクタに渡されたBLooperオブジェクト
 *  に対してメッセージで通知される。AsyncReadはバッファにデータがある場合には、要求された
 *  サイズ以内の読めるかぎりのデータを読み終了する。読めるデータがない場合には、B_WOULD_BLOCK
 *  を返し、読める状態になった時にTxB_HTTP_CAN_READを送ってくる。
 *  ヘッダの調査関数は読み込み済みの場合はすぐに処理されるが、読み込まれていないとブロックする。
 *   またBPositionIOとしても利用できる同期関数も持つので、そのままTranslatorにかけることも可能。
 * --------------------------------------------------------------------------------------------
 *  <メッセージに関する仕様書>
 *  what: 'tNTH'
 *    Network-Tcp-Httpの頭文字。常にこれが入ります。
 *  pointer: "who"
 *    メッセージを送信したオブジェクトへのポインタが入ります。
 *  int8 "type": メッセージの種類を判別します。
 *    TxB_HTTP_ERROR
 *      エラーが発生した場合に送られてきます。
 *      int32 "errno": status_t 型のError Codeが入ります。
 *      string "message": エラーを表すメッセージが入っています。
 *    TxB_HTTP_HOST_RESOLVED
 *      サーバーのアドレスが解決できた時に送られて来ます。ただし、解決できていてもリクエストが
 *      発行されるまでは、このメッセージは送られてきません。
 *      int32 "address": 解決後のアドレス（ホストバイトオーダー）
 *      int16 "port": ポート番号
 *    TxB_HTTP_CONNECTED
 *      サーバーへの接続が完了した時に送られてきます。
 *    TxB_HTTP_STATUS
 *      サーバーからのステータスコード(404 Not Found 等)を認識した時に送られます。
 *      int16 "status": ステータスコード
 *      string "message": ステータスを表す文字列
 *    TxB_HTTP_HEADER_COMPLETE
 *      サーバーからの応答のうちヘッダ部分の受信が終わると送られてくる。この時点でヘッダ調査系
 *      の関数がブロックなしで呼べるようになる。
 *    TxB_HTTP_CONTENT_LENGTH
 *      サーバーからの応答のうちボディーのサイズが判明した時に送られてくる。
 *      通常はTxB_HTTP_STATUSからTxB_HTTP_HEADER_COMPLETEの間に送られる。
 *      int32 "length": ボディーのサイズ
 *    TxB_HTTP_COMPLETE
 *      サーバーからの応答をすべて受信した時に送られる。これ以降すべての関数がブロックなしで
 *      利用できる。
 *      int32 "length": データサイズ
 *    TxB_HTTP_BUFFER_CHANGED
 *      サーバーからの応答のうちボディーを受信している時に送られてきます。
 *      送られてくるのはバッファーへ受信し、その状態が変化した時です。
 *      int32 "newby": 新たに得たデータサイズ
 *      int32 "current": 今までに得たデータサイズ
 *      int32 "length": 最終的に得るであろうデータサイズ
 * --------------------------------------------------------------------------------------------
 * [TODO]
 *  POST
 * -------------------------------------------------------------------------------------------- */

#if !defined(__TxBTcpHttp_h__)
#	define __TxBTcpHttp_h__

#	include <Be.h>
#	include <NetworkKit.h>

#	if !defined(__TxBStringPair__)
class TxBStringPair;
#		define __TxBStringPair__
#	endif	// !defined(__TxBStringPair__)

#	if !defined(__TxBStringPairList___)
class TxBStringPairList;
#		define __TxBStringPairList__
#	endif	// !defined(__TxBStringPairList__)

// what
enum {
	TxB_HTTP_NOTIFY					= 'tNTH',
};

// names
#	define TxB_HTTP_NOTIFY_TYPE		"type"
#	define TxB_HTTP_NOTIFY_ERRNO	"errno"
#	define TxB_HTTP_NOTIFY_MESSAGE	"message"
#	define TxB_HTTP_NOTIFY_ADDRESS	"address"
#	define TxB_HTTP_NOTIFY_PORT		"port"
#	define TxB_HTTP_NOTIFY_STATUS	"status"
#	define TxB_HTTP_NOTIFY_LENGTH	"length"
#	define TxB_HTTP_NOTIFY_WHO		"who"
#	define TxB_HTTP_NOTIFY_NEWBY	"newby"
#	define TxB_HTTP_NOTIFY_CURRENT	"current"

// int8:"type"
enum {
	TxB_HTTP_ERROR					= -1,
	TxB_HTTP_HOST_RESOLVED			= 0,
	TxB_HTTP_CONNECTED,
	TxB_HTTP_STATUS,
	TxB_HTTP_HEADER_COMPLETE,
	TxB_HTTP_CONTENT_LENGTH,
	TxB_HTTP_COMPLETE,
	TxB_HTTP_BUFFER_CHANGED,
	TxB_HTTP_CAN_READ,
};
#	if !defined(TxB_HTTP_NOTIFY)
#		define TxB_HTTP_NOTIFY	'tNTH'
#	endif	// !defined(TxB_HTTP_NOTIFY)

class TxBTcpHttp: public BPositionIO{
private:
	TxBStringPairList *headers;
	TxBStringPairList *responseHeaders;
	char *userAgent;
	BLooper *receiver;
	char *body;
	int bodySize;
	BNetAddress address;
	BMallocIO buffer;
	BLocker lockAddress;
	BLocker lockBuffer;
	thread_id socketThread;
	int sock;
	BLocker lockSocket;
	BLocker lockHeader;
	BLocker lockMessage;
	BString request;
	int responseStatus;
	int contentLength;
	int readableLength;
	int readPointer;
	int canReadPointer;
	BLocker waitHeader;
	bool fWaitHeader;
	bool fCompleteHeader;
	BLocker waitBody;
public:
	TxBTcpHttp(BLooper *receiver = NULL);
	~TxBTcpHttp(void);

	// You can customize request headers.
	status_t SetUserAgent(const char *name);
	status_t SetExtraHeader(const char *name, const char *value);
	status_t SetExtraHeader(const TxBStringPair pair);
	status_t SetExtraHeaders(const TxBStringPairList *list);
	status_t SetBody(const void *buffer, size_t size);

	// You shold call SetServer before a request.
	status_t SetServer(const char *server, short port = 80);
	status_t SetServer(unsigned long s_addr, short port = 80);	// (*) s_addr: Host Byte Order

	// Requests
	status_t Get(const char *path);
	status_t Post(const char *path);
	
	// Looking into response informations
	int GetStatus(void) const;	// 404 Not found, etc...
	const char *GetHeader(const char *name) const;	// Check a header line
	const TxBStringPairList *GetHeaders(void) const;	// Get complete headers list reference
	
	// Async methods
	status_t AsyncRead(void *buffer, size_t &buffer_size);
	status_t AsyncCancelRead(void);
	status_t AsyncWrite(const void *buffer, size_t &buffer_size) { return B_READ_ONLY_DEVICE; };
	status_t AsyncCancelWrite(void) { return B_NO_INIT; };

	// Sync methods
	ssize_t Read(void *buffer, size_t size);	// BPositionIO
	ssize_t Write(const void *buffer, size_t size) { return B_READ_ONLY_DEVICE; };	// BPositionIO
	
	ssize_t ReadAt(off_t pos, void *buffer, size_t size);	// BPositionIO
	ssize_t WriteAt(off_t pos, const void *buffer, size_t size) { return B_READ_ONLY_DEVICE; };	// BPositionIO
	
	off_t Seek(off_t position, uint32 seek_mode);	// BPositionIO
	off_t Position(void) const;	// BPositionIO
	
	status_t SetSize(off_t size) { return B_READ_ONLY_DEVICE; };	// BPositionIO

private:
	void ThreadStop(void);
	static int32 ThreadMain(void *data);
	void PostErrorMessage(status_t code, const char *message);
	void PostMessage(BMessage *msg);
	ssize_t _ReadAt(off_t pos, void *buffer, size_t size);
};

#	if !defined(__TxBTcpHttp__)
#		define __TxBTcpHttp__
#	endif	// !defined(__TxBTcpHttp__)

#endif	// !defined(__TxBTcpHttp_h__)
