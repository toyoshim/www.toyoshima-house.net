/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBStringPair.cpp,v 1.2 2000/07/15 23:26:41 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBStringPair.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "TxBStringPair.h"

TxBStringPair::TxBStringPair
(const char *name, const char *value)
{
	this->name = strdup(name);
	this->value = strdup(value);
	refCount = new int;
	if (NULL != refCount) *refCount = 1;
}

TxBStringPair::TxBStringPair
(const TxBStringPair &anotherPair)
{
	refCount = anotherPair.refCount;
	if (NULL == refCount) return;
	*refCount += 1;
	name = anotherPair.name;
	value = anotherPair.value;
}

TxBStringPair::~TxBStringPair
(void)
{
	if (NULL == refCount) return;
	*refCount -= 1;
	if (0 != *refCount) return;
	if (NULL != name) free(name);
	if (NULL != value) free(value);
}

const char *
TxBStringPair::GetName
(void) const
{
	return name;
}

const char *
TxBStringPair::GetValue
(void) const
{
	return value;
}
