/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBMidiSynthConsumer.cpp,v 1.4 2000/07/24 10:07:11 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBMidiSynthConsumer.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "TxBMidiSynthConsumer.h"

extern BSynth *be_synth;

TxBMidiSynthConsumer::TxBMidiSynthConsumer
(const char *name):
BMidiLocalConsumer((NULL != name)? name: "Software MIDI")
{
	midi.EnableInput(true, true);
	be_synth->SetSamplingRate(44100);
}

void
TxBMidiSynthConsumer::NoteOff
(uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.NoteOff(channel + 1, note, velocity, time / 1000);
}

void
TxBMidiSynthConsumer::NoteOn
(uchar channel, uchar note, uchar velocity, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.NoteOn(channel + 1, note, velocity, time / 1000);
}

void
TxBMidiSynthConsumer::KeyPressure
(uchar channel, uchar note, uchar pressure, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.KeyPressure(channel + 1, note, pressure, time / 1000);
}

void
TxBMidiSynthConsumer::ControlChange
(uchar channel, uchar controlNumber, uchar controlVolume, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.ControlChange(channel + 1, controlNumber, controlVolume, time / 1000);
}

void
TxBMidiSynthConsumer::ProgramChange
(uchar channel, uchar programNumber, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.ProgramChange(channel + 1, programNumber, time / 1000);
}

void
TxBMidiSynthConsumer::ChannelPressure
(uchar channel, uchar pressure, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.ChannelPressure(channel + 1, pressure, time / 1000);
}

void
TxBMidiSynthConsumer::PitchBend
(uchar channel, uchar lsb, uchar msb, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.PitchBend(channel + 1, lsb, msb, time / 1000);
}

void
TxBMidiSynthConsumer::SystemExclusive
(void *data, size_t dataLength, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.SystemExclusive(data, dataLength, time / 1000);
}

void
TxBMidiSynthConsumer::SystemCommon
(uchar statusByte, uchar data1, uchar data2, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.SystemCommon(statusByte, data1, data2, time / 1000);
}

void
TxBMidiSynthConsumer::SystemRealTime
(uchar statusByte, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.SystemRealTime(statusByte, time / 1000);
}

void
TxBMidiSynthConsumer::TempoChange
(int32 bpm, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.TempoChange(bpm, time / 1000);
}

void
TxBMidiSynthConsumer::AllNotesOff
(bool justChannel, bigtime_t time)
{
	if (0 == time) time = system_time();
	midi.AllNotesOff(justChannel, time / 1000);
}

TxBMidiSynthConsumer::~TxBMidiSynthConsumer
(void)
{
}
