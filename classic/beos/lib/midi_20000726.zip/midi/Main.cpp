#include "TxBMidiSynthConsumer.h"
#include "TxBMidiFileProducer.h"

int
main(int argc, char **argv)
{
	BApplication app("application/x-vnd.toyoshima-house.miditest");
	TxBMidiSynthConsumer *midi = new TxBMidiSynthConsumer();
	midi->Register();	// register to Roster

	TxBMidiFileProducer *smf = new TxBMidiFileProducer();
	smf->Register();	// register to Roster

	smf->Connect(midi);

	entry_ref midiRef;
	get_ref_for_path(argv[1], &midiRef);
	if (B_OK != smf->Import(&midiRef)) puts("import failed");
	if (B_OK != smf->Play()) puts("play failed");
	smf->WaitForStop();

	smf->Unregister();	// unregister from Roster
	smf->Release();
	// Don't delete TxBMidiFileProducer

	midi->Unregister();	// unregister from Roster
	midi->Release();
	// Don't delete TxBMidiSynthConsumer
	return 0;
}
