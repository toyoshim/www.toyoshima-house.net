/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBMidiSynthConsumer.h,v 1.3 2000/07/23 01:05:43 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBMidiSynthConsumer.h]
 *  新MidiKitのインターフェースにのっとって、旧MidiKitのソフトシンセを
 *  Endpoint(Comsumer)として見せるクラス。
 * -------------------------------------------------------------------------------------------- */

#if !defined(__TxBMidiSynthConsumer_h__)
#	define __TxBMidiSynthConsumer_h__

#	include <Be.h>
#	include <MidiConsumer.h>
#	include <MidiProducer.h>
#	include <MidiRoster.h>

class TxBMidiSynthConsumer: public BMidiLocalConsumer{
private:
	BMidiSynth midi;
public:
	TxBMidiSynthConsumer(const char *name = NULL);

	virtual void NoteOff(uchar channel, uchar note, uchar velocity, bigtime_t time);
	virtual void NoteOn(uchar channel, uchar note, uchar velocity, bigtime_t time);
	virtual void KeyPressure(uchar channel, uchar note, uchar pressure, bigtime_t time);
	virtual void ControlChange(uchar channel, uchar controlNumber, uchar controlValue, bigtime_t time);
	virtual void ProgramChange(uchar channel, uchar programNumber, bigtime_t time);
	virtual void ChannelPressure(uchar channel, uchar pressure, bigtime_t time);
	virtual void PitchBend(uchar channel, uchar lsb, uchar msb, bigtime_t time);
	virtual void SystemExclusive(void *data, size_t dataLength, bigtime_t time);
	virtual void SystemCommon(uchar statusByte, uchar data1, uchar data2, bigtime_t time);
	virtual void SystemRealTime(uchar statusByte, bigtime_t time);
	virtual void TempoChange(int32 bpm, bigtime_t time);
	virtual void AllNotesOff(bool justChannel, bigtime_t time);

protected:
	~TxBMidiSynthConsumer(void);
};

#	if !defined(__TxBMidiSynthConsumer__)
#		define __TxBMidiSynthConsumer__
#	endif	// !defined(__TxBMidiSynthConsumer__)

#endif	// !defined(__TxBMidiSynthConsumer_h__)
