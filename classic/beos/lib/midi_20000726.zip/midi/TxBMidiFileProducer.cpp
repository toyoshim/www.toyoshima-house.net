/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBMidiFileProducer.cpp,v 1.3 2000/07/24 12:37:55 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBMidiFileProducer.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "TxBMidiFileProducer.h"

long
TxBMidiFileProducer::Track::tempo = 0;

TxBMidiFileProducer::Track::Track
(TxBMidiFileProducer *mid):
data(NULL),
size(0),
offset(0),
mid(mid),
waitTime((ulong)-1),
oldEvent(0)
{
}

TxBMidiFileProducer::Track::~Track
(void)
{
	if (NULL != data) free(data);
}

status_t
TxBMidiFileProducer::Track::SetData
(const void *data, size_t datasize)
{
	if (NULL != this->data) free(this->data);
	this->data = (uchar *)malloc(datasize);
	if (NULL == this->data) return B_NO_MEMORY;
	memcpy(this->data, data, datasize);
	size = datasize;
	return B_OK;
}

void
TxBMidiFileProducer::Track::Rewind
(void)
{
	offset = 0;
	waitTime = (ulong)-1;
	oldEvent = 0;
}

ulong
TxBMidiFileProducer::Track::WaitTime
(void)
{
	if (waitTime != (ulong)-1) return waitTime;
	waitTime = GetTime();
	return waitTime;
}

void
TxBMidiFileProducer::Track::Spray
(ulong time)
{
	if (waitTime == (ulong)-1) return;
	waitTime -= time;
	if (waitTime > 0) return;
	waitTime = (ulong)-1;
	uchar ev = GetEvent();
	uchar type = ev >> 4;
	uchar ch = ev & 0xf;
	switch (type) {
	case 0x8:	// 0x8n
		mid->SprayNoteOff(ch, data[offset], data[offset + 1]);
		offset += 2;
		break;
	case 0x9:	// 0x9n
		mid->SprayNoteOn(ch, data[offset], data[offset + 1]);
		offset += 2;
		break;
	case 0xa:	// 0xan
		mid->SprayKeyPressure(ch, data[offset], data[offset + 1]);
		offset += 2;
		break;
	case 0xb:	// 0xbn
		mid->SprayControlChange(ch, data[offset], data[offset + 1]);
		offset += 2;
		break;
	case 0xc:	// 0xcn
		mid->SprayProgramChange(ch, data[offset]);
		offset++;
		break;
	case 0xd:	// 0xdn
		mid->SprayChannelPressure(ch, data[offset]);
		offset++;
		break;
	case 0xe:	// 0xen
		mid->SprayPitchBend(ch, data[offset], data[offset + 1]);
		offset += 2;
		break;
	case 0xf:	// 0xfn
		switch (ch) {
		case 0x0:{	// 0xf0	: exclusive
			uchar size = data[offset++];
			mid->SpraySystemExclusive(&data[offset], size);	// last data is 7F(term-char)
			offset += size;
			break;}
		case 0xf:{	// 0xff	: meta
			type = data[offset++];
			uchar size = data[offset++];
			if (type == 0x51) {
				// tempo
				tempo = (data[offset] << 16) | (data[offset + 1] << 8) | data[offset + 2];
			} else if (type == 0x2f) {
				// end of track
				offset = this->size - size;
//			} else {
//				printf("meta %02x\n", type);
			}
			offset += size;
			break;}
		default:
			printf("SMF error: $%x\n", ev);
		}
		break;
	default:
		printf("SMF error: $%x\n", ev);
	}
}

ulong
TxBMidiFileProducer::Track::GetTime
(void)
{
	if (offset + 4 > size) return (ulong)-1;
	ulong value;
	offset += TxBMidiFileProducer::GetTime(&data[offset], value);
	return value;
}

uchar
TxBMidiFileProducer::Track::GetEvent
(void)
{
	if (0 == (data[offset] & 0x80)) return oldEvent;
	oldEvent = data[offset++];
	return oldEvent;
}

TxBMidiFileProducer::TxBMidiFileProducer
(const char *name):
BMidiLocalProducer((NULL != name)? name: "SMF Producer"),
format(0xffff),
nTrack(0),
timeBase(0),
tracks(NULL),
playbackId(0),
loop(false)
{
}

TxBMidiFileProducer::~TxBMidiFileProducer
(void)
{
	Stop();
	lock.Lock();
	if (NULL != tracks) {
		for (int tr = 0; tr < nTrack; tr++) if (NULL != tracks[tr]) delete tracks[tr];
		free(tracks);
	}
	lock.Unlock();
}

status_t
TxBMidiFileProducer::Import
(const entry_ref *smf_entry_ref)
{
	if (NULL == smf_entry_ref) return B_BAD_VALUE;
	BFile *file = new BFile(smf_entry_ref, B_READ_ONLY);
	if (NULL == file) return B_NO_MEMORY;
	status_t rc = Import(file);
	delete file;
	return rc;
}

status_t
TxBMidiFileProducer::Import
(const void *smf_data, size_t smf_datasize)
{
	Stop();
	lock.Lock();
	if (smf_datasize < 14) return B_BAD_VALUE;
	const uchar *data = (const uchar *)smf_data;
	const uchar *data_end = &data[smf_datasize];

	if (NULL != tracks) {
		for (uint tr = 0; tr < nTrack; tr++) delete tracks[tr];
		free(tracks);
		tracks = NULL;
	}
	try {
		if (0 != memcmp("MThd", data, 4)) throw B_BAD_VALUE;
		data += 4;
		ulong size;
		data += GetLong(data, size);
		if (6 != size) throw B_BAD_VALUE;
		data += GetShort(data, format);
		data += GetShort(data, nTrack);
		data += GetShort(data, timeBase);
		tracks = (Track **)malloc(sizeof(Track *) * nTrack);
		if (NULL == tracks) throw B_NO_MEMORY;
		memset(tracks, 0, sizeof(Track *) * nTrack);
		uint tr;
		for (tr = 0; (tr < nTrack) && ((ulong)data < (ulong)data_end); tr++) {
			tracks[tr] = new Track(this);
			if (NULL == tracks[tr]) throw B_NO_MEMORY;
			if (0 != memcmp("MTrk", data, 4)) throw B_BAD_VALUE;
			data += 4;
			ulong tracksize;
			data += GetLong(data, tracksize);
			status_t rc = tracks[tr]->SetData((void *)data, (size_t)tracksize);
			if (B_OK != rc) throw (int)rc;
			data += tracksize;
		}
		if (tr != nTrack) throw B_BAD_VALUE;
	} catch (int e) {
		if (NULL != tracks) {
			for (uint tr = 0; tr < nTrack; tr++) if (NULL != tracks[tr]) delete tracks[tr];
			free(tracks);
			tracks = NULL;
		}
		lock.Unlock();
		return e;
	}
	lock.Unlock();
	return B_OK;
}

status_t
TxBMidiFileProducer::Import
(BPositionIO *smf_io)
{
	if (NULL == smf_io) return B_BAD_VALUE;
	off_t size = smf_io->Seek(0, SEEK_END);
	if (size <= 0) smf_io->Position();
	
	void *smf_data = malloc(size);
	if (NULL == smf_data) return B_NO_MEMORY;
	ssize_t smf_size = smf_io->ReadAt(0, smf_data, size);
	status_t rc;
	if ((ulong)size != (ulong)smf_size) rc = B_DEV_READ_ERROR;
	else rc = Import(smf_data, smf_size);
	free(smf_data);

	return rc;
}

status_t
TxBMidiFileProducer::Play
(bool loop)
{
	Stop();
	lock.Lock();
	this->loop = loop;
	playbackId = spawn_thread(PlaybackThread, "SMF Playback Thread", B_NORMAL_PRIORITY, (void *)this);
	lock.Unlock();
	status_t rc;
	if (playbackId > B_OK) rc = resume_thread(playbackId);
	else rc = B_ERROR;
	return rc;
}

status_t
TxBMidiFileProducer::Stop
(void)
{
	lock.Lock();
	if (playbackId <= B_OK) {
		lock.Unlock();
		return B_ERROR;
	}
	status_t rc = kill_thread(playbackId);
	playbackId = 0;
	lock.Unlock();
	return rc;
}

status_t
TxBMidiFileProducer::WaitForStop
(void)
{
	lock.Lock();
	if (playbackId <= B_OK) {
		lock.Unlock();
		return B_ERROR;
	}
	thread_id target = playbackId;
	lock.Unlock();
	status_t ec;
	status_t rc = wait_for_thread(target, &ec);
	if (B_OK != rc) return B_OK;	// already stoped
	return ec;
}

ssize_t
TxBMidiFileProducer::GetLong
(const uchar *data, ulong &result)
{
	result = (data[0] << 24) | (data[1] << 16) | (data[2] << 8) | data[3];
	return 4;
}

ssize_t
TxBMidiFileProducer::GetShort
(const uchar *data, ushort &result)
{
	result = (data[0] << 8) | data[1];
	return 2;
}

ssize_t
TxBMidiFileProducer::GetTime
(const uchar *data, ulong &result)
{
	result = 0;
	const uchar *start = data;
	do {
		result <<= 7;
		result += (*data & 0x7f);
	} while (*data++ & 0x80);
	return data - start;
}

int32
TxBMidiFileProducer::PlaybackThread
(void *data)
{
	((TxBMidiFileProducer *)data)->lock.Lock();
	((TxBMidiFileProducer *)data)->lock.Unlock();
	return ((TxBMidiFileProducer *)data)->PlaybackMain();
}

int32
TxBMidiFileProducer::PlaybackMain
(void)
{
	lock.Lock();
	bigtime_t time = system_time();
	do {
		for (;;) {
			ulong wait = (ulong)-1;
			for (ushort tr = 0; tr < nTrack; tr++) {
				ulong _wait = tracks[tr]->WaitTime();
				if (_wait < wait) wait = _wait;
			}
			if (wait == (ulong)-1) break;
			time += (int)((double)wait * (double)Track::tempo / (double)timeBase);
			lock.Unlock();
			snooze_until(time, B_SYSTEM_TIMEBASE);
//			bigtime_t t = time - system_time();
//			if (t > 0) snooze(t);
			lock.Lock();
			for (ushort tr = 0; tr < nTrack; tr++) tracks[tr]->Spray(wait);
		}
		for (ushort tr = 0; tr < nTrack; tr++) tracks[tr]->Rewind();
	} while(loop);

	// exit
	playbackId = 0;
	lock.Unlock();
	exit_thread(B_OK);
	return B_OK;
}
