/* --------------------------------------------------------------------------------------------
 *  Meta Gassee - Meta Gate clone for BeOS -
 *  (C) 2000 とよしま
 *  $Id: TxBMidiFileProducer.h,v 1.3 2000/07/24 12:37:56 toyoshim Exp $
 * --------------------------------------------------------------------------------------------
 *  [TxBMidiFileProducer.h]
 *  新MidiKitのインターフェースにのっとって、SMFファイルを再生するためのクラス。
 * -------------------------------------------------------------------------------------------- */

#if !defined(__TxBMidiFileProducer_h__)
#	define __TxBMidiFileProducer_h__

#	include <Be.h>
#	include <MidiConsumer.h>
#	include <MidiProducer.h>
#	include <MidiRoster.h>

class TxBMidiFileProducer: public BMidiLocalProducer{
private:
	friend class Track{
	private:
		uchar *data;
		size_t size;
		off_t offset;
		TxBMidiFileProducer *mid;
		ulong waitTime;
		uchar oldEvent;
	public:
		static long tempo;
		Track(TxBMidiFileProducer *parent);
		~Track(void);
		status_t SetData(const void *data, size_t datasize);
		void Rewind(void);
		
		ulong WaitTime(void);
		void Spray(ulong time);
	private:
		ulong GetTime(void);
		uchar GetEvent(void);
	};
	BLocker lock;
	ushort format;
	ushort nTrack;
	ushort timeBase;
	Track **tracks;
	thread_id playbackId;
	bool loop;
public:
	TxBMidiFileProducer(const char *name = NULL);
	virtual ~TxBMidiFileProducer(void);

	status_t Import(const entry_ref *smf_entry_ref);
	status_t Import(const void *smf_data, size_t smf_datasize);
	status_t Import(BPositionIO *smf_io);

	status_t Play(bool loop = false);
	status_t Stop(void);
	status_t WaitForStop(void);

protected:
	static ssize_t GetLong(const uchar *data, ulong &result);
	static ssize_t GetShort(const uchar *data, ushort &result);
	static ssize_t GetTime(const uchar *data, ulong &result);
	static int32 PlaybackThread(void *data);
	int32 PlaybackMain(void);
};

#	if !defined(__TxBMidiFileProducer__)
#		define __TxBMidiFileProducer__
#	endif	// !defined(__TxBMidiFileProducer__)

#endif	// !defined(__TxBMidiFileProducer_h__)
