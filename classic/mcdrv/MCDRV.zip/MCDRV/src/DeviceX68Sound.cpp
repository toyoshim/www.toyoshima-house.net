#include "DeviceX68Sound.h"
#include "SoundDriver.h"

namespace X68Sound {
	int (*X68SoundStart)(int samprate = 44100, int opmflag = 1, int adpcmflag = 1, int betw = 5, int pcmbuf = 5, int late = 200, double rev = 1.0);
	int (*X68SoundStartPCM)(int samprate = 44100, int opmflag = 1, int adpcmflag = 1, int pcmbuf = 5);
	int (*X68SoundGetPCM)(void *buf, int len);
	void (*X68SoundFree)(void);
	void (*X68SoundOPMInt)(void (CALLBACK *proc)(void) = NULL);
	void (*X68SoundOPMReg)(unsigned char no);
	void (*X68SoundOPMPoke)(unsigned char data);
	unsigned char (*X68SoundOPMPeek)(void);
	int (*X68SoundPCM8Abort)(void);
	int (*X68SoundPCM8Out)(int ch, void *adrs, int mode, int len);
}

DeviceX68Sound::DevicePCM8::DevicePCM8
(void):
active_channel(0)
{
	for (int i = 0; i < 8; i++) {
		voice_number[i] = 0;
		bank_number[i] = 0;
		pan[i] = 3;
		volume[i] = 8 << 3;
		mode[i] = 4;
	}
	ZeroMemory(voice[0], sizeof(unsigned char *) * 128);
	ZeroMemory(voice[1], sizeof(unsigned char *) * 128);
	ZeroMemory(voice_length[0], sizeof(int) * 128);
	ZeroMemory(voice_length[1], sizeof(int) * 128);
}

DeviceX68Sound::DevicePCM8::~DevicePCM8
(void)
{
	X68Sound::X68SoundPCM8Abort();
	for (int b = 0; b < 2; b++) for (int v = 0; v < 128; v++) if (NULL != voice[b][v]) delete voice[b][v];
}

bool
DeviceX68Sound::DevicePCM8::Initialize
(void)
{
	return true;
}

void
DeviceX68Sound::DevicePCM8::Update
(short *buffer, int count)
{
	return;
}

void
DeviceX68Sound::DevicePCM8::SetPitch
(int pitch)
{
	int note = pitch / 64 - 15;
	voice_number[active_channel] = note;
//	DOUT("NOTE: %d\n", note);
}

void
DeviceX68Sound::DevicePCM8::SetVolume
(int vol)
{
	volume[active_channel] = vol;
}

void
DeviceX68Sound::DevicePCM8::SetVoice
(int voice, int bank)
{
	voice_number[active_channel] = voice;
	bank_number[active_channel] = bank;
}

void
DeviceX68Sound::DevicePCM8::SetPan
(int panpot)
{
	if (panpot < 0x2b) pan[active_channel] = 1;	// L
	else if (panpot < 0x55) pan[active_channel] = 3;	// C
	else if (panpot < 0x80) pan[active_channel] = 2;	// R
	else pan[active_channel] = 0;	// OFF
}

void
DeviceX68Sound::DevicePCM8::KeyOn
(void)
{
	int vol = volume[active_channel] >> 3;
	if (vol > 15) vol = 15;
	else if (vol < 0) vol = 0;
	int n = voice_number[active_channel];
	int b = bank_number[active_channel];
	if (n < 0) {
		KeyOff();
		return;
	}
	unsigned char *v = voice[b][n];
//	DOUT("ON %d v=%d pan=%d @%d:%d\n", active_channel, volume[active_channel], pan[active_channel], n, b);
	if (NULL == v) return;
	X68Sound::X68SoundPCM8Out(active_channel, v, (vol << 16) | (mode[active_channel] << 8) | pan[active_channel], voice_length[b][n]);
}

void
DeviceX68Sound::DevicePCM8::KeyOff
(void)
{
	X68Sound::X68SoundPCM8Out(active_channel, NULL, -1, 0);
}

void
DeviceX68Sound::DevicePCM8::SetActiveChannel
(int channel)
{
	active_channel = channel;
}

bool
DeviceX68Sound::DevicePCM8::SetVoiceData
(int n, unsigned char *data, int data_length, int bank)
{
	DOUT("@%d:%d $%08X($%08X)\n", n, bank, data, data_length);
	if (NULL != voice[bank][n]) delete voice[bank][n];
	voice[bank][n] = new unsigned char[data_length];
	if (NULL == voice[bank][n]) return false;
	memcpy(voice[bank][n], data, data_length);
	voice_length[bank][n] = data_length;
	return true;
}

bool
DeviceX68Sound::DevicePCM8::SetPlayMode
(int n)
{
	mode[active_channel] = n;
	return true;
}

bool
DeviceX68Sound::has_instance = false;

HINSTANCE
DeviceX68Sound::dll_instance = NULL;

DeviceX68Sound *
DeviceX68Sound::instance = NULL;

DeviceX68Sound::DeviceX68Sound
(int mode):
DeviceOPM(),
callback(NULL),
mode(mode)
{
	initialize = !has_instance;
	has_instance = true;
}

DeviceX68Sound::~DeviceX68Sound
(void)
{
	has_instance = !initialize;
	if (initialize) {
		X68Sound::X68SoundFree();
		instance = NULL;
	}
}

bool
DeviceX68Sound::Initialize
(void)
{
	if (!initialize) return false;
	if (NULL == dll_instance) if (!LoadModule()) return false;
	if (mode == CDXS_STAND_ALONE) X68Sound::X68SoundStart();
	else X68Sound::X68SoundStartPCM();
	instance = this;
	return true;
}

void
DeviceX68Sound::Update
(short *buffer, int count)
{
	X68Sound::X68SoundGetPCM(buffer, count / 2);
}

void
DeviceX68Sound::SetTimerCallback
(SoundDriver *driver)
{
	callback = driver;
	Write(0x14, 0);
}

void
DeviceX68Sound::SetTimerInterval
(double msec)
{
	DOUT("SetTimer %f msec\n", (float)msec);
	Write(0x14, 0);
	int clk_a = 1024 - (int)floor(4000.0 * msec / 64.0);
	if (clk_a < 0) clk_a = 0;
	if (clk_a > 0x3ff) clk_a = 0x3ff;
	Write(0x10, clk_a >> 2);
	Write(0x11, clk_a & 3);
	Write(0x14, 0x15);
	X68Sound::X68SoundOPMInt(TimerCallback);
}

void
DeviceX68Sound::Write
(unsigned char reg, unsigned char value)
{
	X68Sound::X68SoundOPMReg(reg);
	X68Sound::X68SoundOPMPoke(value);
}

unsigned char
DeviceX68Sound::Read
(unsigned char reg)
{
	return X68Sound::X68SoundOPMPeek();
}

void
DeviceX68Sound::TimerCallback
(void)
{
	instance->callback->TimerCallback();
	X68Sound::X68SoundOPMReg(0x14);
	X68Sound::X68SoundOPMPoke(0x15);
	X68Sound::X68SoundOPMInt(TimerCallback);
}

DeviceX68Sound::DevicePCM8 *
DeviceX68Sound::DevicePCM8Create
(void)
{
	DevicePCM8 *pcm8 = new DevicePCM8();
	return pcm8;
}

bool
DeviceX68Sound::LoadModule
(void)
{
	if (NULL != dll_instance) return true;
	dll_instance = LoadLibrary("X68Sound.dll");
	if (NULL == dll_instance) return false;

	X68Sound::X68SoundStart = (int (*)(int, int, int, int, int, int, double))GetProcAddress(dll_instance, "X68Sound_Start");
	X68Sound::X68SoundStartPCM = (int (*)(int, int, int, int))GetProcAddress(dll_instance, "X68Sound_StartPcm");
	X68Sound::X68SoundGetPCM = (int (*)(void *, int))GetProcAddress(dll_instance, "X68Sound_GetPcm");
	X68Sound::X68SoundFree = (void (*)(void))GetProcAddress(dll_instance, "X68Sound_Free");
	X68Sound::X68SoundOPMInt = (void (*)(void (CALLBACK *proc)(void)))GetProcAddress(dll_instance, "X68Sound_OpmInt");
	X68Sound::X68SoundOPMReg = (void (*)(unsigned char no))GetProcAddress(dll_instance, "X68Sound_OpmReg");
	X68Sound::X68SoundOPMPoke = (void (*)(unsigned char data))GetProcAddress(dll_instance, "X68Sound_OpmPoke");
	X68Sound::X68SoundOPMPeek = (unsigned char (*)(void))GetProcAddress(dll_instance, "X68Sound_OpmPeek");
	X68Sound::X68SoundPCM8Abort = (int (*)(void))GetProcAddress(dll_instance, "X68Sound_Pcm8_Abort");
	X68Sound::X68SoundPCM8Out = (int (*)(int, void *, int, int))GetProcAddress(dll_instance, "X68Sound_Pcm8_Out");
	if ((NULL == X68Sound::X68SoundStart) ||
		(NULL == X68Sound::X68SoundStartPCM) ||
		(NULL == X68Sound::X68SoundGetPCM) ||
		(NULL == X68Sound::X68SoundFree) ||
		(NULL == X68Sound::X68SoundOPMInt) ||
		(NULL == X68Sound::X68SoundOPMReg) ||
		(NULL == X68Sound::X68SoundOPMPoke) ||
		(NULL == X68Sound::X68SoundOPMPeek) ||
		(NULL == X68Sound::X68SoundPCM8Abort) ||
		(NULL == X68Sound::X68SoundPCM8Out)) return false;
	return true;
}
