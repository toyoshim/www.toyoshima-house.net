#if !defined(__SoundStream_h__)
#	define	__SoundStream_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__SoundDriver__)
class SoundDriver;
#		define	__SoundDriver__
#	endif	// !defined(__SoundDriver__)

abstract class SoundStream{
public:
	virtual ~SoundStream(void){};
	virtual void SetTimerCallback(SoundDriver *driver) = 0;
	virtual void SetTimerInterval(double msec) = 0;
};

#endif	// !defined(__SoundStream_h__)
