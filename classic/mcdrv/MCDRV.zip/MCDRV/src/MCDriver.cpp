#include "MCDriver.h"
#include "DeviceX68Sound.h"
#include "SoundDevice.h"
#include "SoundStream.h"
#include "File.h"

#define	GET_WORD(x)	(((x)[0] << 8) | (x)[1])
#define	GET_LONG(x)	(((x)[0] << 24) | ((x)[1] << 16) | ((x)[2] << 8) | (x)[3])

bool
MCDriver::CheckFormat
(const unsigned char *data, int datasize)
{
	MCDriver md;
	md.data = (unsigned char *)data;
	md.datasize = datasize;
	bool result = md.CheckFormat();
	md.data = NULL;
	return result;
}

const unsigned char *
MCDriver::GetTitle
(const unsigned char *data, int datasize)
{
	static unsigned char t[1024];
	MCDriver md;
	md.data = (unsigned char *)data;
	md.datasize = datasize;
	if (!md.CheckFormat()) return NULL;
	_snprintf((char *)t, 1024, "%s", md.title);
	md.data = NULL;
	return t;
}

#if defined(_DEBUG)
void
MCDriver::DisTrack
(const unsigned char *data)
{
	char *note[] = {
		"c", "c+", "d", "d+", "e", "f", "f+", "g", "g+", "a", "a+", "b",
	};
	char *adpcm_freq[] = {
		"3.9", "5.2", "7.8", "10.4", "15.6", "16bit PCM", "8bit PCM",
	};
	bool tie = false;
	int oct = -1;
	DOUT("DISTRACK ");
	for (;;) {
		if (*data < 0x80) {
			int o = data[0] / 12;
			int n = data[0] % 12;
			if (o != oct) {
				oct = o;
				DOUTR("\no%d ", o);
			}
			if (data[1] >= 0x80) {
				DOUTR("%s{%d}%s", note[n], data[1] - 128, tie? "&": "");
				data += 2;
			} else {
				int vol = data[1];
				int step;
				if (data[2] & 0x80) {
					step = ((data[2] & 0x7f) << 7) + data[3];
					data++;
				} else {
					step = data[2];
				}
				int gate;
				if (data[3] & 0x80) {
					gate = ((data[3] & 0x7f) << 7) + data[4];
					data++;
				} else {
					gate = data[3];
				}
				DOUTR("%s{%d:%d/%d}%s",note[n], vol, step, gate, tie? "&": "");
				data += 4;
			}
			tie = false;
			continue;
		}
		switch (*data) {
		case 0x80:{	// �x��
			int l;
			if (data[1] == 0xff) {
				DOUTR("\n*** [R %02X %02X] ***\n", data[1], data[2]);
				data += 3;
				break;
			} else if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			DOUTR("r{%d}%s", l, tie? "&": "");
			data += 2;
			tie = false;
			break;}
		case 0x81:{	// ����
			int o = data[1] / 12;
			int n = data[1] % 12;
			int l;
			if (o != oct) {
				oct = o;
				DOUTR("o%d", o);
			}
			if (data[2] & 0x80) {
				l = ((data[2] & 0x7f) << 7) + data[3];
				data++;
			} else {
				l = data[2];
			}
			DOUTR("%s{{%d}}%s", note[n], l, tie? "&": "");
			data += 3;
			tie = false;
			break;}
		case 0x86:	// �^�C�i�X���[�j
			tie = true;
			data++;
			break;
		case 0x88:	// ���s�[�g�J�n
			DOUTR("\n|:%d", data[1]);
			data += 3;
			break;
		case 0x89:	// ���s�[�g�I�[
			DOUTR(":|\n");
			data += 3;
			break;
		case 0x8a:	// ���s�[�g�����o��
			DOUTR("|");
			data += 3;
			break;
		case 0x8b:	// ���s�[�g�񐔎w��t�����o��
			DOUTR("|%d", data[2]);
			data += 4;
			break;
		case 0x8c:	// OPMDRV�n [�`] �R�}���h
			switch (data[1]) {
			case 0:
				DOUTR(" [D.C.] ");
				data += 4;
				break;
			case 1:
				DOUTR(" [D.S.] ");
				data += 4;
				break;
			case 2:
				DOUTR(" [TOCODA] ");	// [*]
				data += 4;
				break;
			case 3:
				DOUTR(" [SEGNO] ");	// [$]
				data += 2;
				break;
			case 4:
				DOUTR(" [CODA] ");
				data += 2;
				break;
			case 5:
				DOUTR(" [FINE] ");	// [^]
				data += 2;
				break;
			default:
				DOUTR(" [*reserved*] ");
				data += 2;
				break;
			}
			break;
		case 0x8d:	// �W�����v
			DOUTR("[JUMP]");
			data++;
			break;
		case 0x8e:	// ���ߏI���
			DOUTR(" /**/\n");
			data++;
			break;
		case 0x8f:	// �Z�[�����W���[
			DOUTR(" [S.M.] ");
			data += 3;
			break;
		case 0xa0:	// �x���V�e�B�ݒ�
			if (data[1] < 0x80) {
				DOUTR("@V%d ", data[1]);
			} else {
				DOUTR("V%d ", data[1] - 0x80);
			}
			data += 2;
			break;
		case 0xa1:	// ���΃x���V�e�B�ݒ�
			if ((char)data[1] > 0) {
				DOUTR("~~%d", data[1]);
			} else {
				DOUTR("__%d", -(char)data[1]);
			}
			data += 2;
			break;
		case 0xa2:	// �{�����[���i�G�N�X�v���b�V�����j�ݒ�
		case 0xa4:	// �g���b�N�{�����[���ݒ�
			if (data[1] < 0x80) {
				DOUTR("@v%d ", data[1]);
			} else {
				DOUTR("v%d ", data[1] - 0x80);
			}
			data += 2;
			break;
		case 0xa3:	// ���΃{�����[���i�G�N�X�v���b�V�����ݒ�
		case 0xa5:	// ���΃g���b�N�{�����[���ݒ�
			if (data[1] < 0x80) {
				DOUTR("~%d", data[1]);
			} else {
				DOUTR("_%d", -(signed char)data[1]);
			}
			data += 2;
			break;
		case 0xa6:	// �p���|�b�g�ݒ�
			if (data[1] < 0x80) {
				DOUTR("@p%d ", data[1]);
			} else if (data[1] < 0x90) {
				DOUTR("p%d ", data[1] - 0x80);
			} else {
				DOUTR("P%d ", data[1] - 0xf0);
			}
			data += 2;
			break;
		case 0xa7:	// ���΃p���|�b�g�ݒ�
			DOUTR("p+%d ", (char)data[1]);
			data += 2;
			break;
		case 0xa8:	// �g���b�N�P�ʃL�[�g�����X�|�[�Y�ݒ�
			DOUTR("KT %d\n", (char)data[1]);
			data += 2;
			break;
		case 0xa9:	// �g���b�N�P�ʑ��΃L�[�g�����X�|�[�Y�ݒ�
			DOUTR("KT+ %d\n", (char)data[1]);
			data += 2;
			break;
		case 0xaa:	// �x���h�����W�ݒ�
			DOUTR("B%d ", data[1]);
			data += 2;
			break;
		case 0xab:	// ���΃x���h�����W�ݒ�
			DOUTR("B+%d ", (char)data[1]);
			data += 2;
			break;
		case 0xac:	// �f�`���[���ݒ�
			DOUTR("k%d", (char)data[1]);
			data += 2;
			break;
		case 0xad:	// ���΃f�`���[���ݒ�
			DOUTR("k+%d", (char)data[1]);
			data += 2;
			break;
		case 0xae:	// �N�I���^�C�Y�ݒ�
			if (data[1] <= 0x08) {
				DOUTR("q%d ", data[1]);
			} else {
				DOUTR("@q%d ", (data[1] & 0x7f) + 1);
			}
			data += 2;
			break;
		case 0xaf:	// ���΃N�I���^�C�Y�ݒ�
			DOUTR("@q+%d ", (char)data[1]);
			data += 2;
			break;
		case 0xb0:	// �`���[���ݒ�
			DOUTR("k%d", (short)GET_WORD(&data[1]));
			data += 3;
			break;
		case 0xb1:	// ���΃`���[���ݒ�
			DOUTR("k+%d", (short)GET_WORD(&data[1]));
			data += 3;
			break;
		case 0xb2:	// �x���h�ݒ�
			DOUTR("b%d", (short)GET_WORD(&data[1]));
			data += 3;
			break;
		case 0xb3:	// ���΃x���h�ݒ�
			DOUTR("b+%d", (short)GET_WORD(&data[1]));
			data += 3;
			break;
		case 0xb8:{	// �|���^�����g
			int target = (short)GET_WORD(&data[1]);
			int l;
			if (data[3] & 0x80) {
				l = ((data[3] & 0x7f) << 7) + data[4];
				data++;
			} else {
				l = data[3];
			}
			DOUTR("/%d/{%d}", target, l);
			data += 4;
			break;}
		case 0xb9:{	// �t���^�C���|���^�����g
			int l;
			if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			DOUTR(" [FP %d] ", l);
			data += 2;
			break;}
		case 0xc0:	// �s�b�`LFO�g�`�ݒ�
			if (0x80 == data[1]) {
				DOUTR("MPOFF ");
			} else if (0x81 == data[1]) {
				DOUTR("MPON ");
			} else {
				DOUTR("\nMP%d ", data[1]);
			}
			data += 2;
			break;
		case 0xc1:{	// �s�b�`LFO�X�s�[�h�ݒ�
			int s;
			if (data[1] & 0x80) {
				s = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				s = data[1];
			}
			DOUTR("MP,%d ", s);
			data += 2;
			break;}
		case 0xc2:	// �s�b�`LFO�U���ݒ�
			DOUTR("MP,,%d ", (short)GET_WORD(&data[1]));
			data += 3;
			break;
		case 0xc3:	// �s�b�`LFO���ΐU���ݒ�
			DOUTR("MP,,+%d ", (short)GET_WORD(&data[1]));
			data += 3;
			break;
		case 0xc4:{	// �s�b�`LFO�f�B���C�ݒ�
			int d;
			if (data[1] & 0x80) {
				d = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				d = data[1];
			}
			DOUTR("MP,,,%d ", d);
			data += 2;
			break;}
		case 0xc5:	// ����LFO�g�`�ݒ�
			if (0x80 == data[1]) {
				DOUTR(" MVOFF ");
			} else if (0x81 == data[1]) {
				DOUTR(" MVON ");
			} else {
				DOUTR("\nMV%d ", data[1]);
			}
			data += 2;
			break;
		case 0xc6:{	// ����LFO�X�s�[�h�ݒ�
			int s;
			if (data[1] & 0x80) {
				s = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				s = data[1];
			}
			DOUTR("MV,%d ", s);
			data += 2;
			break;}
		case 0xc7:	// ����LFO�U���ݒ�
			DOUTR("MV,,%d ", (char)data[1]);
			data += 2;
			break;
		case 0xc9:{	// ����LFO�f�B���C�ݒ�
			int d;
			if (data[1] & 0x80) {
				d = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				d = data[1];
			}
			DOUTR("MV,,,%d ", d);
			data += 2;
			break;}
		case 0xe0:	// �v���O�����`�F���W
			DOUTR("\n@%d:%d ", data[1] & 0x7f, data[1] & 0x01);
			data += 2;
			break;
		case 0xe1:	// �o���N���v���O�����`�F���W
			DOUTR("\n@%d:%d ", data[2], data[1]);
			data += 3;
			break;
		case 0xe2:	// ����f�o�C�X�ύX
			DOUTR("\n@!%d ", data[1]);
			data += 2;
			break;
		case 0xe5:	// ADPCM�Đ����g���ݒ�
			DOUTR(" [ADPCM %s] ", adpcm_freq[data[1]]);
			data += 2;
			break;
		case 0xe6:	// OPM�z���C�g�m�C�Y�ݒ�
			DOUTR("N%d ", data[1]);
			data += 2;
			break;
		case 0xe7:	// OPM�n�[�hLFO�ݒ�
			if (data[1] == 0x80) {
				DOUTR(" [LFO OFF] ");
				data += 2;
			} else if (data[1] == 0x81) {
				DOUTR(" [LFO ON] ");
				data += 2;
			} else {
				DOUTR(" [LFO %d, %d, %d, %d, %d] ", data[1], data[2], data[3], data[4], data[5]);
				data += 6;
			}
			break;
		case 0xe8:	// OPM���W�X�^�ݒ�
			DOUTR("y%d,%d", data[1], data[2]);
			data += 3;
			break;
		case 0xec:	// �R���g���[���`�F���W
			DOUTR("\n[CTLCHG %d, %d]\n", data[1], data[2]);
			data += 3;
			break;
		case 0xef:	// �g���b�N�o���G�[�V����
			DOUTR("[%s]\n", (data[1] & 0x01)? "drum track": "music track");
			data += 2;
			break;
		case 0xf0:	// �e���|�ݒ�
			DOUTR("\nt%d ", GET_WORD(&data[1]));
			data += 3;
			break;
		case 0xf6:	// �����L�[�g�����X�|�[�Y
			DOUTR("[kt %d]", (signed char)data[1]);
			data += 2;
			break;
		case 0xf7:	// �������΃L�[�g�����X�|�[�Y
			DOUTR("[kt+ %d]", (signed char)data[1]);
			data += 2;
			break;
		case 0xfc:{	// �R�����g
			int size = data[1];
			int val = data[2];
			DOUTR(" /* (%d:%d) %s */\n", size, val, &data[3]);
			data += size + 2;
			break;}
		case 0xfd:{	// �S�g���b�N�t�F�[�h����
			int l;
			if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			DOUTR("\n[fade %d]\n", l);
			data += 2;
			break;}
		case 0xfe:	// �f�[�^�G���h/�i�v���[�v
			DOUTR("\n[EOD]\n");
			return;
		case 0xff:	// �i�v���[�v�|�C���g�}�[�N
			DOUTR("\n$ ");
			data++;
			break;
		default:	// �s��
			DOUTR("\n[%02X]", *data++);
			break;
		}
	}
}
#endif	// defined(_DEBUG)

MCDriver::MCDriver
(SoundStream *stream, File *file):
major_version(0),
minor_version(0),
title(NULL),
num_of_track(0),
track_data(0),
data(NULL),
datasize(0),
work(NULL),
system_work(NULL),
track_work(NULL),
ext_track_work(NULL),
fm(NULL),
pcm8(NULL),
stream(stream),
file(file)
{
}

MCDriver::~MCDriver
(void)
{
	if (NULL != stream) stream->SetTimerCallback(NULL);
	if (NULL != title) delete title;
	if (NULL != track_data) free(track_data);
	if (NULL != data) delete data;
	if (NULL != work) delete work;
	if (NULL != pcm8) delete pcm8;
	if (NULL != fm) delete fm;
}

bool
MCDriver::SetData
(const unsigned char *data, int datasize)
{
	if (NULL != this->data) delete this->data;
	this->data = new unsigned char[datasize];
	if (NULL == this->data) return false;
	this->datasize = datasize;
	memcpy(this->data, data, datasize);
	if (!CheckFormat()) return false;
	if (NULL != pcm8) delete pcm8;
	if (NULL != fm) delete fm;
	fm = new DeviceX68Sound((NULL == stream)? CDXS_STAND_ALONE: CDXS_CLIENT);
	if (NULL == fm) return false;
	if (NULL == stream) stream = fm;
	fm->Initialize();
	if (NULL != voice_data) {
		int num_of_voice = GET_WORD(&voice_data[4]);
		voice_data += 6;
		for (int v = 0; v < num_of_voice; v++) {
			DeviceX68Sound::VOICE voice;
			int size = GET_WORD(&voice_data[0]);
			int n = voice_data[3];
			int b = voice_data[2];
			memcpy(&voice, &voice_data[4], sizeof(DeviceX68Sound::VOICE));
			fm->SetVoiceData(n, &voice, b);
			voice_data += size;
		}
	}
	pcm8 = fm->DevicePCM8Create();
	if (NULL == pcm8) return false;
	pcm8->Initialize();
	if (NULL != adpcm_data) {
		File *f;
		if (NULL == file) f = new File();
		else f = file;
		if (NULL == f) return false;
		bool result = false;
		for (;;) {
			if (!f->Open((char *)adpcm_data, CFO_READ)) break;
			unsigned long size;
			if (!f->GetFileSize(size)) break;
			unsigned char *data = new unsigned char[size];
			if (NULL == data) break;
			if (!f->Read((char *)data, size) || !f->Close()) {
				delete data;
				break;
			}
			for (int c = 0; c < 96; c++) {
				int offset = GET_LONG(&data[c * 8 + 0]);
				int length = GET_LONG(&data[c * 8 + 4]);
				if (0 != offset) pcm8->SetVoiceData(c, &data[offset], length);
			}
			delete data;
			result = true;
			break;
		}
		if (NULL == file) delete f;
		if (!result) {
		}
	}
	for (int ch = 0; ch < num_of_track; ch++) {
		ext_track_work[ch].quo = 127;
		if (track_work[ch].curch < 8) ext_track_work[ch].sd = fm;
		else if (track_work[ch].curch < 0x20) ext_track_work[ch].sd = pcm8;
		track_work[ch].nowvolume = 8 << 3;
	}
	return true;
}

bool
MCDriver::Play
(void)
{
	if ((NULL == work) || (NULL == data) || (NULL == fm)) return false;
	stream->SetTimerCallback(this);
	stream->SetTimerInterval((double)(60.0 * 1000.0 / (double)((int)system_work->inf_division * (int)system_work->inf_tempo)));
	/**
	for(;;) {
	for (int i = 0; i < 8; i++) {
		DumpTrackWork(i);
		printf("\n");
	}
	Sleep(10);
	}
	/**/
	return true;
}

bool
MCDriver::Stop
(void)
{
	return false;
}

const unsigned char *
MCDriver::GetTitle
(void)
{
	return title;
}

int
MCDriver::GetCurrentLoopCount
(void)
{
	return system_work->inf_loop;
}

void
MCDriver::TimerCallback
(void)
{
//	HANDLE c = GetStdHandle(STD_OUTPUT_HANDLE);
//	COORD cp;
//	cp.X = cp.Y = 0;
//	SetConsoleCursorPosition(c, cp);
	int ch;
	for (ch = 0; ch < num_of_track; ch++) {
		if (track_work[ch].curch < 8) fm->SetActiveChannel(track_work[ch].curch);
		else if (track_work[ch].curch < 0x20) pcm8->SetActiveChannel(track_work[ch].curch - 0x10);
		Eval(&track_work[ch], &ext_track_work[ch]);
//		DumpTrackWork(ch);
	}
	int loop = 0x7fffffff;
	int max = -1;
	for (ch = 0; ch < num_of_track; ch++) {
		if ((loop > ext_track_work[ch].loop) && (0 <= ext_track_work[ch].loop)) loop = ext_track_work[ch].loop;
		if (max < ext_track_work[ch].loop) max = ext_track_work[ch].loop;
	}
	system_work->inf_loop = (-1 == max)? -1: loop;
}

void
MCDriver::Update
(short *buffer, int count)
{
	fm->Update(buffer, count);
}

LPSYSTEM_WORK
MCDriver::GetSystemWork
(void)
{
	return system_work;
}

LPTRACK_WORK
MCDriver::GetTrackWork
(void)
{
	return track_work;
}

LPEXT_TRACK_WORK
MCDriver::GetExtTrackWork
(void)
{
	return ext_track_work;
}

bool
MCDriver::CheckFormat
(void)
{
	DOUT("CheckFormat\n");
	if (datasize < (4 + 2 + 2 + 4)) {
		DOUT("invalid data size\n");
		return false;
	}
	if (0 != strncmp("MDC\032", (const char *)data, 4)) {
		DOUT("MDC$1a code not found\n");
		return false;
	}
	major_version = data[4];
	minor_version = data[5];
	DOUT("DataVersion: %d.%02d\n", major_version, minor_version);
	int header_size = GET_WORD(&data[6]);
	if (header_size < 0x30) {
		DOUT("invalid header size\n");
		return false;
	}
	int file_size = GET_LONG(&data[8]);
	if (0 == file_size) file_size = datasize;	// for compatibility
	if (file_size != datasize) {
		DOUT("filesize(%d) != datasize(%d)\n", file_size, datasize);
		return false;
	}
	int seq_offset = GET_LONG(&data[16]);
	int title_offset = GET_LONG(&data[20]);
	int ext_offset = GET_LONG(&data[24]);
	if (0 != ext_offset) voice_data = &data[ext_offset];
	else voice_data = NULL;
	int adpcm_offset = GET_LONG(&data[28]);
	if (0 != adpcm_offset) adpcm_data = &data[adpcm_offset];
	else adpcm_data = NULL;
	int midi_offset = GET_LONG(&data[32]);
	if ((seq_offset > datasize) || (title_offset > datasize) | (ext_offset > datasize) | (adpcm_offset > datasize) | (midi_offset > datasize)) {
		DOUT("invalid offset\n");
		return false;
	}
	char *end_of_title = strstr((const char *)&data[title_offset], "\r\n\032\0");
	if (NULL == end_of_title) end_of_title = strstr((const char *)&data[title_offset], "\r\n\0");
	if (NULL == end_of_title) {
		DOUT("invalid title\n");
		return false;
	}
	int title_size = end_of_title - (char *)&data[title_offset];
	DOUT("Title: ");
	DOUTRN((const char *)&data[title_offset], title_size);
	DOUTRN("\n", 1);
	if (NULL != title) delete title;
	title = new unsigned char[title_size + 1];
	if (NULL != title) {
		strncpy((char *)title, (char *)&data[title_offset], title_size);
		title[title_size] = 0;
	}
	int play_time = GET_LONG(&data[36]);
	int play_time_minute = play_time >> 16;
	int play_time_second = play_time & 0xffff;
	DOUT("Time: %02d:%02d\n", play_time_minute, play_time_second);
	int all_clock_count = GET_LONG(&data[40]);
	int base_clock_count = GET_WORD(&data[44]);
	if (0 == base_clock_count) base_clock_count = 48;	// for compatibility
	int tempo = GET_WORD(&data[46]);
	if (0 == tempo) tempo = 120;
	DOUT("Clock: %d (/%d)\n", all_clock_count, base_clock_count);
	DOUT("Tempo: %d\n", tempo);

	if ((seq_offset + 2) > datasize) {
		DOUT("invalid sequence offset\n");
		return false;
	}
	const unsigned char *seq_header = &data[seq_offset];
	if (NULL != track_data) free(track_data);
	num_of_track = GET_WORD(&seq_header[0]);
	DOUT("Track: %d\n", num_of_track);
	if ((seq_offset + 2 + 8 * num_of_track) > datasize) {
		DOUT("invalid track offset\n");
		return false;
	}
	track_data = (unsigned char **)malloc(sizeof(unsigned char *) * num_of_track);
	if (NULL != work) delete work;
	work = new unsigned char[sizeof(SYSTEM_WORK) + (sizeof(TRACK_WORK) + sizeof(EXT_TRACK_WORK)) * num_of_track];
	if ((NULL == work) || (NULL == track_data)) return false;
	ZeroMemory(work, sizeof(SYSTEM_WORK) + (sizeof(TRACK_WORK) + sizeof(EXT_TRACK_WORK)) * num_of_track);
	system_work = (LPSYSTEM_WORK)work;
	track_work = (LPTRACK_WORK)(work + sizeof(SYSTEM_WORK));
	ext_track_work = (LPEXT_TRACK_WORK)(work + sizeof(SYSTEM_WORK) + sizeof(TRACK_WORK) * num_of_track);
	for (int i = 0; i < num_of_track; i++) {
		const unsigned char *track_header = &seq_header[2 + i * 8];
		int track_offset = GET_LONG(&track_header[0]) + seq_offset;
		DOUT(" #%d: ", track_header[4]);
		if (track_header[5] < 0x08) {
			DOUTR("OPM %d", track_header[5] + 1);
		} else if (track_header[5] < 0x20) {
			DOUTR("ADPCM %d", track_header[5] - 0x08 + 1);
		} else {
			DOUTR("MIDI %d", track_header[5] - 0x20 + 1);
		}
		track_work[i].curch = track_header[5];
		DOUTR(", $%08x\n", track_offset);
#if defined(_DEBUG)
		DisTrack(&data[track_offset]);
#endif	// defined(_DEBUG)
		track_data[i] = &data[track_offset];
		track_work[i].mmlptr = (unsigned long)track_data[i];
		ext_track_work[i].step = -1;
		ext_track_work[i].gate = 1;
		track_work[i].volmst = 127;
	}
	system_work->inf_division = base_clock_count;
	system_work->inf_tempo = tempo;
	system_work->inf_trnum = num_of_track;
	return true;
}

#if defined(_DEBUG)
void
MCDriver::DumpTrackWork
(int track)
{
	char *work = (char *)&track_work[track];
	int line = (sizeof(TRACK_WORK) - 1) / 16;
//	line = 1;
	for (int l = 0; l <= line; l++) {
		int last = (l == line)? (sizeof(TRACK_WORK) % 16): 16;
		int i;
		for (i = 0; i < last; i++) {
			printf("%02X ", (*work++) & 0xff);
		}
		for (; i < 16; i++) {
			printf("00 ");
		}
		printf("\n");
	}
//	return;

	printf("-\n");
	work = (char *)&ext_track_work[track];
	line = (sizeof(EXT_TRACK_WORK) - 1) / 16;
	for (l = 0; l <= line; l++) {
		int last = (l == line)? (sizeof(EXT_TRACK_WORK) % 16): 16;
		int i;
		for (i = 0; i < last; i++) {
			printf("%02X ", (*work++) & 0xff);
		}
		for (; i < 16; i++) {
			printf("00 ");
		}
		printf("\n");
	}
	printf("-\n");
}
#endif	//	defined(_DEBUG)

void
MCDriver::Eval
(LPTRACK_WORK work, LPEXT_TRACK_WORK ext_work)
{
	static int v16to128[17] = {	// ZMUSIC�����Ȃ̂�17�i�K�̃e�[�u���ɂȂ��Ă���
		85, 87, 90, 93, 95, 98, 101, 103, 106, 109, 111, 114, 117, 119, 122, 125, 127,
	};
	if (work->active || work->waitsignal) return;

	bool pitch_flag = false;;
	if (0 != (work->event & TRACK_EVENT_PORT_MASK)) {
		ext_work->por_count++;
		if (ext_work->por_count == ext_work->por_step) {
			work->event &= ~TRACK_EVENT_PORT_MASK;
			work->waspitch = work->nowpitch + ext_work->por_target;
		} else {
			work->waspitch = work->nowpitch + ext_work->por_target * ext_work->por_count / ext_work->por_step;
		}
		pitch_flag = true;
	} else {
		work->waspitch = work->nowpitch;
	}

	if (0 != (work->event & TRACK_EVENT_PLFO_MASK)) {
		if (ext_work->pitch_lfo_delay_count > ext_work->pitch_lfo_delay) {
			// LFO (type 2 only)
			ext_work->pitch_lfo_delta += ext_work->pitch_lfo_vector;
			work->waspitch += ext_work->pitch_lfo_delta;	// nowpitch + <port> + lfo
			pitch_flag = true;
			if (((ext_work->pitch_lfo_vector > 0) && (ext_work->pitch_lfo_delta_high < ext_work->pitch_lfo_delta)) || 
				((ext_work->pitch_lfo_vector < 0) && (ext_work->pitch_lfo_delta_low > ext_work->pitch_lfo_delta))) {
				ext_work->pitch_lfo_vector = -ext_work->pitch_lfo_vector;
			}
		} else {
			if (ext_work->pitch_lfo_delay_count == ext_work->pitch_lfo_delay) {
				// LFO START
				ext_work->pitch_lfo_delta = 0;
				ext_work->pitch_lfo_vector = (ext_work->pitch_lfo_amp < 0)? -ext_work->pitch_lfo_speed: ext_work->pitch_lfo_speed;
				if (ext_work->pitch_lfo_amp > 0) {
					ext_work->pitch_lfo_delta_high = ext_work->pitch_lfo_amp / 2;
					ext_work->pitch_lfo_delta_low = ext_work->pitch_lfo_delta_high - ext_work->pitch_lfo_amp;
				} else {
					ext_work->pitch_lfo_delta_low = ext_work->pitch_lfo_amp / 2;
					ext_work->pitch_lfo_delta_high = ext_work->pitch_lfo_delta_high - ext_work->pitch_lfo_amp;
				}
			}
			ext_work->pitch_lfo_delay_count++;
		}
	}
	if (pitch_flag) ext_work->sd->SetPitch(work->waspitch);

	if (0 != (work->event & TRACK_EVENT_ALFO_MASK)) {
		if (ext_work->amp_lfo_delay_count > ext_work->amp_lfo_delay) {
			// LFO (type 2 only)
			ext_work->amp_lfo_delta += ext_work->amp_lfo_vector;
			work->wasvolume = work->nowvolume + (ext_work->amp_lfo_delta >> 2);	// ???
			ext_work->sd->SetVolume(work->wasvolume + work->volmst - 127);
			if (((ext_work->amp_lfo_vector > 0) && (ext_work->amp_lfo_delta_high < ext_work->amp_lfo_delta)) ||
				((ext_work->amp_lfo_vector < 0) && (ext_work->amp_lfo_delta_low > ext_work->amp_lfo_delta))) {
				ext_work->amp_lfo_vector = -ext_work->amp_lfo_vector;
			}
		} else {
			if (ext_work->amp_lfo_delay_count == ext_work->amp_lfo_delay) {
				// LFO START
				ext_work->amp_lfo_delta = 0;
				ext_work->amp_lfo_vector = (ext_work->amp_lfo_amp < 0)? -ext_work->amp_lfo_speed: ext_work->amp_lfo_speed;
				if (ext_work->amp_lfo_vector > 0) {
					ext_work->amp_lfo_delta_high = ext_work->amp_lfo_amp;
					ext_work->amp_lfo_delta_low = ext_work->amp_lfo_delta_high - ext_work->amp_lfo_amp;
				} else {
					ext_work->amp_lfo_delta_low = ext_work->amp_lfo_amp;
					ext_work->amp_lfo_delta_high = ext_work->amp_lfo_delta_high - ext_work->amp_lfo_amp;
				}
			}
			ext_work->amp_lfo_delay_count++;
		}
	}
	ext_work->gate--;
	if (0 != ext_work->gate) return;

	if (-1 != ext_work->step) {
		if (!ext_work->tie) ext_work->sd->KeyOff();
		ext_work->gate = ext_work->step;
		ext_work->step = -1;
		if (0 != ext_work->gate) return;
	}
	if (!ext_work->tie) {
		ext_work->pitch_lfo_delay_count = 0;
		ext_work->amp_lfo_delay_count = 0;
	}
	else ext_work->tie = false;

	unsigned char *data = (unsigned char *)work->mmlptr;
	for (;;) {
//		DOUTR("[%02X %02X %02X %02X]\n", data[0], data[1], data[2], data[3]);
		work->nowstep++;
		if (data[0] < 0x80) {
			int note = data[0] + ext_work->key_trans;
			work->nowpitch = note * 64 + ext_work->tune;
			if (data[1] >= 0x80) {
				ext_work->step = ext_work->gate = data[1] & 0x7f;
				data += 2;
			} else {
				int v = data[1];
				int step;
				if (data[2] & 0x80) {
					step = ((data[2] & 0x7f) << 7) + data[3];
					data++;
				} else {
					step = data[2];
				}
				int gate;
				if (data[3] & 0x80) {
					gate = ((data[3] & 0x7f) << 7) + data[4];
					data++;
				} else {
					gate = data[3];
				}
				if (0 != v) work->nowvolume = v;
				ext_work->step = step;
				ext_work->gate = gate;
				data += 4;
			}
			ext_work->sd->SetPitch(work->nowpitch);
			ext_work->sd->SetVolume(work->nowvolume + work->volmst - 127);
			ext_work->gate = ext_work->gate * ext_work->quo / 128;
			if (0 == ext_work->gate) ext_work->gate = 1;
			ext_work->step -= ext_work->gate;
			if (ext_work->hard_lfo_sync) fm->Write(0x01, 0x02);
			ext_work->sd->KeyOn();
			ext_work->key_on = work->nowvolume + work->volmst - 127;
			goto eval_quit;
		}
		switch (*data) {
		case 0x80:{	// �x��
			int l;
			if (data[1] == 0xff) {	// for compatibility (0x80, 0xff, 0xfc sequence)
				data += 3;
				break;
			} else if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			ext_work->step = -1;
			ext_work->gate = l;
			data += 2;
			ext_work->sd->KeyOff();
			goto eval_quit;}
		case 0x81:{	// ����
			int note = data[1] + ext_work->key_trans;
			work->nowpitch = note * 64 + ext_work->tune;
			int l;
			if (data[2] & 0x80) {
				l = ((data[2] & 0x7f) << 7) + data[3];
				data++;
			} else {
				l = data[2];
			}
			ext_work->step = ext_work->gate = l;
			data += 3;
			ext_work->sd->SetPitch(work->nowpitch);
			ext_work->sd->SetVolume(work->nowvolume + work->volmst - 127);
			ext_work->gate = ext_work->gate * ext_work->quo / 128;
			if (0 == ext_work->gate) ext_work->gate = 1;
			ext_work->step -= ext_work->gate;
			if (ext_work->hard_lfo_sync) fm->Write(0x01, 0x02);
			ext_work->sd->KeyOn();
			ext_work->key_on = work->nowvolume + work->volmst - 127;
			goto eval_quit;}
		case 0x86:	// �^�C�i�X���[�j
			ext_work->tie = true;
			data++;
			break;
		case 0x88:	// ���s�[�g�J�n
			ext_work->repeat_count = data[2] = 1;
			data += 3;
			break;
		case 0x89:{	// ���s�[�g�I�[
			int offset = (short)GET_WORD(&data[1]);
			if (data[3 + offset + 1] == data[3 + offset + 2]) {
				data += 3;
			} else {
				ext_work->repeat_count = ++data[3 + offset + 2];
				data = &data[3 + offset + 3];
			}
			break;}
		case 0x8a:{	// ���s�[�g�����o��
			int end_offset = (short)GET_WORD(&data[1]);
			int start_offset = (short)GET_WORD(&data[3 + end_offset + 1]);
			if (data[3 + end_offset + 3 + start_offset + 1] == data[3 + end_offset + 3 + start_offset + 2]) {
				data += 3 + end_offset + 3;
			} else {
				data += 3;
			}
			break;}
		case 0x8b:{	// ���s�[�g�񐔎w��t�����o��
			int skip_offset = (short)GET_WORD(&data[2]);
			if (ext_work->repeat_count != data[1]) data = &data[4 + skip_offset];
			else data += 4;
			break;}
		case 0x8c:{	// OPMDRV�n [�`] �R�}���h
			switch (data[1]) {
			case 0:
			case 1:
			case 2:{
				int offset = (short)GET_WORD(&data[2]);
				data = &data[4 + offset];
				break;}
			case 3:
			case 4:
				data += 2;
				break;
			case 5:
				ext_work->loop = -1;
				work->active = -1;
				break;
			}
			break;}
		case 0x8d:{	// �W�����v
			int offset = (short)GET_WORD(&data[1]);
			data = &data[3 + offset];
			break;}
		case 0x8e:	// ���ߏI���
			work->nowbar++;
			work->nowstep = 0;
			data++;
			break;
		case 0x8f:	// �Z�[�����W���[
			data = &data[ 3 + (short)GET_WORD(&data[1])];
			break;
		case 0xa0:	// �x���V�e�B�ݒ�
		case 0xa2:	// �{�����[���i�G�N�X�v���b�V�����j�ݒ�
		case 0xa4:	// �g���b�N�{�����[���ݒ�
			if (data[1] < 0x80) {
				work->nowvolume = data[1];
				ext_work->volume16 = -1;
			} else {
				ext_work->volume16 = data[1] - 0x80;
				if (work->curch < 8) work->nowvolume = v16to128[ext_work->volume16];
				else {
					work->nowvolume = ext_work->volume16 * 8;
				}
			}
			data += 2;
			break;
		case 0xa1:	// ���΃x���V�e�B�ݒ�
		case 0xa3:	// ���΃{�����[���i�G�N�X�v���b�V�����ݒ�
		case 0xa5:	// ���΃g���b�N�{�����[���ݒ�
//			if (ext_work->volume16 != -1) {
//				ext_work->volume16 += (char)data[1];
//				work->nowvolume = v16to128[ext_work->volume16];
//			} else {
				work->nowvolume += (char)data[1];
//			}
			data += 2;
			break;
		case 0xa6:	// �p���|�b�g�ݒ�
			if (data[1] < 0x80) {
				work->panmst = data[1];
			} else if (data[1] < 0x90) {
				work->panmst = (data[1] - 0x80) * 8;
			} else {
				switch (data[1]) {
				case 0xf0:
					work->panmst = 0xff;	// OFF
					break;
				case 0xf1:
					work->panmst = 0x00;	// L
					break;
				case 0xf2:
					work->panmst = 0x7f;	// R
					break;
				case 0xf3:
					work->panmst = 0x40;	// C
					break;
				}
			}
			ext_work->sd->SetPan(work->panmst);
			data += 2;
			break;
		case 0xa7:	// ���΃p���|�b�g�ݒ�
			work->panmst += (char)data[1];
			ext_work->sd->SetPan(work->panmst);
			data += 2;
			break;
		case 0xa8:	// �g���b�N�P�ʃL�[�g�����X�|�[�Y�ݒ�
			ext_work->key_trans = (char)data[1];
			data += 2;
			break;
		case 0xa9:	// ���΃g���b�N�P�ʃL�[�g�����X�|�[�Y�ݒ�
			ext_work->key_trans += (char)data[1];
			data += 2;
			break;
		case 0xaa:	// �x���h�����W�ݒ�
			work->bendrange = data[1];
			data += 2;
			break;
		case 0xab:	// ���΃x���h�����W�ݒ�
			work->bendrange += (char)data[1];
			data += 2;
			break;
		case 0xac:	// �f�`���[���ݒ�
			ext_work->tune = (char)data[1];
			data += 2;
			break;
		case 0xad:	// ���΃f�`���[���ݒ�
			ext_work->tune += (char)data[1];
			data += 2;
			break;
		case 0xae:	// �N�I���^�C�Y�ݒ�
			if (data[1] <= 0x08) ext_work->quo = data[1] * 16;
			else ext_work->quo = data[1] & 0x7f + 1;
			data += 2;
			break;
		case 0xaf:	// ���΃N�I���^�C�Y�ݒ�
			ext_work->quo += (char)data[1];
			data += 2;
			break;
		case 0xb0:	// �`���[���ݒ�
			ext_work->tune = (short)GET_WORD(&data[1]);
			data += 3;
			break;
		case 0xb1:	// ���΃`���[���ݒ�
			ext_work->tune += (short)GET_WORD(&data[1]);
			data += 3;
			break;
		case 0xb2:	// �x���h�ݒ�
			work->bend = (short)GET_WORD(&data[1]);
			data += 3;
			break;
		case 0xb3:	// ���΃x���h�ݒ�
			work->bend = (short)GET_WORD(&data[1]);
			data += 3;
			break;
		case 0xb8:	// �|���^�����g
			ext_work->por_target = (short)GET_WORD(&data[1]);
			if (data[3] & 0x80) {
				ext_work->por_step = ((data[3] & 0x7f) << 7) + data[4];
				data++;
			} else {
				ext_work->por_step = data[3];
			}
			ext_work->por_count = 0;
			work->event |= TRACK_EVENT_PORT_MASK;
//			DOUT("POR : %d, %d\n", ext_work->por_target, ext_work->por_step);
			data += 4;
			break;
		case 0xb9:{	// �t���^�C���|���^�����g
			int l;
			if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			ext_work->fulltime_por = l;
			data += 2;
			break;}
		case 0xc0:	// �s�b�`LFO�g�`�ݒ�
			if (0x80 == data[1]) work->event &= ~TRACK_EVENT_PLFO_MASK;
			else {
				if (0x81 != data[1]) ext_work->pitch_lfo_type = data[1];
				work->event |= TRACK_EVENT_PLFO_MASK;
			}
			data += 2;
			break;
		case 0xc1:{	// �s�b�`LFO�X�s�[�h�ݒ�
			int l;
			if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			ext_work->pitch_lfo_speed = l;
			data += 2;
			break;}
		case 0xc2:	// �s�b�`LFO�U���ݒ�
			ext_work->pitch_lfo_amp = (short)GET_WORD(&data[1]);
			data += 3;
			break;
		case 0xc3:	// �s�b�`LFP���ΐU���ݒ�
			ext_work->pitch_lfo_amp += (short)GET_WORD(&data[1]);
			data += 3;
		case 0xc4:{	// �s�b�`LFO�f�B���C�ݒ�
			int l;
			if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			ext_work->pitch_lfo_delay = l;
			data += 2;
			break;}
		case 0xc5:	// ����LFO�g�`�ݒ�
			if (0x80 == data[1]) work->event &= ~TRACK_EVENT_ALFO_MASK;
			else {
				if (0x81 != data[1]) ext_work->amp_lfo_type = data[1];
				work->event |= TRACK_EVENT_ALFO_MASK;
			}
			data += 2;
			break;
		case 0xc6:{	// ����LFO�X�s�[�h�ݒ�
			int l;
			if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			ext_work->amp_lfo_speed = l;
			data += 2;
			break;}
		case 0xc7:	// ����LFO�U���ݒ�
			ext_work->amp_lfo_amp = (char)data[1];
			data += 2;
			break;
		case 0xc9:{	// ����LFO�f�B���C�ݒ�
			int l;
			if (data[1] & 0x80) {
				l = ((data[1] & 0x7f) << 7) + data[2];
				data++;
			} else {
				l = data[1];
			}
			ext_work->amp_lfo_delay = l;
			data += 2;
			break;}
		case 0xe0:	// �v���O�����`�F���W
			work->banklsb = data[1] >> 7;
			work->program = data[1] & 0x7f;
			ext_work->sd->SetVoice(work->program, work->banklsb);
			data += 2;
			break;
		case 0xe1:	// �o���N���v���O�����`�F���W
			work->banklsb = data[1];
			work->program = data[2];
			ext_work->sd->SetVoice(work->program, work->banklsb);
			data += 3;
			break;
		case 0xe2:	// ����f�o�C�X�ύX
			work->curch = data[1];
			fm->SetActiveChannel(work->curch);
			DOUTR("\n@!%d\n", data[1]);
			data += 2;
			break;
		case 0xe5:	// ADPCM�Đ����g���ݒ�
			if (NULL != pcm8) pcm8->SetPlayMode(data[1]);
			data += 2;
			break;
		case 0xe6:	// OPM�z���C�g�m�C�Y�ݒ�
			fm->Write(0x0f, data[1]);
			data += 2;
			break;
		case 0xe7:	// OPM�n�[�hLFO�ݒ�
			if (data[1] == 0x80) {
				if (work->curch < 8) fm->Write(0x38 + work->curch, 0);
				data += 2;
			} else if (data[1] == 0x81) {
				if (work->curch < 8) fm->Write(0x38 + work->curch, ext_work->hard_lfo_pms_ams = data[5]);
				data += 2;
			} else {
				if (work->curch < 8) {
					if(data[1] & 0x40) ext_work->hard_lfo_sync = true;
					else ext_work->hard_lfo_sync = false;
					fm->Write(0x1b, data[1] & 0x3);
					fm->Write(0x18, data[2]);
					fm->Write(0x19, 0x80 | data[3]);
					fm->Write(0x19, data[4]);
					fm->Write(0x38 + work->curch, data[5]);
					ext_work->hard_lfo_pms_ams = data[5];
				}
//				DOUTR("[LFO %d, %d, %d, %d, %d]\n", data[1], data[2], data[3], data[4], data[5]);
				data += 6;
			}
			break;
		case 0xe8:	// OPM���W�X�^�ݒ�
			fm->Write(data[1], data[2]);
			data += 3;
			break;
		case 0xec:	// �R���g���[���`�F���W
			DOUTR("\n[CTLCHG %d, %d]\n", data[1], data[2]);
			data += 3;
			break;
		case 0xef:	// �g���b�N�o���G�[�V����
			data += 2;
			break;
		case 0xf0:{	// �e���|�ݒ�
			system_work->inf_tempo = GET_WORD(&data[1]);
			double interval;
			interval = (double)(60.0 * 1000.0 / (double)((int)system_work->inf_division * (int)system_work->inf_tempo));
			interval = (double)(60.0 * 1000.0 / (double)((int)system_work->inf_division * (int)system_work->inf_tempo));	// against VC bug
			stream->SetTimerInterval(interval);
			data += 3;
			break;}
		case 0xf6:	// �����L�[�g�����X�|�[�Y
			DOUTR("[kt %d]", (signed char)data[1]);
			data += 2;
			break;
		case 0xf7:	// �������΃L�[�g�����X�|�[�Y
			DOUTR("[kt+ %d]", (signed char)data[1]);
			data += 2;
			break;
		case 0xfc:{	// �R�����g
			int size = data[1];
			int val = data[2];
			DOUTR(" /* (%d:%d) %s */\n", size, val, &data[3]);
			data += size + 2;
			break;}
		case 0xfd:	// �S�g���b�N�t�F�[�h����
			DOUTR("\n[fade %d]\n", data[1]);
			data += 2;
			break;
		case 0xfe:{	// �f�[�^�G���h/�i�v���[�v
			int offset = (short)GET_WORD(&data[1]);
			if (0 == offset) {
				DOUTR("\n[EOD]\n");
				ext_work->loop = -1;
				return;
			}
			ext_work->loop++;
			data = &data[3 + offset];
			DOUTR("[LOOP]\n");
			break;}
		case 0xff:	// �i�v���[�v�|�C���g�}�[�N
			data++;
			break;
		default:	// �s��
			DOUTR("[[%02X]]\n", data[0]);
			data++;
			break;
		}
	}
eval_quit:
	work->mmlptr = (unsigned long)data;
}
