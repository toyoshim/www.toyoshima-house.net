#include "File.h"

File::File
(void):
fh(INVALID_HANDLE_VALUE),
filesize((unsigned long)-1)
{
}

File::~File
(void)
{
	Close();
}

bool
File::Create
(const char *filename, int flags)
{
	Close();
	DWORD access = ((CFC_READ == (flags & CFC_READ))? GENERIC_READ: 0) |
		((CFC_WRITE == (flags & CFC_WRITE))? (GENERIC_READ | GENERIC_WRITE): 0);
	DWORD share = 0;
	DWORD disposition = (CFC_OVERRIDE == (flags & CFC_OVERRIDE))? CREATE_ALWAYS: CREATE_NEW;
	fh = CreateFile(filename, access, share, NULL, disposition, FILE_ATTRIBUTE_ARCHIVE, NULL);
	return (INVALID_HANDLE_VALUE != fh);
}

bool
File::Open
(const char *filename, int flags)
{
	Close();
	DWORD access = ((CFO_READ == (flags & CFO_READ))? GENERIC_READ: 0) |
		((CFO_WRITE == (flags & CFO_WRITE))? (GENERIC_READ | GENERIC_WRITE): 0);
	DWORD share = 0;
	DWORD disposition = (CFO_CREATE == (flags & CFO_CREATE))? OPEN_ALWAYS: OPEN_EXISTING;
	fh = CreateFile(filename, access, share, NULL, disposition, FILE_ATTRIBUTE_ARCHIVE, NULL);
	filesize = -1;
	return (INVALID_HANDLE_VALUE != fh);
}

bool
File::Close
(void)
{
	if (INVALID_HANDLE_VALUE == fh) return false;
	bool result = (TRUE == CloseHandle(fh));
	fh = INVALID_HANDLE_VALUE;
	if (result) filesize = -1;
	return result;
}

bool
File::Seek
(long offset, int mode)
{
	if (INVALID_HANDLE_VALUE == fh) return false;
	DWORD method;
	switch (mode) {
	case CFS_BEGIN:
		method = FILE_BEGIN;
		break;
	case CFS_CURRENT:
		method = FILE_CURRENT;
		break;
	case CFS_END:
		method = FILE_END;
		break;
	}
	return (-1 != SetFilePointer(fh, offset, NULL, method));
}

bool
File::GetPosition
(unsigned long &pos)
{
	if (INVALID_HANDLE_VALUE == fh) return false;
	pos = SetFilePointer(fh, 0, NULL, FILE_CURRENT);
	return (-1 != pos);
}

bool
File::GetFileSize
(unsigned long &size)
{
	if (INVALID_HANDLE_VALUE == fh) return false;
	if ((unsigned long)-1 == filesize) filesize = ::GetFileSize(fh, NULL);
	size = filesize;
	return (-1 != size);
}

bool
File::Read
(char *buffer, unsigned long &size)
{
	if (INVALID_HANDLE_VALUE == fh) return false;
	return (0 != ReadFile(fh, (LPVOID)buffer, size, &size, NULL));
}

bool
File::Write
(char *buffer, unsigned long &size)
{
	if (INVALID_HANDLE_VALUE == fh) return false;
	return (0 != WriteFile(fh, (LPVOID)buffer, size, &size, NULL));
}
