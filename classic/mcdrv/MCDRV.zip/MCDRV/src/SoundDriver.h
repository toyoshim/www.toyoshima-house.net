#if !defined(__SoundDriver_h__)
#	define	__SoundDriver_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

abstract class SoundDriver{
public:
	virtual ~SoundDriver(void){};

	virtual bool SetData(const unsigned char *data, int datasize) = 0;
	virtual bool Play(void) = 0;
	virtual bool Stop(void) = 0;

	virtual const unsigned char *GetTitle(void) = 0;
	virtual int GetCurrentLoopCount(void) = 0;

	virtual void TimerCallback(void) = 0;
	virtual void Update(short *buffer, int count) = 0;
};

#	if !defined(__SoundDriver__)
#		define	__SoundDriver__
#	endif	// !defined(__SoundDriver__)

#endif	// !defined(__SoundDriver_h__)
