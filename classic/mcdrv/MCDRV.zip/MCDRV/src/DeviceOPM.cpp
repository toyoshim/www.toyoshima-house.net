#include "DeviceOPM.h"

DeviceOPM::DeviceOPM
(void):
active_channel(0)
{
	for (int i = 0; i < 8; i++) {
		voice_number[i] = 0;
		bank_number[i] = 0;
		pan[i] = 0xc0;
		volume[i] = 0;
	}
	ZeroMemory(voice[0], sizeof(VOICE) * 128);
	ZeroMemory(voice[1], sizeof(VOICE) * 128);
}

DeviceOPM::~DeviceOPM
(void)
{
}

void
DeviceOPM::SetPitch
(int pitch)
{
	char note[12] = { 0, 1, 2, 4, 5, 6, 8, 9, 10, 12, 13, 14 };
	pitch -= 64 * 15 - 5;
	int tone = pitch / 64;
	pitch %= 64;
	int oct = tone / 12;
	oct &= 0x7;
	tone %= 12;
	Write(0x30 + active_channel, pitch << 2);
	Write(0x28 + active_channel, (oct << 4) + note[tone]);
}

#define	GET_VOL(t, v)	(t + 127 - v)
#define	MAKE_VOL(v)		{ \
	if (v < 0) v = 0; \
	else if (v > 127) v = 127; \
}

void
DeviceOPM::SetVolume
(int volume)
{
//	DOUT("vol %d : %d\n", active_channel, volume);
	this->volume[active_channel] = volume;
	int n = voice_number[active_channel];
	int b = bank_number[active_channel];
	int conn = voice[b][n].fl_con & 7;
	int v =	GET_VOL(voice[b][n].tl[3], volume);
	MAKE_VOL(v);
	Write(0x78 + active_channel, v);	// C2
	if (0 == (conn & 4)) return;
	v = GET_VOL(voice[b][n].tl[2], volume);
	MAKE_VOL(v);
	Write(0x70 + active_channel, v);	// C1
	if (4 == conn) return;
	v = GET_VOL(voice[b][n].tl[1], volume);
	MAKE_VOL(v);
	Write(0x68 + active_channel, v);	// M2
	if (7 != conn) return;
	v = GET_VOL(voice[b][n].tl[0], volume);
	MAKE_VOL(v);
	Write(0x60 + active_channel, v);	// M1
}

void
DeviceOPM::SetVoice
(int voice, int bank)
{
	LPVOICE v = &this->voice[bank][voice];

	Write(0x20 + active_channel, v->fl_con + pan[active_channel]);
	Write(0x40 + active_channel, v->dt1_mul[0]);
	Write(0x48 + active_channel, v->dt1_mul[1]);
	Write(0x50 + active_channel, v->dt1_mul[2]);
	Write(0x58 + active_channel, v->dt1_mul[3]);
	Write(0x60 + active_channel, v->tl[0]);
	Write(0x68 + active_channel, v->tl[1]);
	Write(0x70 + active_channel, v->tl[2]);
	Write(0x78 + active_channel, v->tl[3]);
	Write(0x80 + active_channel, v->ks_ar[0]);
	Write(0x88 + active_channel, v->ks_ar[1]);
	Write(0x90 + active_channel, v->ks_ar[2]);
	Write(0x98 + active_channel, v->ks_ar[3]);
	Write(0xa0 + active_channel, v->ams_d1r[0]);
	Write(0xa8 + active_channel, v->ams_d1r[1]);
	Write(0xb0 + active_channel, v->ams_d1r[2]);
	Write(0xb8 + active_channel, v->ams_d1r[3]);
	Write(0xc0 + active_channel, v->dt2_d2r[0]);
	Write(0xc8 + active_channel, v->dt2_d2r[1]);
	Write(0xd0 + active_channel, v->dt2_d2r[2]);
	Write(0xd8 + active_channel, v->dt2_d2r[3]);
	Write(0xe0 + active_channel, v->d1l_rr[0]);
	Write(0xe8 + active_channel, v->d1l_rr[1]);
	Write(0xf0 + active_channel, v->d1l_rr[2]);
	Write(0xf8 + active_channel, v->d1l_rr[3]);
	voice_number[active_channel] = voice;
	bank_number[active_channel] = bank;

	SetVolume(volume[active_channel]);
}

void
DeviceOPM::SetPan
(int pan)
{
	int n = voice_number[active_channel];
	int b = bank_number[active_channel];
	int fl_con = voice[b][n].fl_con;
	if (pan < 0x2b) {
		// L
		this->pan[active_channel] = 0x40;
	} else if (pan < 0x55) {
		// C
		this->pan[active_channel] = 0xc0;
	} else if (pan < 0x80) {
		// R
		this->pan[active_channel] = 0x80;
	} else {
		// OFF
	}
	fl_con |= this->pan[active_channel];
	Write(0x20 + active_channel, fl_con);
}

void
DeviceOPM::KeyOn
(void)
{
	int mask = voice[bank_number[active_channel]][voice_number[active_channel]].slot_mask;
	Write(0x08, (mask << 3) + active_channel);
}

void
DeviceOPM::KeyOff
(void)
{
	Write(0x08, active_channel);
}

void
DeviceOPM::SetActiveChannel
(int channel)
{
	if (channel < 8) active_channel = channel;
}

bool
DeviceOPM::SetVoiceData
(int n, LPVOICE voice, int bank)
{
	DOUT("STORE @%d\n", n);
	this->voice[bank][n] = *voice;
	return true;
}
