#if !defined(__SoundDevice_h__)
#	define	__SoundDevice_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

abstract class SoundDevice{
public:
	virtual ~SoundDevice(void){};

	virtual bool Initialize(void) = 0;
	virtual void Update(short *buffer, int count) = 0;

	virtual void SetPitch(int pitch) = 0;
	virtual void SetVolume(int volume) = 0;
	virtual void SetVoice(int voice, int bank = 0) = 0;
	virtual void SetPan(int pan) = 0;
	virtual void KeyOn(void) = 0;
	virtual void KeyOff(void) = 0;
	virtual void SetActiveChannel(int channel) = 0;
};

#	if !defined(__SoundDevice__)
#		define	__SoundDevice__
#	endif	// !defined(__SoundDevice__)

#endif	// !defined(__SoundDevice_h__)
