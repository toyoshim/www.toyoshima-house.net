#include "LocalFile.h"

LocalFile::LocalFile
(const char *path)
{
	SetLocalPath(path);
}

bool
LocalFile::Create
(const char *filename, int flags)
{
	char fullpath[_MAX_PATH];
	FixFileName(fullpath, _MAX_PATH, filename);
	return File::Create(fullpath, flags);
}

bool
LocalFile::Open
(const char *filename, int flags)
{
	char fullpath[_MAX_PATH];
	FixFileName(fullpath, _MAX_PATH, filename);
	DOUT("OPEN %s\n", fullpath);
	return File::Open(fullpath, flags);
}

bool
LocalFile::Close
(void)
{
	bool result = File::Close();
	if (result && (0 != *tmp_file)) {
		DOUT("CLOSE\n");
		DeleteFile(tmp_file);
		*tmp_file = 0;
	}
	return result;
}

bool
LocalFile::SetLocalPath
(const char *path)
{
	if (NULL == path) *this->path = 0;
	else _snprintf(this->path, _MAX_PATH, "%s\\", path);
	return true;
}

void
LocalFile::FixFileName
(char *dst, int dst_size, const char *src)
{
	const char *lastdot = src;
	for (const char *p = src; 0 != *p; p++) if ('.' == *p) lastdot = p + 1;
	if (0 == stricmp(lastdot, "MDX")) {
		char tmp_path[_MAX_PATH];
		char tmp[_MAX_PATH];
		GetTempPath(_MAX_PATH, tmp_path);
		GetTempFileName(tmp_path, "MCDRV", time(NULL), tmp);
		File f;
		f.Create(tmp, CFC_WRITE);
		f.Close();
		GetShortPathName(tmp, tmp_file, _MAX_PATH);
		char src_long[_MAX_PATH];
		char src_short[_MAX_PATH];
		_snprintf(src_long, _MAX_PATH, "%s%s", path, src);
		GetShortPathName(src_long, src_short, _MAX_PATH);
		char command[1024];
		_snprintf(command, 1024, "run68.exe mdx2mdc -o -q %s %s", src_short, tmp_file);
		PROCESS_INFORMATION pi;
		STARTUPINFO si;
		ZeroMemory(&si, sizeof(STARTUPINFO));
		si.cb = sizeof(STARTUPINFO);
		DOUT("%s\n", command);
		CreateProcess(NULL, command, NULL, NULL, false, NORMAL_PRIORITY_CLASS | DETACHED_PROCESS, NULL, NULL, &si, &pi);
		CloseHandle(pi.hThread);
		WaitForSingleObject(pi.hProcess, INFINITE);
		CloseHandle(pi.hProcess);
		_snprintf(dst, dst_size, "%s", tmp_file);
		return;
	}
	_snprintf(dst, dst_size, "%s%s", path, src);
	*tmp_file = 0;
}
