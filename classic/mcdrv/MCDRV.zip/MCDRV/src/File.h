#if !defined(__File_h__)
#define	__File_h__

#if !defined(__Common_h__)
#	include "Common.h"
#endif	// !defined(__Common_h__)

class File{
#	define	CF_READ			(1 << 0)
#	define	CF_WRITE		(1 << 1)
#	define	CF_FORCE		(1 << 2)

#	define	CFC_READ		CF_READ
#	define	CFC_WRITE		CF_WRITE
#	define	CFC_OVERRIDE	CF_FORCE

#	define	CFO_READ		CF_READ
#	define	CFO_WRITE		CF_WRITE
#	define	CFO_CREATE		CF_FORCE

#	define	CFS_BEGIN		0
#	define	CFS_CURRENT		1
#	define	CFS_END			2
private:
	HANDLE fh;
	unsigned long filesize;
public:
	File(void);
	virtual ~File(void);
	virtual bool Create(const char *filename, int flags);
	virtual bool Open(const char *filename, int flags);
	virtual bool Close(void);
	virtual bool Rewind(void) { return File::Seek(0, CFS_BEGIN); };
	virtual bool Seek(long offset, int mode);
	virtual bool GetPosition(unsigned long &pos);
	virtual bool SetPosition(unsigned long pos) { return File::Seek(pos, CFS_BEGIN); };
	virtual bool GetFileSize(unsigned long &size);
	virtual bool Read(char *buffer, unsigned long &size);
	virtual bool Write(char *buffer, unsigned long &size);
};

#if !defined(__File__)
#	define	__File__
#endif	// !defined(__File__)

#endif	// !defined(__File_h__)
