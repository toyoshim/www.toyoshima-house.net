#if !defined(__InputModuleMDC_h__)
#	define	__InputModuleMDC_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__InputModule_h__)
#		include "InputModule.h"
#	endif	// !defined(__InputMoudle_h__)

#	if !defined(__LocalFile_h__)
#		include "LocalFile.h"
#	endif	// !defined(__Local_File_h__)

#	if !defined(__StreamExternalBuffer__)
class StreamExternalBuffer;
#		define	__StreamExternalBuffer__
#	endif	// !defined(__StreamExternalBuffer__)

#	if !defined(__MCDriver__)
class MCDriver;
#		define	__MCDriver__
#	endif	// !defined(__MCDriver__)

class InputModuleMDC: public InputModule{
private:
	LocalFile lf;
	StreamExternalBuffer *stream;
	MCDriver *mcd;
	char lastFileName[_MAX_PATH];
public:
	InputModuleMDC(void);
	~InputModuleMDC(void);

	const char *GetModuleDescription(void);	// InputModule
	bool GetModuleVersion(int &major, int &minor);	// InputModule
	const char *GetAcceptFileList(void);	// InputModule
	const char *GetTitle(const char *fileName);	// InputModule
	bool CheckFormat(const char *fileName);	// InputModule
	bool PlayMusic(const char *fileName);	// InputModule
	void StopMusic(void);	// InputModule
	bool StreamUpdate(short *buffer, int count);	// InputModule
	bool SetVisualData(unsigned char data[76], int mode);	// InputModule

private:
	void ParseFileName(const char *fileName);
	bool FileLoad(const char *fileName, unsigned char *&data, int &datasize);
};

#endif	// !defined(__InModuleMDC_h__)
