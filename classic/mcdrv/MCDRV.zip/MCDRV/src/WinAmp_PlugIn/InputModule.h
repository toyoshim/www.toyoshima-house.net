#if !defined(__InputModule_h__)
#	define	__InputModule_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__WinAmpInModule_h__)
#		include "WinAmpInModule.h"
#	endif	// !defined(__WinAmpInModule_h__)

class InputModule{
#	define	CIM_BUFFER_SIZE			1024
#	define	CIM_PLAY_BUFFER_SIZE	4096
private:
	static InputModule *instance;
	WINAMP_IN_MODULE im;
	bool im_fixed;
	bool im_init;
	char description[CIM_BUFFER_SIZE];
	bool paused;
	HANDLE thread_handle;
	bool kill_thread;
	unsigned char buffer[CIM_PLAY_BUFFER_SIZE];
public:
	InputModule(void);
	virtual ~InputModule(void);

	LPWINAMP_IN_MODULE GetWinAmpInModule(void);
	virtual void FixWinAmpInModule(void);
	virtual const char *GetModuleDescription(void);
	virtual bool GetModuleVersion(int &major, int &minor);
	virtual const char *GetAcceptFileList(void);
	virtual void ConfigDialog(HWND hParentWnd);
	virtual void AboutDialog(HWND hParentWnd);
	virtual const char *GetTitle(const char *fileName);
	virtual bool InfoDialog(const char *fileName, HWND hParentWnd);
	virtual bool CheckFormat(const char *fileName);
	virtual bool PlayMusic(const char *fileName);
	virtual void StopMusic(void);
	virtual bool StreamUpdate(short *buffer, int count);
	virtual bool SetVisualData(unsigned char data[76], int mode);

	static void Config(HWND hParentWnd);
	static void About(HWND hParentWnd);
	static void Init(void);
	static void Quit(void);
	static void GetFileInfo(char *fileName, char *title, int *lengthInMs);
	static int InfoBox(char *fileName, HWND hParentWnd);
	static int IsOurFile(char *fileName);
	static int Play(char *fileName);
	static void Pause(void);
	static void UnPause(void);
	static int IsPaused(void);
	static void Stop(void);

	static int GetLength(void);
	static int GetOutputTime(void);
	static void SetOutputTime(int timeInMs);
	static void SetVolume(int volume);
	static void SetPan(int pan);
	static void EQSet(int on, char data[10], int preAmp);

	static DWORD WINAPI PlayThread(LPVOID param);
};

#	if !defined(__InputModule__)
#		define	__InputModule__
#	endif	// !defined(__InputModule__)

#endif	// !defined(__InputModule_h__)
