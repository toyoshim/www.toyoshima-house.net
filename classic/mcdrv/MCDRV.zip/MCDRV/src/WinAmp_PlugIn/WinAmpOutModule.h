#if !defined(__WinAmpOutModule_h__)
#	define	__WinAmpOutModule_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	define	WINAMP_OUT_MODULE_VERSION	0x10

typedef struct {
	int version;
	char *description;
	int id;
	HWND hMainWindow;
	HINSTANCE hDllInstance;

	void (*Config)(HWND hParentWnd);
	void (*About)(HWND hParentWnd);
	void (*Init)(void);
	void (*Quit)(void);
	int (*Open)(int sampleRate, int nChannels, int bitsPerSamp, int bufferLenInMs, int preBufferInMs); 
	void (*Close)(void);
	int (*Write)(char *buf, int len);	
	int (*CanWrite)(void);
	int (*IsPlaying)(void);
	int (*Pause)(int pause);
	void (*SetVolume)(int volume);
	void (*SetPan)(int pan);
	void (*Flush)(int t);
	int (*GetOutputTime)();
	int (*GetWrittenTime)();

} WINAMP_OUT_MODULE, *LPWINAMP_OUT_MODULE;

#	if !defined(__WINAMP_OUT_MODULE__)
#		define	__WINAMP_OUT_MODULE__
#	endif	// !defined(__WINAMP_OUT_MODULE__)

#endif	// !defined(__WinAmpOutModule_h__)
