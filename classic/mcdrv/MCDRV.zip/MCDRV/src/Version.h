#if !defined(__Version_h__)
#	define	__Version_h__

#	define	PLAYER_VERSION_MAJOR	0
#	define	PLAYER_VERSION_MINOR	60

#endif	// !defined(__Version_h__)
