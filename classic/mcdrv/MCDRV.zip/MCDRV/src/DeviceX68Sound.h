#if !defined(__DeviceX68Sound_h__)
#	define	__DeviceX68Sound_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__DeviceOPM_h__)
#		include "DeviceOPM.h"
#	endif	// !defined(__SoundDevice_h__)

#	if !defined(__SoundStream_h__)
#		include "SoundStream.h"
#	endif	// !defined(__SoundStream_h__)

#	if !defined(__SoundDriver__)
class SoundDriver;
#		define	__SoundDriver__
#	endif	// !defined(__SoundDriver__)

class DeviceX68Sound: public DeviceOPM, public SoundStream{
public:
	class DevicePCM8: public SoundDevice{
	private:
		unsigned char *voice[2][128];
		int voice_length[2][128];
		int voice_number[8];
		int bank_number[8];
		int pan[8];
		int volume[8];
		int mode[8];
		int active_channel;
	public:
		DevicePCM8(void);
		~DevicePCM8(void);

		bool Initialize(void);	// SoundDevice
		void Update(short *buffer, int count);	// SoundDevice

		void SetPitch(int pitch);	// SoundDevice
		void SetVolume(int volume);	// SoundDevice
		void SetVoice(int voice, int bank = 0);	// SoundDevice
		void SetPan(int pan);	// SoundDevice
		void KeyOn(void);	// SoundDevice
		void KeyOff(void);	// SoundDevice
		void SetActiveChannel(int channel);	// SoundDevice

		bool SetVoiceData(int n, unsigned char *data, int data_length, int bank = 0);
		bool SetPlayMode(int n);
	};

#	define	CDXS_STAND_ALONE	1
#	define	CDXS_CLIENT			2
private:
	static bool has_instance;
	static DeviceX68Sound *instance;
	static HINSTANCE dll_instance;
	bool initialize;
	int mode;
	SoundDriver *callback;
public:
	DeviceX68Sound(int mode = CDXS_STAND_ALONE);
	~DeviceX68Sound(void);

	bool Initialize(void);	// SoundDevice
	void Update(short *buffer, int count);	// SoundDevice

	void SetTimerCallback(SoundDriver *driver);	// SoundStream
	void SetTimerInterval(double msec);	// SoundStream

	void Write(unsigned char reg, unsigned char value);
	unsigned char Read(unsigned char reg);
	DeviceX68Sound::DevicePCM8 *DevicePCM8Create(void);

private:
	static void CALLBACK TimerCallback(void);
	static bool LoadModule(void);
};

#endif	// !defined(__DeviceYM2151_h__)
