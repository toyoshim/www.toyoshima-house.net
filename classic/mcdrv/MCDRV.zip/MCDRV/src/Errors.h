#if !defined(__Errors_h__)
#define	__Errors_h__

#define	ERROR_OK			0
#define	ERROR_UNKNOWN		1
#define	ERROR_MEMORY		2
#define	ERROR_UNSUPPORTED	3
#define	ERROR_MEDIACHECK	4
#define	ERROR_FILE_OPEN		5
#define	ERROR_FILE_READ		6
#define	ERROR_FILE_WRITE	7
#define	ERROR_FILE_SEEK		8
#define	ERROR_FILE_CLOSE	9
#define	ERROR_INVAL_DATA	10

#endif	// !defined(__Errors_h__)
