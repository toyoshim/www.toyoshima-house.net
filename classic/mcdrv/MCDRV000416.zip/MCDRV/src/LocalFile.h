/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [LocalFile.h]
 *   ����̃p�X����t�����ăt�@�C��������s���N���X�B
 * -------------------------------------------------------------------------------------------- */
#if !defined(__LocalFile_h__)
#	define	__LocalFile_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__File_h__)
#		include "File.h"
#	endif	// !defined(__File_h__)

class LocalFile: public File{
private:
	char path[_MAX_PATH];
	char tmp_file[_MAX_PATH];
public:
	LocalFile(const char *path = NULL);
	~LocalFile(void) {};

	bool Create(const char *filename, int flags);	// File
	bool Open(const char *filename, int flags);	// File
	bool Close();	// File

	bool SetLocalPath(const char *path);
	void FixFileName(char *dst, int dst_size, const char *src);
};

#endif	// !defined(__LocalFile_h__)
