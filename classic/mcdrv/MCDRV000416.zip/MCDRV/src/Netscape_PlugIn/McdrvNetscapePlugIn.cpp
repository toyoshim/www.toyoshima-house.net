/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [McdrvNetscapePlugIn.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "McdrvNetscapePlugIn.h"
#include "MCDriver.h"
#include "GraphicBuffer.h"
#include "Errors.h"
#include "Version.h"
#include "resource.h"

#define	PLUGIN_NAME		"npmdc.dll"
#define	UPDATE_URL		"http://www.tk.xaxon.ne.jp/~toyoshim/mcdrv/update.html"

unsigned long
McdrvNetscapePlugIn::HighColor[16] = {
	0x0000ff00, 0x0000ff00, 0x0000ff00, 0x0000ff00,	0x0000ff00, 0x0000ff00, 0x0000ff00, 0x0000ff00,
	0x0000ff00, 0x0000ff00, 0x00ff0000, 0x00ff0000,	0x00ff0000, 0x00ff0000, 0x00ff0000, 0x00ff0000,
};

unsigned long
McdrvNetscapePlugIn::LowColor[16] = {
	0x00003300, 0x00003300, 0x00003300, 0x00003300, 0x00003300, 0x00003300, 0x00003300, 0x00003300,
	0x00003300, 0x00003300, 0x00330000, 0x00330000, 0x00330000, 0x00330000, 0x00330000, 0x00330000,
};

RECT
McdrvNetscapePlugIn::areas[4] = {
	{  4, 48, 14, 57 },
	{ 20, 48, 29, 57 },
	{ 35, 48, 43, 57 },
	{ 50, 48, 59, 57 },
};

McdrvNetscapePlugIn::McdrvNetscapePlugIn
(NPNetscapeFuncs *funcs, NPP instance):
NetscapePlugIn(funcs, instance),
mime(NULL),
buffer(NULL),
bufferSize(0),
mcd(NULL),
hWnd(NULL),
oldProc(NULL),
image(NULL),
offscreen(NULL),
bgcolor(RGB(0, 0, 0)),
vols(NULL),
highVols(NULL),
highCnts(NULL),
channels(0),
mouseArea(CMNPI_MOUSEAREA_INVALID),
mousePushed(false),
playing(false),
pausing(false)
{
}

McdrvNetscapePlugIn::~McdrvNetscapePlugIn
(void)
{
	NPP_Destroy(NULL);
}

NPError
McdrvNetscapePlugIn::NPP_New
(NPMIMEType pluginType, uint16 mode, int16 argc, char **argn, char **argv, NPSavedData *saved)
{
	DOUT("type: %s\n", pluginType);
	DOUT("mode: %s\n", (mode == NP_EMBED)? "embed": "full");
	for (int i = 0; i < argc; i++) {
		DOUT("%s = %s\n", argn[i], argv[i]);
		if (0 == stricmp("BGCOLOR", argn[i])) {
			bgcolor = HtmlColor(argv[i]);
		} else if (0 == stricmp("DRIVER", argn[i])) {
			double v = ParseVersion(argv[i]);
			double cv = MAKE_FULL_VERSION(DRIVER_VERSION_MAJOR, DRIVER_VERSION_MINOR);
			DOUT("CheckDriverVersion: %2.02f / %2.02f\n", v, cv);
			if (v > cv) {
				NPN_GetURL(UPDATE_URL, "mcdrv_update_page");
				return NPERR_MODULE_LOAD_FAILED_ERROR;
			}
		} else if (0 == stricmp("VERSION", argn[i])) {
			double v = ParseVersion(argv[i]);
			double cv = MAKE_FULL_VERSION(PLUGIN_VERSION_MAJOR, PLUGIN_VERSION_MINOR);
			DOUT("CheckPlugInVersion: %2.02f / %2.02f\n", v, cv);
			if (v > cv) {
				NPN_GetURL(UPDATE_URL, "mcdrv_update_page");
				return NPERR_MODULE_LOAD_FAILED_ERROR;
			}
		}
	}
	DOUT("data: $%08X\n", saved);
	offscreen = new GraphicBuffer();
	if (NULL == offscreen) NPERR_OUT_OF_MEMORY_ERROR;
	if (ERROR_OK != offscreen->MakeImage(122, 61)) {
		delete offscreen;
		offscreen = NULL;
		return NPERR_OUT_OF_MEMORY_ERROR;
	}
	image = new GraphicBuffer();
	HINSTANCE hInstance = GetModuleHandle(PLUGIN_NAME);
	DOUT("hInstance: $%08X\n", hInstance);
	if (NULL == image) return NPERR_OUT_OF_MEMORY_ERROR;
	image->ResourceImage(MAKEINTRESOURCE(IDB_BITMAP1), 122, 77, hInstance);
	image->BltToBuffer(offscreen);
	unsigned long width;
	unsigned long height;
	char *bits;
	offscreen->GetData(width, height, bits);
	unsigned long *p = (unsigned long *)bits;
	for (unsigned int y = 0; y < height; y++) {
		for (unsigned int x = 0; x < width; x++) {
			if (*p == 0x00ff00ff) {
				*p = bgcolor;
			}
			p++;
		}
	}
	return NPERR_NO_ERROR;
}

NPError
McdrvNetscapePlugIn::NPP_Destroy
(NPSavedData **save)
{
	if (NULL != mime) {
		free(mime);
		mime = NULL;
	}
	if (NULL != mcd) {
		delete mcd;
		mcd = NULL;
	}
	if (NULL != hWnd) {
		SetWindowLong(hWnd, GWL_WNDPROC, (LONG)oldProc);
		WndEntryDel(hWnd);
		hWnd = NULL;
	}
	if (NULL != image) {
		delete image;
		image = NULL;
	}
	if (NULL != offscreen) {
		delete offscreen;
		offscreen = NULL;
	}
	if (NULL != vols) {
		free(vols);
		vols = NULL;
	}
	if (NULL != highVols) {
		free(highVols);
		highVols = NULL;
	}
	if (NULL != highCnts) {
		free(highCnts);
		highCnts = NULL;
	}
	if (NULL != buffer) {
		free(buffer);
		buffer = NULL;
		bufferSize = 0;
	}
	return NPERR_NO_ERROR;
}

NPError
McdrvNetscapePlugIn::NPP_NewStream
(NPMIMEType type, NPStream *stream, NPBool seekable, uint16 *stype)
{
	// for easy implement, we can use as-file mode stream.
	// but, IE not support this mode (force to use normal mode stream).
	// and receiving stream from JavaScript, we get null-pointer as filename.
	// it seem to be a bug of netscape.
	*stype = NP_NORMAL;
	if (NULL != mime) free(mime);
	mime = strdup(type);
	if (NULL == mime) NPERR_OUT_OF_MEMORY_ERROR;
	return NPERR_NO_ERROR;
}

NPError
McdrvNetscapePlugIn::NPP_DestroyStream
(NPStream *stream, NPReason reason)
{
	if (NPRES_DONE != reason) {
		free(buffer);
		buffer = NULL;
		bufferSize = 0;
		NPN_Status("mcdrv: �f�[�^�̓ǂݍ��݂Ɏ��s���܂���");
	}
	if (NULL != mcd) delete mcd;
	mcd = new MCDriver(NULL, &lf);
	if (NULL != mcd) if (mcd->SetData((unsigned char *)buffer, bufferSize)) playing = mcd->Play();
	free(buffer);
	buffer = NULL;
	bufferSize = 0;
	return NPERR_NO_ERROR;
}

void
McdrvNetscapePlugIn::NPP_StreamAsFile
(NPStream *stream, const char *fname)
{
	DOUT("StreamAsFile: $%08x(%02x %02x %02x %02x ...) , %s\n", stream, ((char *)stream)[0], ((char *)stream)[1], ((char *)stream)[2], ((char *)stream)[3], fname);
	if (!lf.Open(fname, CFO_READ)) return;
	unsigned long filesize;
	if (!lf.GetFileSize(filesize)) return;
	unsigned char *data = new unsigned char[filesize];
	if (NULL == data) return;
	if (!lf.Read((char *)data, filesize) || !lf.Close()) {
		delete data;
		return;
	}
	mcd = new MCDriver(NULL, &lf);
	if (NULL == mcd) {
		delete data;
		return;
	}
	if (!mcd->SetData(data, filesize)) {
		delete data;
		return;
	}
	delete data;
	char message[1024];
	_snprintf(message, 1024, "mcdrv: [%s] %s", "�Đ����܂�", mcd->GetTitle());
	NPN_Status(message);
	playing = mcd->Play();
}

int32
McdrvNetscapePlugIn::NPP_WriteReady
(NPStream *stream)
{
	return 0x7fffffff;
}

int32
McdrvNetscapePlugIn::NPP_Write
(NPStream *stream, int32 offset, int32 len, void *data)
{
	int32 size = offset + len;
	if (NULL == buffer) buffer = (char *)malloc(size);
	else buffer = (char *)realloc(buffer, size);
	if (NULL == buffer) return 0;
	bufferSize = size;
	memcpy(&buffer[offset], data, len);
	return len;
}

NPError
McdrvNetscapePlugIn::NPP_SetWindow
(NPWindow *window)
{
	DOUT("HWND: $%08X\n", window->window);
	DOUT("POS: (%d, %d)\n", window->x, window->y);
	DOUT("SIZE: (%d, %d)\n", window->width, window->height);
	HWND newWnd = (HWND)window->window;
	point.x = window->x;
	point.y = window->y;
	size.cx = window->width;
	size.cy = window->height;
	if (newWnd == hWnd) return NPERR_NO_ERROR;
	if (NULL != hWnd) {
		KillTimer(hWnd, 1);
		SetWindowLong(hWnd, GWL_WNDPROC, (LONG)oldProc);
		WndEntryDel(hWnd);
	}
	hWnd = newWnd;
	WndEntryAdd(hWnd, this);
	oldProc = NULL;
	oldProc = (WNDPROC)SetWindowLong(hWnd, GWL_WNDPROC, (LONG)WindowProcWrap);
	SetTimer(hWnd, 1, 50, NULL);
	return NPERR_NO_ERROR;
}

LRESULT
McdrvNetscapePlugIn::WindowProc
(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
//	DOUT("$%08X $%08X $%08X $%08X\n", hWnd, nMsg, wParam, lParam);
	switch (nMsg) {
	case WM_PAINT:{
		PAINTSTRUCT ps;
		HDC hDc = BeginPaint(hWnd, &ps);
		if ((NULL != hDc) && (NULL != offscreen)) {
			unsigned long width;
			unsigned long height;
			char *bits;
			offscreen->GetData(width, height, bits);
			if (size.cx < (int)width) width = size.cx;
			if (size.cy < (int)height) height = size.cy;
			StretchDIBits(hDc, 0, 0, width, height, 0, 0, width, height, bits, offscreen->GetLpBitsInfo(), DIB_RGB_COLORS, SRCCOPY);
		}
		EndPaint(hWnd, &ps);
		return 0;}
	case WM_LBUTTONDOWN:{
		mousePushed = true;
		POINT pt;
		pt.x = GET_X_LPARAM(lParam);
		pt.y = GET_Y_LPARAM(lParam);
		mousePushedArea = CheckArea(pt);
		ButtonOn(mousePushedArea);
		break;}
	case WM_LBUTTONUP:{
		mousePushed = false;
		POINT pt;
		pt.x = GET_X_LPARAM(lParam);
		pt.y = GET_Y_LPARAM(lParam);
		int area = CheckArea(pt);
		ButtonOff(area);
		if (area != mousePushedArea) break;
		ButtonPushed(area);
		break;}
	case WM_TIMER:
		MouseCheck();
		DrawEqualizer();
		InvalidateRect(hWnd, NULL, false);
		break;
	}
	if (NULL != oldProc) return oldProc(hWnd, nMsg, wParam, lParam);
	return DefWindowProc(hWnd, nMsg, wParam, lParam);
}

unsigned long
McdrvNetscapePlugIn::HtmlColor
(const char *str)
{
	if (NULL == str) return 0;
	if (*str == '#') str++;
	char rgbstr[6];
	int len = strlen(str);
	if (len > 6) return 0;
	for (int i = 0; i < 6 - len; i++) rgbstr[i] = '0';
	memcpy(&rgbstr[6 - len], str, len);
	for (i = 0; i < 6; i++) {
		if (('0' <= rgbstr[i]) && (rgbstr[i] <= '9')) {
			rgbstr[i] -= '0';
			continue;
		}
		rgbstr[i] |= 0x20;
		if ((rgbstr[i] < 'a') || ('f' < rgbstr[i])) return 0;
		rgbstr[i] += 10 - 'a';
	}
	int r = (rgbstr[0] << 4) | rgbstr[1];
	int g = (rgbstr[2] << 4) | rgbstr[3];
	int b = (rgbstr[4] << 4) | rgbstr[5];
	return (r << 16) | (g << 8) | b;
}

double
McdrvNetscapePlugIn::ParseVersion
(const char *str)
{
	int v = 0;
	int major = 0;
	bool dot = false;
	for (; 0 != *str; str++) {
		if ('.' == *str) {
			if (dot) return 0.0;
			dot = true;
			major = v;
			v = 0;
			continue;
		}
		if (0 == isdigit(*str)) return 0.0;
		v *= 10;
		v += *str - '0';
	}
	if (!dot) return (double)v;
	double full = (double)major + (double)v / 100.0;
	return full;
}

void
McdrvNetscapePlugIn::DrawEqualizer
(void)
{
	if (NULL == mcd) return;
	LPSYSTEM_WORK system = mcd->GetSystemWork();
	LPEXT_TRACK_WORK ext = mcd->GetExtTrackWork();
	int n = system->inf_trnum;
	if (n > 9) n = 9;

	if (0 == channels) {
		vols = (int *)malloc(sizeof(int) * n);
		highVols = (int *)malloc(sizeof(int) * n);
		highCnts = (int *)malloc(sizeof(int) * n);
	} else {
		vols = (int *)realloc(vols, sizeof(int) * n);
		highVols = (int *)realloc(highVols, sizeof(int) * n);
		highCnts = (int *)realloc(highCnts, sizeof(int) * n);
	}
	if ((NULL == vols) || (NULL == highVols) || (NULL == highCnts)) {
		if (NULL != vols) {
			free(vols);
			vols = NULL;
		}
		if (NULL != highVols) {
			free(highVols);
			highVols = NULL;
		}
		if (NULL != highCnts) {
			free(highCnts);
			highCnts = NULL;
		}
		channels = 0;
		return;
	}
	for (int i = channels; i < n; i++) vols[i] = highVols[i] = highCnts[i] = 0;
	channels = n;

	int ch;
	for (ch = 0; ch < n; ch++) {
		if (vols[ch] > 0) vols[ch] -= 16;
		if (vols[ch] < ext[ch].key_on) vols[ch] = ext[ch].key_on;
		ext[ch].key_on = 0;
		int max = highVols[ch] - highCnts[ch] * highCnts[ch];	// x - at^2
		if (max < 0) max = 0;
		if (max < vols[ch]) {
			highVols[ch] = vols[ch];
			highCnts[ch] = 0;
			max = highVols[ch] - 0 * 0;
		} else {
			highCnts[ch]++;
		}
	}

	unsigned long width;
	unsigned long height;
	char *bits;
	offscreen->GetData(width, height, bits);
	for (i = 0; i < n; i++) {
		unsigned long *p = (unsigned long *)&bits[(12 + (i * 11) + 38 * width) * 4];
		for (int v = 0; v < vols[i] >> 3; v++) {
			for (int lp = 0; lp < 10; lp++) *p++ = HighColor[v];
			p -= width + width + 10;
		}
		for (; v < 16; v++) {
			for (int lp = 0; lp < 10; lp++) *p++ = LowColor[v];
			p -= width + width + 10;
		}
		int max = highVols[i] - highCnts[i] * highCnts[i];	// x - at^2
		if (max < 0) max = 0;
		p = (unsigned long *)&bits[(12 + (i * 11) + (38 - (max >> 3) * 2) * width) * 4];
		for (int lp = 0; lp < 10; lp++) *p++ = 0xeeeeee;
	}
	InvalidateRect(hWnd, NULL, false);
}

void
McdrvNetscapePlugIn::MouseCheck
(void)
{
	POINT pt;
	GetCursorPos(&pt);
	ScreenToClient(hWnd, &pt);
	int area = CheckArea(pt);
	if (mouseArea == area) return;

	switch (area) {
	case CMNPI_MOUSEAREA_INVALID:
		NPN_Status("");
		break;
	case CMNPI_MOUSEAREA_ON_APP:
		if (NULL == mcd) {
			NPN_Status("");
		} else {
			char message[1024];
			_snprintf(message, 1024, "mcdrv: [%s] %s", "�Đ���", mcd->GetTitle());
			NPN_Status(message);
		}
		break;
	case CMNPI_MOUSEAREA_ON_PREV:
	case CMNPI_MOUSEAREA_ON_PLAY:
	case CMNPI_MOUSEAREA_ON_PAUSE:
	case CMNPI_MOUSEAREA_ON_STOP:
		if (mousePushed) ButtonOn(area);
		break;
	}
	if (mouseArea >= CMNPI_MOUSEAREA_ON_PREV) ButtonOff(mouseArea);
	mouseArea = area;
}

int
McdrvNetscapePlugIn::CheckArea
(POINT pt)
{
	int area = CMNPI_MOUSEAREA_INVALID;
	if ((0 < pt.x) && (pt.x < size.cx) && (0 < pt.y) && (pt.y < size.cy)) {
		area = CMNPI_MOUSEAREA_ON_APP;
		for (int i = 0; i < 4; i++) {
			if ((areas[i].left <= pt.x) && (pt.x <= areas[i].right) && (areas[i].top <= pt.y) && (pt.y <= areas[i].bottom)) {
				area = CMNPI_MOUSEAREA_ON_PREV + i;
				break;
			}
		}
	}
	return area;
}

void
McdrvNetscapePlugIn::ButtonOn
(int area)
{
	area -= CMNPI_MOUSEAREA_ON_PREV;
	if (area < 0) return;
	LPRECT rect = &areas[area];
	image->BltToBuffer(offscreen, rect->left, rect->top, rect->left, rect->top + 16, rect->right - rect->left, rect->bottom - rect->top);
}

void
McdrvNetscapePlugIn::ButtonOff
(int area)
{
	area -= CMNPI_MOUSEAREA_ON_PREV;
	if (area < 0) return;
	LPRECT rect = &areas[area];
	image->BltToBuffer(offscreen, rect->left, rect->top, rect->left, rect->top, rect->right - rect->left, rect->bottom - rect->top);
}

void
McdrvNetscapePlugIn::ButtonPushed
(int area)
{
	if (NULL == mcd) return;
	switch (area) {
	case CMNPI_MOUSEAREA_ON_PREV:
		playing = mcd->Play();
		break;
	case CMNPI_MOUSEAREA_ON_PLAY:
		if (pausing) {
			pausing = false;
			mcd->Pause(false);
		} else {
			if (!playing) playing = mcd->Play();
		}
		break;
	case CMNPI_MOUSEAREA_ON_PAUSE:
		pausing = !pausing;
		playing = mcd->Pause(pausing);
		break;
	case CMNPI_MOUSEAREA_ON_STOP:
		playing = false;
		mcd->Stop();
		break;
	}
}
