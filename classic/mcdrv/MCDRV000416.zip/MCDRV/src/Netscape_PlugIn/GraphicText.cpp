/* --------------------------------------------------------------------------------------------
 *  EL-POINT subset version for KARIHITO
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [GraphicText.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "GraphicText.h"

bool
GraphicText::IsMBFirst
(unsigned char code)
{
	if (((0x81 <= code) && (code <= 0x9f)) || ((0xe0 <= code) && (code <= 0xef))) return true;
	return false;
}
