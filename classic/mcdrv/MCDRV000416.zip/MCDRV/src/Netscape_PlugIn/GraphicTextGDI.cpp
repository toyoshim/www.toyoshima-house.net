/* --------------------------------------------------------------------------------------------
 *  EL-POINT subset version for KARIHITO
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [GraphicTextGDI.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "GraphicTextGDI.h"
#include "GraphicText.h"

GraphicTextGDI::GraphicTextGDI
(void):
hFont(NULL),
hDc(NULL),
align_width(8),
align_height(16),
color(RGB(0xff, 0xff, 0xff)),
back_color(RGB(0x00, 0x00, 0x00)),
transparent(true)
{
}

GraphicTextGDI::~GraphicTextGDI
(void)
{
	if (NULL != hFont) DeleteObject(hFont);
}

bool
GraphicTextGDI::SetFont
(int size)
{
	if (NULL != hFont) DeleteObject(hFont);
	LOGFONT lf;
	ZeroMemory(&lf, sizeof(LOGFONT));
	lf.lfHeight = size;
	lf.lfCharSet = DEFAULT_CHARSET;
	hFont = CreateFontIndirect(&lf);
	return (NULL != hFont);
}

void
GraphicTextGDI::SetAlign
(int width, int height)
{
	align_width = width;
	align_height = height;
}

void
GraphicTextGDI::SetColor
(int r, int g, int b)
{
	color = RGB(r, g, b);
}

void
GraphicTextGDI::SetBackColor
(int r, int g, int b)
{
	back_color = RGB(r, g, b);
	transparent = false;
}

void
GraphicTextGDI::Transparent
(bool on)
{
	transparent = on;
}

bool
GraphicTextGDI::DrawText
(int x, int y, int code)
{
	if (NULL == hDc) return false;
	if (transparent) SetBkMode(hDc, TRANSPARENT);
	else SetBkColor(hDc, back_color);
	SetTextColor(hDc, color);
	char buffer[2];
	if (code < 0x100) {
		buffer[0] = code;
		TextOut(hDc, x, y, buffer, 1);
	} else {
		buffer[0] = code >> 8;
		buffer[1] = code & 0xff;
		TextOut(hDc, x, y, buffer, 2);
	}
	return true;
}

bool
GraphicTextGDI::DrawString
(int x, int y, char *string)
{
	if (NULL == hDc) return false;
	if (transparent) SetBkMode(hDc, TRANSPARENT);
	else SetBkColor(hDc, back_color);
	SetTextColor(hDc, color);
	for (; 0 != *string; ) {
		if (GraphicText::IsMBFirst(*string)) {
			TextOut(hDc, x, y, string, 2);
			string += 2;
			x += align_width << 1;
		} else {
			TextOut(hDc, x, y, string, 1);
			string++;
			x += align_width;
		}
	}
	return true;
}

void
GraphicTextGDI::SetDC
(HDC hDc)
{
	this->hDc = hDc;
}

void
GraphicTextGDI::ResetDC
(void)
{
	hDc = NULL;
}
