/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [NetscapePlugIn.h]
 *   �l�b�g�X�P�[�v��Plug-in �̎�����C++�Ŏ��R�ɍs����悤�Ƀe���v���[�g�������N���X�B
 * -------------------------------------------------------------------------------------------- */
#if	!defined(__NetscapePlugIn_h__)
#	define	__NetscapePlugIn_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	include <npapi.h>
#	include <npupp.h>

abstract class NetscapePlugIn{
public:
	NPNetscapeFuncs *netscapeFuncs;
	NPP instance;
public:
	NetscapePlugIn(NPNetscapeFuncs *funcs, NPP instance);
	virtual ~NetscapePlugIn(void) {};

	// Plug-in Functions
	virtual NPError NPP_New(NPMIMEType pluginType, uint16 mode, int16 argc, char **argn, char **argv, NPSavedData *saved) = 0;
	virtual NPError NPP_Destroy(NPSavedData **save);
	virtual NPError NPP_SetWindow(NPWindow *window);
	virtual NPError NPP_NewStream(NPMIMEType type, NPStream *stream, NPBool seekable, uint16 *stype) = 0;
	virtual NPError NPP_DestroyStream(NPStream *stream, NPReason reason);
	virtual int32 NPP_WriteReady(NPStream *stream);
	virtual int32 NPP_Write(NPStream *stream, int32 offset, int32 len, void *buffer);
	virtual void NPP_StreamAsFile(NPStream *stream, const char *fname);
	virtual void NPP_Print(NPPrint *platformPrint);
	virtual int16 NPP_HandleEvent(NPEvent event);
	virtual void NPP_URLNotify(const char *url, NPReason reason, void *notifyData);
	static jref NPP_GetJavaClass(void);

	// Netscape Functions
	void NPN_Version(int &plugin_major, int &plugin_minor, int &netscape_major, int &netscape_minor);
	NPError NPN_GetURLNotify(const char *url, const char *target, void *notifyData);
	NPError NPN_GetURL(const char *url, const char *target);
	NPError NPN_PostURLNotify(const char *url, const char *window, uint32 len, const char *buf, NPBool file, void *notifyData);
	NPError NPN_PostURL(const char *url, const char *window, uint32 len, const char *buf, NPBool file);
	NPError NPN_RequestRead(NPStream *stream, NPByteRange *rangeList);
	NPError NPN_NewStream(NPMIMEType type, const char *target, NPStream **stream);
	int32 NPN_Write(NPStream *stream, int32 len, void *buffer);
	NPError NPN_DestroyStream(NPStream *stream, NPError reason);
	void NPN_Status(const char *message);
	const char *NPN_UserAgent(void);
	void *NPN_MemAlloc(uint32 size);
	void NPN_MemFree(void *ptr);
	void NPN_ReloadPlugins(NPBool reloadPages);
	JRIEnv *NPN_GetJavaEnv(void);
	jref NPN_GetJavaPeer(void);
};

#	if !defined(__NetscapePlugIn__)
#		define	__NetscapePlugIn__
#	endif	// !defined(__NetscapePlugIn__)

#endif	// !defined(__NetscapePlugIn_h__)
