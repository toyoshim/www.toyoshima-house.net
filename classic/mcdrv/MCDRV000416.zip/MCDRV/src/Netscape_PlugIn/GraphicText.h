/* --------------------------------------------------------------------------------------------
 *  EL-POINT subset version for KARIHITO
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [GraphicText.h]
 *   �e�L�X�g�����ɕK�v�ȃC���^�[�t�F�[�X���W�߂����ۃN���X�B
 * -------------------------------------------------------------------------------------------- */

#if !defined(__GraphicText_h__)
#define	__GraphicText_h__

#if !defined(__Common_h__)
#	include "Common.h"
#endif	// !defined(__Common_h__)

class GraphicText{
public:
	virtual bool SetTextFont(int size, int width, int height, int r, int g, int b) = 0;
	virtual bool SetTextBkColor(int r, int g, int b) = 0;
	virtual bool DrawText(int x, int y, int code) = 0;
	virtual bool DrawString(int x, int y, char *string) = 0;

	static bool IsMBFirst(unsigned char code);
};

#if !defined(__GraphicText__)
#	define	__GraphicText__
#endif	// !defined(__GraphicText__)

#endif	// !defined(__GraphicText_h__)
