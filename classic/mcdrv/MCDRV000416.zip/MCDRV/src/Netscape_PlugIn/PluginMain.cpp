/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [PlugInMain.cpp]
 *   NetscapePlugIn�N���X��Netscape Plug-ins�d�l�ɍ��v�����`��DLL�Ƃ��Ďd���Ă�B
 *  �K�v�ȃw�b�_�t�@�C�����C���N���[�h���APLUGIN_CLASS�Ƃ���NetscapePlugIn�N���X��
 *  �p�������N���X���`����΁A���̃N���X��Netscape Plug-ins�Ƃ��Ďd���Ă�B
 * -------------------------------------------------------------------------------------------- */
#define	__Main__
#include "Common.h"
#undef	__Main__
#include <npapi.h>
#include <npupp.h>

#include "McdrvNetscapePlugIn.h"

#define	PLUGIN_CLASS	McdrvNetscapePlugIn

#define	NP_EXPORT		extern "C"
#define	PLUGIN			((NetscapePlugIn *)instance->pdata)
#define	NETSCAPE		((NetscapePlugIn *)instance->pdata)

static NPPluginFuncs *pluginFuncs = NULL;
static NPNetscapeFuncs *netscapeFuncs = NULL;

NPError
NPP_New
(NPMIMEType pluginType, NPP instance, uint16 mode, int16 argc, char **argn, char **argv, NPSavedData *saved)
{
	DOUT("NPP_New\n");
	if (NULL == instance) NPERR_INVALID_INSTANCE_ERROR;
	if (NULL == netscapeFuncs) NPERR_INVALID_FUNCTABLE_ERROR;
	instance->pdata = new PLUGIN_CLASS(netscapeFuncs, instance);
	if (NULL == instance->pdata) return NPERR_OUT_OF_MEMORY_ERROR;
	NPError err = PLUGIN->NPP_New(pluginType, mode, argc, argn, argv, saved);
	if (err != NPERR_NO_ERROR) NPP_Destroy(instance, NULL);
	return err;
}

NPError
NPP_Destroy
(NPP instance, NPSavedData **save)
{
	DOUT("NPP_Destroy\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return NPERR_INVALID_INSTANCE_ERROR;
	NPError err = PLUGIN->NPP_Destroy(save);
	delete (NetscapePlugIn *)instance->pdata;
	instance->pdata = NULL;
	return err;
}

NPError
NPP_SetWindow
(NPP instance, NPWindow *window)
{
	DOUT("NPP_SetWindow\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return NPERR_INVALID_INSTANCE_ERROR;
	return PLUGIN->NPP_SetWindow(window);
}

NPError
NPP_NewStream
(NPP instance, NPMIMEType type, NPStream *stream, NPBool seekable, uint16 *stype)
{
	DOUT("NPP_NewStream\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return NPERR_INVALID_INSTANCE_ERROR;
	return PLUGIN->NPP_NewStream(type, stream, seekable, stype);
}

NPError
NPP_DestroyStream
(NPP instance, NPStream *stream, NPReason reason)
{
	DOUT("NPP_DestroyStream\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return NPERR_INVALID_INSTANCE_ERROR;
	return PLUGIN->NPP_DestroyStream(stream, reason);
}

int32
NPP_WriteReady
(NPP instance, NPStream *stream)
{
	DOUT("NPP_WriteReady\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return 0;
	return PLUGIN->NPP_WriteReady(stream);
}

int32
NPP_Write
(NPP instance, NPStream *stream, int32 offset, int32 len, void *buffer)
{
	DOUT("NPP_Write\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return 0;
	return PLUGIN->NPP_Write(stream, offset, len, buffer);
}

void
NPP_StreamAsFile
(NPP instance, NPStream *stream, const char *fname)
{
	DOUT("NPP_StreamAsFile\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return;
	PLUGIN->NPP_StreamAsFile(stream, fname);
}

void
NPP_Print
(NPP instance, NPPrint *platformPrint)
{
	DOUT("NPP_Print\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return;
	PLUGIN->NPP_Print(platformPrint);
}

/*
int16
NPP_HandleEvent
(NPP instance, NPEvent event)
{
	DOUT("NPP_HandleEvent\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return 0;
	return PLUGIN->NPP_HandleEvent(event);
}
*/

void
NPP_URLNotify
(NPP instance, const char *url, NPReason reason, void *notifyData)
{
	DOUT("NPP_URLNotify\n");
	if ((NULL == instance) || (NULL == instance->pdata)) return;
	PLUGIN->NPP_URLNotify(url, reason, notifyData);
}

jref
Private_GetJavaClass
(void)
{
	DOUT("NPP_GetJavaClass\n");
	jref clazz = PLUGIN_CLASS::NPP_GetJavaClass();
	if (NULL != clazz) {
		JRIEnv *env = netscapeFuncs->getJavaEnv();
		return (jref)JRI_NewGlobalRef(env, clazz);
	}
	return NULL;
}


NP_EXPORT NPError WINAPI
NP_GetEntryPoints(NPPluginFuncs *pFuncs)
{
	DOUT("NP_GetEntryPoints\n");
	if (NULL == pFuncs) return NPERR_INVALID_FUNCTABLE_ERROR;

	pFuncs->version			= (NP_VERSION_MAJOR << 8) | NP_VERSION_MINOR;
	pFuncs->newp			= NPP_New;
    pFuncs->destroy			= NPP_Destroy;
    pFuncs->setwindow		= NPP_SetWindow;
    pFuncs->newstream		= NPP_NewStream;
    pFuncs->destroystream	= NPP_DestroyStream;
    pFuncs->asfile			= NPP_StreamAsFile;
    pFuncs->writeready		= NPP_WriteReady;
    pFuncs->write			= NPP_Write;
    pFuncs->print			= NPP_Print;
    pFuncs->event			= NULL;	//NPP_HandleEvent;

	pluginFuncs				= pFuncs;

	return NPERR_NO_ERROR;
}

NP_EXPORT NPError WINAPI
NP_Initialize(NPNetscapeFuncs *pFuncs)
{
	DOUT("NP_Initialize\n");
	if (NULL == pFuncs) return NPERR_INVALID_FUNCTABLE_ERROR;

	netscapeFuncs = pFuncs;
	if (HIBYTE(pFuncs->version) > NP_VERSION_MAJOR) return NPERR_INCOMPATIBLE_VERSION_ERROR;
	int minor = pFuncs->version & 0xff;
	if (minor >= NPVERS_HAS_NOTIFICATION) pluginFuncs->urlnotify = NPP_URLNotify;
	if (minor >= NPVERS_HAS_LIVECONNECT) pluginFuncs->javaClass = Private_GetJavaClass();
	return NPERR_NO_ERROR;
}

NP_EXPORT NPError WINAPI
NP_Shutdown(void)
{
	DOUT("NP_Shutdown\n");
	netscapeFuncs = NULL;
#if defined(_DEBUG)
	_CrtDumpMemoryLeaks();
#endif	// defined(_DEBUG)
	return NPERR_NO_ERROR;
}
