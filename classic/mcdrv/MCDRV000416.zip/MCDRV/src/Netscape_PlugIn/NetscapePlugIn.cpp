/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [NetscapePlugIn.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "NetscapePlugIn.h"

#define	VERSION_CHECK(f)	{ if ((netscapeFuncs->version & 0xff) < f) return NPERR_INCOMPATIBLE_VERSION_ERROR; }

NetscapePlugIn::NetscapePlugIn
(NPNetscapeFuncs *funcs, NPP instance):
netscapeFuncs(funcs),
instance(instance)
{
}

NPError
NetscapePlugIn::NPP_Destroy
(NPSavedData **save)
{
	return NPERR_NO_ERROR;
}

NPError
NetscapePlugIn::NPP_SetWindow
(NPWindow *window)
{
	return NPERR_NO_ERROR;
}

NPError
NetscapePlugIn::NPP_DestroyStream
(NPStream *stream, NPReason reason)
{
	return NPERR_NO_ERROR;
}

int32
NetscapePlugIn::NPP_WriteReady
(NPStream *stream)
{
	return 0;
}

int32
NetscapePlugIn::NPP_Write
(NPStream *stream, int32 offset, int32 len, void *buffer)
{
	return 0;
}

void
NetscapePlugIn::NPP_StreamAsFile(NPStream *stream, const char *fname)
{
}

void
NetscapePlugIn::NPP_Print
(NPPrint *platformPrint)
{
}

int16
NetscapePlugIn::NPP_HandleEvent(NPEvent event)
{
	return 0;
}

void
NetscapePlugIn::NPP_URLNotify
(const char *url, NPReason reason, void *notifyData)
{
}

jref
NetscapePlugIn::NPP_GetJavaClass
(void)
{
	return NULL;
}

void
NetscapePlugIn::NPN_Version
(int &plugin_major, int &plugin_minor, int &netscape_major, int &netscape_minor)
{
	plugin_major	= NP_VERSION_MAJOR;
	plugin_minor	= NP_VERSION_MINOR;
	netscape_major	= HIBYTE(netscapeFuncs->version);
	netscape_minor	= LOBYTE(netscapeFuncs->version);
}

NPError
NetscapePlugIn::NPN_GetURLNotify
(const char *url, const char *target, void *notifyData)
{
	VERSION_CHECK(NPVERS_HAS_NOTIFICATION);
	return netscapeFuncs->geturlnotify(instance, url, target, notifyData);
}

NPError
NetscapePlugIn::NPN_GetURL(const char *url, const char *target)
{
	return netscapeFuncs->geturl(instance, url, target);
}

NPError
NetscapePlugIn::NPN_PostURLNotify
(const char *url, const char *window, uint32 len, const char *buf, NPBool file, void *notifyData)
{
	VERSION_CHECK(NPVERS_HAS_NOTIFICATION);
	return netscapeFuncs->posturlnotify(instance, url, window, len, buf, file, notifyData);
}


NPError
NetscapePlugIn::NPN_PostURL
(const char *url, const char *window, uint32 len, const char* buf, NPBool file)
{
	return netscapeFuncs->posturl(instance, url, window, len, buf, file);
}

NPError
NetscapePlugIn::NPN_RequestRead
(NPStream *stream, NPByteRange *rangeList)
{
	return netscapeFuncs->requestread(stream, rangeList);
}

NPError
NetscapePlugIn::NPN_NewStream
(NPMIMEType type, const char *target, NPStream **stream)
{
	VERSION_CHECK(NPVERS_HAS_STREAMOUTPUT);
	return netscapeFuncs->newstream(instance, type, target, stream);
}

int32
NetscapePlugIn::NPN_Write
(NPStream *stream, int32 len, void *buffer)
{
	VERSION_CHECK(NPVERS_HAS_STREAMOUTPUT);
	return netscapeFuncs->write(instance, stream, len, buffer);
}

NPError
NetscapePlugIn::NPN_DestroyStream
(NPStream* stream, NPError reason)
{
	VERSION_CHECK(NPVERS_HAS_STREAMOUTPUT);
	return netscapeFuncs->destroystream(instance, stream, reason);
}

void
NetscapePlugIn::NPN_Status
(const char *message)
{
	netscapeFuncs->status(instance, message);
}

const char*
NetscapePlugIn::NPN_UserAgent
(void)
{
	return netscapeFuncs->uagent(instance);
}

void *
NetscapePlugIn::NPN_MemAlloc
(uint32 size)
{
	return netscapeFuncs->memalloc(size);
}

void
NetscapePlugIn::NPN_MemFree
(void *ptr)
{
	netscapeFuncs->memfree(ptr);
}

void
NetscapePlugIn::NPN_ReloadPlugins
(NPBool reloadPages)
{
	netscapeFuncs->reloadplugins(reloadPages);
}

JRIEnv*
NetscapePlugIn::NPN_GetJavaEnv(void)
{
	return netscapeFuncs->getJavaEnv();
}

jref
NetscapePlugIn::NPN_GetJavaPeer
(void)
{
	return netscapeFuncs->getJavaPeer(instance);
}
