/* --------------------------------------------------------------------------------------------
 *  EL-POINT subset version for KARIHITO
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [GraphicBuffer.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "GraphicBuffer.h"
#include "File.h"
#include "Errors.h"

int
GraphicBuffer::nInstance = 0;

HDC
GraphicBuffer::hDc = NULL;

GraphicBuffer::GraphicBuffer
(void):
hBitmap(NULL),
width(0),
height(0),
bits(NULL),
reference(NULL),
transmode(CGB_TRANS_SRCCOPY),
alpha(NULL)
{
	reference = new int;
	*reference = 1;
	if (NULL == hDc) {
		HWND dtpWnd = GetDesktopWindow();
		HDC dtpDc = GetDC(dtpWnd);
		hDc = CreateCompatibleDC(dtpDc);
		ReleaseDC(dtpWnd, dtpDc);
	}
	nInstance++;
}

GraphicBuffer::GraphicBuffer
(GraphicBuffer &src):
bmih(src.bmih),
hBitmap(src.hBitmap),
width(src.width),
height(src.height),
bits(src.bits),
transmode(src.transmode),
key(src.key)
{
	reference = src.reference;
	*reference += 1;
	if (NULL != src.alpha) alpha = new GraphicBuffer(*src.alpha);
	else alpha = NULL;
}

GraphicBuffer::GraphicBuffer
(GraphicBuffer *src)
{
	reference = new int;
	*reference = 1;
	if (NULL == hDc) {
		HWND dtpWnd = GetDesktopWindow();
		HDC dtpDc = GetDC(dtpWnd);
		hDc = CreateCompatibleDC(dtpDc);
		ReleaseDC(dtpWnd, dtpDc);
	}
	nInstance++;
	width = src->width;
	height = src->height;
	hBitmap = CreateDIB(width, height);
	if (NULL != hBitmap) memcpy(bits, src->bits, width * height * 4);
	key = src->key;
	transmode = src->transmode;
	if (NULL != src->alpha) alpha = new GraphicBuffer(*src->alpha);
	else alpha = NULL;
}

GraphicBuffer::~GraphicBuffer
(void)
{
	*reference -= 1;
	if (0 != *reference) return;
	delete reference;
	nInstance--;
	if (NULL != hBitmap) DeleteObject(hBitmap);
	if (0 == nInstance) {
		if (NULL != hDc) {
			DeleteDC(hDc);
			hDc = NULL;
		}
	}
	if (NULL != alpha) delete alpha;
}

int
GraphicBuffer::LoadImage
(const char *filename)
{
	DOUT("LoadImage: %s\n", filename);
	if (NULL == hDc) {
		DOUT("GraphicBuffer Class is not initialized!\n");
		return ERROR_UNKNOWN;
	}
	File file;
	if (!file.Open(filename, CFO_READ)) return ERROR_FILE_OPEN;
	unsigned long filesize;
	if (!file.GetFileSize(filesize)) return ERROR_UNKNOWN;
	char *data = new char[filesize];
	if (NULL == data) return ERROR_MEMORY;
	if (!file.Read(data, filesize)) {
		delete data;
		return ERROR_FILE_READ;
	}
	file.Close();
	int result = LoadBitmap(data, filesize);	// BMP�Ƃ��ēǂݍ���
	delete data;
	return result;
}

int
GraphicBuffer::ResourceImage
(LPCTSTR resourcename, int width, int height, HINSTANCE hInstance)
{
	if (NULL == hDc) {
		DOUTR("GraphicBuffer Class is not initialized!\n");
		return ERROR_UNKNOWN;
	}
	this->width = width;
	this->height = height;
	hBitmap = CreateDIB(width, height);
	if (NULL == hBitmap) return ERROR_MEMORY;
	HBITMAP resource = ::LoadBitmap(hInstance, resourcename);
	if (NULL == resource) return ERROR_FILE_OPEN;
	HDC resDc = CreateCompatibleDC(hDc);
	if (NULL == resDc) {
		DOUTR("can not create dc\n");
		DeleteObject(resource);
		return ERROR_UNKNOWN;
	}
	SelectObject(resDc, resource);
	HBITMAP oldBitmap = (HBITMAP)SelectObject(hDc, hBitmap);
	if (0 == BitBlt(hDc, 0, 0, width, height, resDc, 0, 0, SRCCOPY)) {
		DOUTR("ResourceBitmap: BitBlt failed\n");
		return ERROR_UNKNOWN;
	}
	SelectObject(hDc, oldBitmap);
	DeleteObject(resource);
	DeleteObject(resDc);
	DOUTR("OK\n");
	return ERROR_OK;
}

bool
GraphicBuffer::GetData
(unsigned long &width, unsigned long &height, char *&bits) const
{
	if (NULL == this->bits) return false;
	width = this->width;
	height = this->height;
	bits = this->bits;
	return true;
}

const LPBITMAPINFO
GraphicBuffer::GetLpBitsInfo
(void) const
{
	return (LPBITMAPINFO)&bmih;
}

HBITMAP
GraphicBuffer::CreateDIB
(unsigned long width, unsigned long height)
{
	ZeroMemory(&bmih, sizeof(BITMAPINFOHEADER));
	bmih.biSize = sizeof(BITMAPINFOHEADER);
	bmih.biWidth = width;
	bmih.biHeight = -(long)height;
	bmih.biPlanes = 1;
	bmih.biBitCount = 32;
	bmih.biCompression = BI_RGB;
	return CreateDIBSection(NULL, (LPBITMAPINFO)&bmih, DIB_RGB_COLORS, (LPVOID *)&bits, NULL, 0);
}

int
GraphicBuffer::LoadBitmap
(const char *buffer, unsigned long size)
{
	DOUT("LoadBitmap\n");
	// BITMAPFILEHEADER
	if ((buffer[0] != 'B' ) || (buffer[1] != 'M')) return ERROR_INVAL_DATA;
	unsigned long filesize = (unsigned char)buffer[2] | ((unsigned char)buffer[3] << 8) | ((unsigned char)buffer[4] << 16) | ((unsigned char)buffer[5] << 24);
	if (filesize != size) return ERROR_INVAL_DATA;
	unsigned long headersize = (unsigned char)buffer[10] | ((unsigned char)buffer[11] << 8) | ((unsigned char)buffer[12] << 16) | ((unsigned char)buffer[13] << 24);
	buffer += 14;
	size -= 14;
	// BITMAPINFOHEADER
	width = (unsigned char)buffer[4] | ((unsigned char)buffer[5] << 8) | ((unsigned char)buffer[6] << 16) | ((unsigned char)buffer[7] << 24);
	height = (unsigned char)buffer[8] | ((unsigned char)buffer[9] << 8) | ((unsigned char)buffer[10] << 16) | ((unsigned char)buffer[11] << 24);
	DOUT("\twidth:  %d\n", width);
	DOUT("\theight: %d\n", height);
	LPBITMAPINFOHEADER bmih = (LPBITMAPINFOHEADER)buffer;
	buffer += headersize - 14;
	size -= headersize - 14;

	// �]���E�ϊ�
	DOUT("convert to DIB ...");
	hBitmap = CreateDIB(width, height);
	if (NULL == hBitmap) {
		DOUTR("CreateDIB failed\n");
		return ERROR_MEMORY;
	}
	HBITMAP oldBitmap = (HBITMAP)SelectObject(hDc, hBitmap);
	if (GDI_ERROR == StretchDIBits(hDc, 0, 0, width, height, 0, 0, width, height, buffer, (LPBITMAPINFO)bmih, DIB_RGB_COLORS, SRCCOPY)) {
		DOUTR("LoadBitmap: GDI_ERROR\n");
		return ERROR_UNKNOWN;
	}
	SelectObject(hDc, oldBitmap);
	DOUTR("OK\n");

	// �S�~����
	char *p = bits + 3;
	for (unsigned long i = 0; i < width * height; i++) {
		*p = 0;
		p += 4;
	}

	return ERROR_OK;
}

int
GraphicBuffer::MakeImage
(unsigned long width, unsigned long height)
{
	hBitmap = CreateDIB(width, height);
	this->width = width;
	this->height = height;
	if (NULL == hBitmap) DOUT("MakeImage %d x %d failed\n", width, height);
	return (NULL != hBitmap)? ERROR_OK: ERROR_MEMORY;
}

bool
GraphicBuffer::ColorKeyBackBlend
(GraphicBuffer *back, int x, int y)
{
	unsigned long b_width;
	unsigned long b_height;
	unsigned long *b_bits;
	if (!back->GetData(b_width, b_height, (char *&)b_bits)) return false;
	unsigned long f_width;
	unsigned long f_height;
	unsigned long *f_bits;
	if (!GetData(f_width, f_height, (char *&)f_bits)) return false;
	b_bits += (y * b_width) + x;
	unsigned long width = ((x + f_width) > b_width)? b_width - x: f_width;
	unsigned long height = ((y + f_height) > b_height)? b_height - y: f_height;
	for (unsigned long dy = 0; dy < height; dy++) {
		for (unsigned long dx = 0; dx < width; dx++, f_bits++, b_bits++) {
			if (*f_bits != key) continue;
			*f_bits = *b_bits;
		}
		b_bits += b_width - width;
		f_bits += f_width - width;
	}
	return true;
}

bool
GraphicBuffer::ColorKeyBackBlend
(GraphicBuffer *back, int r, int g, int b, int x, int y)
{
	unsigned long oldkey = key;
	key = RGB(r, g, b);
	bool result = ColorKeyBackBlend(back, x, y);
	key = oldkey;
	return result;
}

bool
GraphicBuffer::ColorKeyOverBlend
(GraphicBuffer *over, int x, int y)
{
	unsigned long b_width;
	unsigned long b_height;
	unsigned long *b_bits;
	if (!GetData(b_width, b_height, (char *&)b_bits)) return false;
	unsigned long f_width;
	unsigned long f_height;
	unsigned long *f_bits;
	if (!over->GetData(f_width, f_height, (char *&)f_bits)) return false;
	b_bits += (y * b_width) + x;
	unsigned long key;
	over->GetTransColor(key);
	unsigned long width = ((x + f_width) > b_width)? b_width - x: f_width;
	unsigned long height = ((y + f_height) > b_height)? b_height - y: f_height;
	for (unsigned long dy = 0; dy < height; dy++) {
		for (unsigned long dx = 0; dx < width; dx++, f_bits++, b_bits++) {
			if (*f_bits == key) continue;
			*b_bits = *f_bits;
		}
		b_bits += b_width - width;
		f_bits += f_width - width;
	}
	return true;
}

bool
GraphicBuffer::Blt
(GraphicBuffer *src, int x, int y)
{
	unsigned long b_width;
	unsigned long b_height;
	unsigned long *b_bits;
	if (!GetData(b_width, b_height, (char *&)b_bits)) return false;
	unsigned long f_width;
	unsigned long f_height;
	unsigned long *f_bits;
	if (!src->GetData(f_width, f_height, (char *&)f_bits)) return false;
	b_bits += (y * b_width) + x;
	unsigned long width = ((x + f_width) > b_width)? b_width - x: f_width;
	unsigned long height = ((y + f_height) > b_height)? b_height - y: f_height;
	for (unsigned long dy = 0; dy < height; dy++) {
		memcpy(b_bits, f_bits, width * 4);
		b_bits += b_width;
		f_bits += f_width;
	}
	return true;
}

bool
GraphicBuffer::BltToBuffer
(GraphicBuffer *buf, int buf_x, int buf_y, int src_x, int src_y, int src_w, int src_h)
{
	unsigned long buf_width;
	unsigned long buf_height;
	unsigned long *buf_bits;
	if (!buf->GetData(buf_width, buf_height, (char *&)buf_bits)) return false;
	buf_bits += (buf_y * buf_width) + buf_x;
	unsigned long src_width;
	unsigned long src_height;
	unsigned long *src_bits;
	if (!GetData(src_width, src_height, (char *&)src_bits)) return false;
	src_bits += (src_y * src_width) + src_x;
	if (src_w < 0) src_w = src_width;
	else if ((unsigned long)src_w > (src_x + src_width)) src_w = src_width - src_x;
	if (src_h < 0) src_h = src_height;
	else if ((unsigned long)src_h > (src_y + src_height)) src_h = src_height - src_y;

	unsigned long blt_width = ((unsigned long)(buf_x + src_w) > buf_width)? buf_width - buf_x: src_w;
	unsigned long blt_height = ((unsigned long)(buf_y + src_h) > buf_height)? buf_height - buf_y: src_h;
	for (unsigned long dy = 0; dy < blt_height; dy++) {
		memcpy(buf_bits, src_bits, blt_width * 4);
		buf_bits += buf_width;
		src_bits += src_width;
	}
	return true;
}

void
GraphicBuffer::SetTransColor
(int r, int g, int b)
{
	SetTransColor(RGB(r, g, b));
}

void
GraphicBuffer::SetTransColor
(unsigned long rgb)
{
	transmode = CGB_TRANS_COLORKEY;
	key = rgb;
}

bool
GraphicBuffer::GetTransColor
(unsigned long &colorkey)
{
	if (CGB_TRANS_COLORKEY != transmode) return false;
	colorkey = key;
	return true;
}

void
GraphicBuffer::ResetTransColor
(void)
{
	transmode = CGB_TRANS_SRCCOPY;
}

int
GraphicBuffer::GetTransMode
(void)
{
	return transmode;
}

bool
GraphicBuffer::SetAlphaData
(GraphicBuffer *alpha)
{
	if (NULL != this->alpha) {
		delete this->alpha;
		this->alpha = NULL;
	}
	if (NULL == alpha) {
		transmode = CGB_TRANS_SRCCOPY;
		return true;
	}
	for (;;) {
		unsigned long a_width;
		unsigned long a_height;
		char *a_bits;
		if (!alpha->GetData(a_width, a_height, a_bits)) {
			DOUT("can not get alpha data mwtrics\n");
			break;
		}
		if ((a_width != width) || (a_height != height)) {
			DOUT("alpha data size is invalid\n");
			break;
		}
		this->alpha = new GraphicBuffer(*alpha);
		if (NULL == this->alpha) break;
		transmode = CGB_TRANS_ALPHADATA;
		return true;
	}
	transmode = CGB_TRANS_SRCCOPY;
	return false;
}

bool
GraphicBuffer::SetTextFont
(int size, int width, int height, int r, int g, int b)
{
	SetFont(size);
	SetAlign(width, height);
	SetColor(r, g, b);
	return true;
}

bool
GraphicBuffer::SetTextBkColor
(int r, int g, int b)
{
	SetBackColor(r, g, b);
	return true;
}

bool
GraphicBuffer::DrawText
(int x, int y, int code)
{
	if (NULL == hDc) return false;
	HBITMAP oldbmp = (HBITMAP)SelectObject(hDc, hBitmap);
	SetDC(hDc);
	bool result = GraphicTextGDI::DrawText(x, y, code);
	ResetDC();
	SelectObject(hDc, oldbmp);
	return result;
}

bool
GraphicBuffer::DrawString
(int x, int y, char *string)
{
	if (NULL == hDc) return false;
	HBITMAP oldbmp = (HBITMAP)SelectObject(hDc, hBitmap);
	SetDC(hDc);
	bool result = GraphicTextGDI::DrawString(x, y, string);
	ResetDC();
	SelectObject(hDc, oldbmp);
	return result;
}

void
GraphicBuffer::FillRect
(int sx, int sy, int ex, int ey, unsigned long color)
{
	if (NULL == hDc) return;
	HBITMAP oldbmp = (HBITMAP)SelectObject(hDc, hBitmap);
	HBRUSH hBr = CreateSolidBrush(color);
	RECT rect;
	SetRect(&rect, sx, sy, ex, ey);
	::FillRect(hDc, &rect, hBr);
	DeleteObject(hBr);
	SelectObject(hDc, oldbmp);
}
