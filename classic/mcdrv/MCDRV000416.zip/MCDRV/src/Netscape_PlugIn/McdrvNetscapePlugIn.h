/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 Netscape Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [McdrvNetscapePlugIn.h]
 *   NetscapePlugIn�N���X���p�����AMCDRV�ŗL�̎������s���N���X�B
 * -------------------------------------------------------------------------------------------- */
#if !defined(__McdrvNetscapePlugIn_h__)
#	define	__McdrvNetscapePlugIn_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__NetscapePlugIn_h__)
#		include "NetscapePlugIn.h"
#	endif	// !defined(__NetscapePlugIn_h__)

#	if !defined(__LocalFile_h__)
#		include "LocalFile.h"
#	endif	// !defined(__LocalFile_h__)

#	if !defined(__HashedWindowProcDivider_h__)
#		include "HashedWindowProcDivider.h"
#	endif	// !defined(__HashedWindowProcDivider_h__)

#	if !defined(__MCDriver__)
class MCDriver;
#		define	__MCDriver__
#	endif	// !defined(__MCDriver__)

#	if !defined(__GraphicBuffer__)
class GraphicBuffer;
#		define	__GraphicBuffer__
#	endif	// !defined(__GraphicBuffer__)

class McdrvNetscapePlugIn: public NetscapePlugIn, public HashedWindowProcDivider{
private:
#	define	CMNPI_MOUSEAREA_INVALID		0
#	define	CMNPI_MOUSEAREA_ON_APP		1
#	define	CMNPI_MOUSEAREA_ON_PREV		2
#	define	CMNPI_MOUSEAREA_ON_PLAY		3
#	define	CMNPI_MOUSEAREA_ON_PAUSE	4
#	define	CMNPI_MOUSEAREA_ON_STOP		5
	static unsigned long HighColor[16];
	static unsigned long LowColor[16];
	static RECT areas[4];
	char *mime;
	char *buffer;
	int bufferSize;
	LocalFile lf;
	MCDriver *mcd;
	HWND hWnd;
	WNDPROC oldProc;
	GraphicBuffer *image;
	GraphicBuffer *offscreen;
	POINT point;
	SIZE size;
	unsigned long bgcolor;
	int *vols;
	int *highVols;
	int *highCnts;
	int channels;
	int mouseArea;
	bool mousePushed;
	int mousePushedArea;
	bool playing;
	bool pausing;
public:
	McdrvNetscapePlugIn(NPNetscapeFuncs *funcs, NPP instance);
	~McdrvNetscapePlugIn(void);
	NPError NPP_New(NPMIMEType pluginType, uint16 mode, int16 argc, char **argn, char **argv, NPSavedData *saved);
	NPError NPP_Destroy(NPSavedData **save);
	NPError NPP_NewStream(NPMIMEType type, NPStream *stream, NPBool seekable, uint16 *stype);
	NPError NPP_DestroyStream(NPStream *stream, NPReason reason);
	void NPP_StreamAsFile(NPStream *stream, const char *fname);
	int32 NPP_WriteReady(NPStream *stream);
	int32 NPP_Write(NPStream *stream, int32 offset, int32 len, void *buffer);
	NPError NPP_SetWindow(NPWindow *window);
private:
	LRESULT WindowProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam);	// HashedWindowPRocDivider
	unsigned long HtmlColor(const char *str);
	double ParseVersion(const char *str);
	void DrawEqualizer(void);
	void MouseCheck(void);
	int CheckArea(POINT pt);
	void ButtonOn(int area);
	void ButtonOff(int area);
	void ButtonPushed(int area);
};

#	if !defined(__McdrvNetscapePlugIn__)
#		define	__McdrvNetscapePlugIn__
#	endif	// !defined(__McdrvNetscapePlugIn__)

#endif	// !defined(__McdrvNetscapePlugIn_h__)
