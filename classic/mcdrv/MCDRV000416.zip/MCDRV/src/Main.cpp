/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [Main.cpp]
 * -------------------------------------------------------------------------------------------- */
#define	__Main__
#include "Common.h"
#undef	__Main__
#include "LocalFile.h"
#include "MCDriver.h"
#include "Errors.h"
#include "Version.h"

void
help
(void)
{
	puts("Usage: MCDRV <filename>\n");
}

void
main
(int argc, char **argv)
{
	printf("Win32 music creative driver version %d.%02d (c)2000 �Ƃ悵��\n", PLAYER_VERSION_MAJOR, PLAYER_VERSION_MINOR);
	printf("            - based on X68k version 0.69 (c)1993-97 CUL.\n");
	if (2 != argc) {
		help();
		exit(ERROR_UNKNOWN);
	}
	int result = ERROR_OK;
	{
		LocalFile f;
		if (!f.Open(argv[1], CFO_READ)) {
			result =ERROR_FILE_OPEN;
			goto quit;
		}
		unsigned long filesize;
		f.GetFileSize(filesize);
		unsigned char *data;
		data = new unsigned char[filesize];
		if (NULL == data) {
			result = ERROR_MEMORY;
			goto quit;
		}
		if (!f.Read((char *)data, filesize)) {
			result = ERROR_FILE_READ;
			goto quit;
		}
		if (!f.Close()) {
			result = ERROR_FILE_CLOSE;
			goto quit;
		}
		char path[_MAX_PATH];
		_snprintf(path, _MAX_PATH, "%s", argv[1]);
		char *pathend;
		pathend = path;
		char *p;
		for (p = path; 0 != *p; p++) {
			if (('\\' == *p) || ('/' == *p)) pathend = p;
		}
		char *localpath;
		if ((p == path) && ('\\' != *p) && ('/' != *p)) localpath = NULL;
		else localpath = path;
		*pathend = 0;
		LocalFile *lf;
		lf = new LocalFile(localpath);
		{
			MCDriver mcd(NULL, lf);
			if (!mcd.SetData(data, filesize)) {
				result = ERROR_UNSUPPORTED;
				goto quit;
			}
			mcd.Play();
			fgetchar();
		}
quit:
		if (NULL != lf) delete lf;
		if (NULL != data) delete data;
	}
	exit(result);
}
