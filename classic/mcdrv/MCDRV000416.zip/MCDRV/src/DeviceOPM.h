/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [DeviceOPM.h]
 *   SoundDevice�𓥏P����API�̌n�̖��߂��AOPM�f�o�C�X�ɑ΂�����ۂ̃��W�X�^�����
 *  �ϊ�����N���X�B���̃N���X���p�����AWrite/Read/Update/Initialize���������邱�ƂŁA
 *  SoundDevice�N���X�����̃N���X���\�z�ł���B
 * -------------------------------------------------------------------------------------------- */
#if !defined(__DeviceOPM_h__)
#	define	__DeviceOPM_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__SoundDevice_h__)
#		include "SoundDevice.h"
#	endif	// !defined(__SoundDevice_h__)

abstract class DeviceOPM: public SoundDevice{
public:
	typedef struct _voice{
		unsigned char fl_con;
		unsigned char slot_mask;
		unsigned char dt1_mul[4];
		unsigned char tl[4];
		unsigned char ks_ar[4];
		unsigned char ams_d1r[4];
		unsigned char dt2_d2r[4];
		unsigned char d1l_rr[4];
	} VOICE, *LPVOICE;
private:
	int active_channel;
	int voice_number[8];
	int bank_number[8];
	int pan[8];
	int volume[8];
	VOICE voice[2][128];
public:
	DeviceOPM(void);
	virtual ~DeviceOPM(void);

	void SetPitch(int pitch);	// SoundDevice
	void SetVolume(int volume);	// SoundDevice
	void SetVoice(int voice, int back = 0);	// SoundDevice
	void SetPan(int pan);	// SoundDevice
	void KeyOn(void);	// SoundDevice
	void KeyOff(void);	// SoundDevice
	void SetActiveChannel(int channel);	// SoundDevice

	bool SetVoiceData(int n, LPVOICE voice, int back = 0);

	virtual void Write(unsigned char reg, unsigned char value) = 0;
	virtual unsigned char Read(void) = 0;
};

#	if !defined(__DeviceOPM__)
#		define	__DeviceOPM__
#	endif	// !defined(__DeviceOPM__)

#endif	// !defined(__DeviceOPM_h__)
