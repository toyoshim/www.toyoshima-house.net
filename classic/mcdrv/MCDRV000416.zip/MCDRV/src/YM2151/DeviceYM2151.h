/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [DeviceYM2151.h]
 *   MAME�Ɋ܂܂��YM2151���W���[���𗘗p����SoundDevice�����̃N���X�B
 * -------------------------------------------------------------------------------------------- */
#if !defined(__DeviceYM2151_h__)
#	define	__DeviceYM2151_h__

#	if !defined(__Common_h__)
#		include "../Common.h"
#	endif	// !defined(__Common_h__)

#	if	!defined(__DeviceOPM_h__)
#		include "../DeviceOPM.h"
#	endif	// !defined(__DeviceOPM_h__)

class DeviceYM2151: public DeviceOPM{
private:
	short *buffer[2];
public:
	DeviceYM2151(void);
	~DeviceYM2151(void);

	bool Initialize(void);	// SoundDevice
	void Update(short *buffer, int count);	// SoundDevice

	void Write(unsigned char reg, unsigned char value);	// DeviceOPM
	unsigned char Read(void);	// DeviceOPM

private:
	void BufferMix(short *dst, short **src, int count);
};

#	if !defined(__DeviceYM2151__)
#		define	__DeviceYM2151__
#	endif	// !defined(__DeviceYM2151__)

#endif	// !defined(__DeviceYM2151_h__)
