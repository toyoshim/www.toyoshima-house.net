/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [DeviceYM2151.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "DeviceYM2151.h"

namespace YM2151{
	typedef	short INT16;
#	pragma	warning(disable: 4244)
#	pragma	warning(disable: 4018)
#	define	__MCDRV__
#	define	FM_EMU
#	define	__inline__	inline
#	include "ym2151.h"
#	include "ym2151.c"
};

DeviceYM2151::DeviceYM2151
(void)
{
	buffer[0] = new short[1024];
	buffer[1] = new short[1024];
}

DeviceYM2151::~DeviceYM2151
(void)
{
	YM2151::YM2151Shutdown();
	if (NULL != buffer[0]) delete buffer[0];
	if (NULL != buffer[1]) delete buffer[1];
}

bool
DeviceYM2151::Initialize
(void)
{
	if ((NULL == buffer[0]) || (NULL == buffer[1])) return false;
	return 0 == YM2151::YM2151Init(1, 4000000, 44100);
}

void
DeviceYM2151::Update
(short *buffer, int count)
{
	count >>= 1;
	while (count > 0) {
		if (count > 1024) {
			YM2151::YM2151UpdateOne(0, this->buffer, 1024);
			BufferMix(buffer, this->buffer, 1024);
			buffer += count * 2;
			count -= 1024;
		} else {
			YM2151::YM2151UpdateOne(0, this->buffer, count);
			BufferMix(buffer, this->buffer, count);
			count = 0;
		}
	}
}

void
DeviceYM2151::Write
(unsigned char reg, unsigned char value)
{
	YM2151::YM2151WriteReg(0, reg, value);
}

unsigned char
DeviceYM2151::Read
(void)
{
	return YM2151::YM2151ReadStatus(0);
}

void
DeviceYM2151::BufferMix
(short *dst, short **src, int count)
{
	for (int i = 0; i < count; i++) {
		*dst++ = src[0][i];
		*dst++ = src[1][i];
	}
}
