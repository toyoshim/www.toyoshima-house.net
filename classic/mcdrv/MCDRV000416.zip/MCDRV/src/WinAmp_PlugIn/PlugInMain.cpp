/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 WinAmp Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [PlugInMain.cpp]
 * -------------------------------------------------------------------------------------------- */
#define	__Main__
#include "Common.h"
#undef	__Main__
#include "InputModuleMDC.h"
#include "LocalFile.h"
#include "StreamExternalBuffer.h"
#include "MCDriver.h"

//
// for WinAmp Input Module Plug-in
//
static InputModuleMDC *im = NULL;

extern "C" __declspec(dllexport) LPWINAMP_IN_MODULE
winampGetInModule2
(void)
{
	if (NULL == im) im = new InputModuleMDC();
	if (NULL == im) return NULL;
	return im->GetWinAmpInModule();
}

//
// for ���A��
//
static StreamExternalBuffer *stream = NULL;

static MCDriver *mcd = NULL;

extern "C" __declspec(dllexport) void
DSP_WRITE
(void *buffer, unsigned int size)
{
	if (NULL != stream) stream->Update((short *)buffer, size >> 1);
}

extern "C" __declspec(dllexport) void
StopMusic(void)
{
	if (NULL != mcd) {
		delete mcd;
		mcd = NULL;
	}
	if (NULL != stream) {
		delete stream;
		stream = NULL;
	}
}

extern "C" __declspec(dllexport) BOOL
PlayMusicBuffer(char *data, int length)
{
	StopMusic();
	stream = new StreamExternalBuffer();
	if (NULL == stream) return false;
	mcd = new MCDriver(stream);
	if ((NULL == mcd) || !mcd->SetData((unsigned char *)data, length)) {
		StopMusic();
		return false;
	}
	return mcd->Play();
}

extern "C" __declspec(dllexport) BOOL
PlayMusic(char *fileName)
{
	LocalFile lf;
	if (!lf.Open(fileName, CFO_READ)) return false;
	unsigned long filesize;
	if (!lf.GetFileSize(filesize)) return false;
	unsigned char *data = new unsigned char[filesize];
	if (NULL == data) return false;
	if (!lf.Read((char *)data, filesize) || !lf.Close()) {
		delete data;
		return false;
	}
	BOOL result = PlayMusicBuffer((char *)data, filesize);
	delete data;
	return result;
}
