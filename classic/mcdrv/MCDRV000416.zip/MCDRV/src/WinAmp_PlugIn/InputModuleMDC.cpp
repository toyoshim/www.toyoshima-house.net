/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 WinAmp Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [InputModuleMDC.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "InputModuleMDC.h"
#include "LocalFile.h"
#include "StreamExternalBuffer.h"
#include "MCDriver.h"
#include "Version.h"

InputModuleMDC::InputModuleMDC
(void):
stream(NULL)
{
}

InputModuleMDC::~InputModuleMDC
(void)
{
}

const char *
InputModuleMDC::GetModuleDescription
(void)
{
	return "�Ƃ悵�܃n�E�X music creative driver";
}

bool
InputModuleMDC::GetModuleVersion
(int &major, int &minor)
{
	major = PLAYER_VERSION_MAJOR;
	minor = PLAYER_VERSION_MINOR;
	return true;
}

const char *
InputModuleMDC::GetAcceptFileList
(void)
{
	return
		"mdc\0music creative driver file (*.mdc)\0"
		"mdx\0MDX file (*.mdx)\0";
}

const char *
InputModuleMDC::GetTitle
(const char *fileName)
{
	if (((NULL == fileName) || (0 == *fileName)) && (NULL != mcd)) return (char *)mcd->GetTitle();
	unsigned char *data;
	int datasize;
	if (!FileLoad(fileName, data, datasize)) return "";
	const unsigned char *title = MCDriver::GetTitle(data, datasize);
	delete data;
	return (const char *)title;
}

bool
InputModuleMDC::CheckFormat
(const char *fileName)
{
	return true;
	unsigned char *data;
	int datasize;
	if (!FileLoad(fileName, data, datasize)) return false;
	bool result = MCDriver::CheckFormat(data, datasize);
	delete data;
	return result;
}

bool
InputModuleMDC::PlayMusic
(const char *fileName)
{
	stream = new StreamExternalBuffer();
	if (NULL == stream) return false;
	ParseFileName(fileName);
	if (!lf.Open(lastFileName, CFO_READ)) return false;
	unsigned long filesize;
	if (!lf.GetFileSize(filesize)) return false;
	unsigned char *data = new unsigned char[filesize];
	if (NULL == data) return false;
	if (!lf.Read((char *)data, filesize) || !lf.Close()) {
		delete data;
		return false;
	}
	mcd = new MCDriver(stream, &lf);
	if (NULL == mcd) {
		delete data;
		return false;
	}
	if (!mcd->SetData(data, filesize)) {
		delete data;
		return false;
	}
	delete data;
	return mcd->Play();
}

void
InputModuleMDC::StopMusic
(void)
{
	if (NULL != mcd) {
		delete mcd;
		mcd = NULL;
	}
	if (NULL != stream) {
		delete stream;
		stream = NULL;
	}
}

bool
InputModuleMDC::StreamUpdate
(short *buffer, int count)
{
	static int volume = 256;
	if ((NULL == stream) || (NULL == mcd)) return true;
	stream->Update(buffer, count);
	int loop = mcd->GetCurrentLoopCount();
	if (-1 == loop) return false;
	if (loop < 2) {
		volume = 256;
		return true;
	}
	volume--;
	short *p = buffer;
	for (int i = 0; i < count; i++) {
		*p = *p * volume / 256;
		p++;
	}
	if (0 == volume) return false;
	return true;
}

bool
InputModuleMDC::SetVisualData
(unsigned char data[76], int mode)
{
	if (mode != 1) return false;
	if (NULL == mcd) return false;
	LPSYSTEM_WORK system = mcd->GetSystemWork();
	LPEXT_TRACK_WORK ext = mcd->GetExtTrackWork();
	int n = system->inf_trnum;
	for (int i = 0; i < n; i++) {
		data[i * 4 + 0] = data[i * 4 + 1] = data[i * 4 + 2] = ext[i].key_on >> 3;
		data[i * 4 + 3] = 0;
		ext[i].key_on = 0;
	}
	for (i *= 4; i < 76; i++) data[i] = 0;
	return true;
}

void
InputModuleMDC::ParseFileName
(const char *fileName)
{
	char path[_MAX_PATH];
	strcpy(path, fileName);
	char *end = path;
	for (char *p = path; 0 != *p; p++) if (('\\' == *p) || ('/' == *p)) end = p;
	if (end == path) {
		if (('\\' == *end) || ('/' == *end)) {
			lf.SetLocalPath("");
			end++;
		} else lf.SetLocalPath(NULL);
	} else {
		*end++ = 0;
		lf.SetLocalPath(path);
	}
	strcpy(lastFileName, end);
}

bool
InputModuleMDC::FileLoad
(const char *fileName, unsigned char *&data, int &datasize)
{
	LocalFile lf;
	if (!lf.Open(fileName, CFO_READ)) return false;
	unsigned long filesize;
	if (!lf.GetFileSize(filesize)) return false;
	data = new unsigned char[filesize];
	if (NULL == data) return false;
	if (!lf.Read((char *)data, filesize) || !lf.Close()) {
		delete data;
		return false;
	}
	datasize = filesize;
	return true;
}
