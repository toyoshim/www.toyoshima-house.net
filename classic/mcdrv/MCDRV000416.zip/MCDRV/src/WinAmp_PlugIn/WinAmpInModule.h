/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 WinAmp Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [WinAmpInModule.h]
 *   WinAmp��Input Module�̍\�����`����N���X
 * -------------------------------------------------------------------------------------------- */
#if !defined(__WinAmpInModule_h__)
#	define	__WinAmpInModule_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__WinAmpOutModule_h__)
#		include "WinAmpOutModule.h"
#	endif	// !defined(__WinAmpOutModule_h__)

#	define	WINAMP_IN_MODULE_VERSION	0x100

#	if !defined(INPARAM)
#		define	INPARAM
#	endif	// !defined(INPARAM)

#	if !defined(OUTPARAM)
#		define	OUTPARAM
#	endif	// !defined(OUTPARAM)

typedef struct {
	OUTPARAM int version;
	OUTPARAM const char *description;
	INPARAM HWND hMainWnd;
	INPARAM HINSTANCE hDllInstance;
	OUTPARAM const char *FileExtensions;
	OUTPARAM int isSeekable;
	OUTPARAM int usesOutputPlug;

	OUTPARAM void (*Config)(HWND hParentWnd);
	OUTPARAM void (*About)(HWND hParentWnd);
	OUTPARAM void (*Init)(void);
	OUTPARAM void (*Quit)(void);
	OUTPARAM void (*GetFileInfo)(char *fileName, char *title, int *lengthInMs);
	OUTPARAM int (*InfoBox)(char *fileName, HWND hParentWnd);
	OUTPARAM int (*IsOurFile)(char *fileName);
	OUTPARAM int (*Play)(char *fileName);
	OUTPARAM void (*Pause)(void);
	OUTPARAM void (*UnPause)(void);
	OUTPARAM int (*IsPaused)(void);
	OUTPARAM void (*Stop)(void);

	OUTPARAM int (*GetLength)(void);
	OUTPARAM int (*GetOutputTime)(void);
	OUTPARAM void (*SetOutputTime)(int timeInMs);

	OUTPARAM void (*SetVolume)(int volume);
	OUTPARAM void (*SetPan)(int pan);
	
	INPARAM void (*SAVSAInit)(int maxLatencyInMs, int sRate);
	INPARAM void (*SAVSADeInit)(void);
	INPARAM void (*SAAddPCMData)(void *PCMData, int nCh, int bps, int timestamp); 
	INPARAM int (*SAGetMode)(void);
	INPARAM void (*SAAdd)(void *data, int timestamp, int csa);
	INPARAM void (*VSAAddPCMData)(void *PCMData, int nCh, int bps, int timestamp);
	INPARAM int (*VSAGetMode)(int *specNCh, int *waveNCh);
	INPARAM void (*VSAAdd)(void *data, int timestamp);
	INPARAM void (*VSASetInfo)(int nCh, int sRate);

	INPARAM int (*DSPIsActive)(void); 
	INPARAM int (*DSPDoSamples)(short int *samples, int nSamples, int bps, int nCh, int sRate);

	OUTPARAM void (*EQSet)(int on, char data[10], int preAmp);

	INPARAM void (*SetInfo)(int bitRate, int sRate, int stereo, int syncHed);
	INPARAM LPWINAMP_OUT_MODULE outMod;
} WINAMP_IN_MODULE, *LPWINAMP_IN_MODULE;

#	if !defined(__WINAMP_IN_MODULE__)
#		define	__WINAMP_IN_MODULE__
#	endif	// !defined(__WINAMP_IN_MODULE__)

#endif	// !defined(__WinAmpInModule_h__)
