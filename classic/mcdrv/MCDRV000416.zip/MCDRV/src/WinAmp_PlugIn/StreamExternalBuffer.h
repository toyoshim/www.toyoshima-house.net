/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [StreamExternalBuffer.h]
 *   PCM Stream���p�������N���X�B�Đ������ɂ͂�����炸�A�P���Ƀo�b�t�@�[�X�g���[�����
 *  ����݂̂ɂƂǂ܂�A�@���ˑ�����ۂ��Ă���B
 * -------------------------------------------------------------------------------------------- */
#if !defined(__StreamExternalBuffer_h__)
#	define	__StreamExternalBuffer_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__SoundStream_h__)
#		include "SoundStream.h"
#	endif	// !defined(__SoundStream_h__)

#	if !defined(__SoundDriver__)
class SoundDriver;
#		define	__SoundDriver__
#	endif	// !defined(__SoundDriver__)

class StreamExternalBuffer: public SoundStream{
private:
	SoundDriver *callback;
	int count;
	int rest;
	bool active;
public:
	StreamExternalBuffer(void);
	~StreamExternalBuffer(void);

	void SetTimerCallback(SoundDriver *driver);	// SoundStream
	void SetTimerInterval(double msec);	// SoundStream
	bool Start(void);	// SoundStream
	bool Stop(void);	// SoundStream

	void Update(short *buffer, int count);
};

#endif	// !defined(__StreamExternalBuffer_h__)
