/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [StreamExternalBuffer.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "StreamExternalBuffer.h"
#include "SoundDriver.h"

StreamExternalBuffer::StreamExternalBuffer
(void):
callback(NULL),
count(0),
rest(0),
active(false)
{
}

StreamExternalBuffer::~StreamExternalBuffer
(void)
{
}

void
StreamExternalBuffer::SetTimerCallback
(SoundDriver *driver)
{
	DOUT("callback : %08x\n", driver);
	callback = driver;
}

void
StreamExternalBuffer::SetTimerInterval
(double msec)
{
	rest = count = (int)floor(0.5 + 44.100 * msec);
	DOUT("COUNT: %d\n", count);
}

bool
StreamExternalBuffer::Start
(void)
{
	active = true;
	return true;
}

bool
StreamExternalBuffer::Stop
(void)
{
	active = false;
	return true;
}

void
StreamExternalBuffer::Update
(short *buffer, int count)
{
	if ((NULL == callback) || !active) {
		memset(buffer, 0, count * 2);
		return;
	}
	if (0 == this->count) {
		callback->Update(buffer, count);
		return;
	}
	count >>= 1;
	while (count > 0) {
		if (count >= rest) {
			callback->Update(buffer, rest * 2);
			count -= rest;
			buffer += rest * 2;
			callback->TimerCallback();
//			DOUT("REST:%d\nCOUNT:%d\n", rest, this->count);
			rest = this->count;
		} else {
			callback->Update(buffer, count * 2);
			rest = this->count - count;
			count = 0;
		}
	}
}
