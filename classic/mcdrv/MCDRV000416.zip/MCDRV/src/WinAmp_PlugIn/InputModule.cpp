/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 WinAmp Plug-in
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [InputModule.cpp]
 * -------------------------------------------------------------------------------------------- */
#include "InputModule.h"

InputModule *
InputModule::instance = NULL;

InputModule::InputModule
(void):
im_fixed(false),
im_init(false),
paused(false),
thread_handle(INVALID_HANDLE_VALUE),
kill_thread(false)
{
	ZeroMemory(&im, sizeof(WINAMP_IN_MODULE));
}

InputModule::~InputModule
(void)
{
	Stop();
}

LPWINAMP_IN_MODULE
InputModule::GetWinAmpInModule
(void)
{
	if (im_init) return NULL;
	im.version = WINAMP_IN_MODULE_VERSION;
	int major;
	int minor;
	if (!GetModuleVersion(major, minor)) major = minor = 0;
	_snprintf(description, CIM_BUFFER_SIZE, "%s v%d.%02d (x86)", GetModuleDescription(), major, minor);
	im.description = description;
	im.FileExtensions = GetAcceptFileList();
	im.usesOutputPlug = 1;
	im.Config = Config;
	im.About = About;
	im.Init = Init;
	im.Quit = Quit;
	im.GetFileInfo = GetFileInfo;
	im.InfoBox = InfoBox;
	im.IsOurFile = IsOurFile;
	im.Play = Play;
	im.Pause = Pause;
	im.UnPause = UnPause;
	im.Stop = Stop;
	im.GetLength = GetLength;
	im.GetOutputTime = GetOutputTime;
	im.SetOutputTime = SetOutputTime;
	im.SetVolume = SetVolume;
	im.SetPan = SetPan;
	im.EQSet = EQSet;
	im_init = true;
	instance = this;
	if (!im_fixed) {
		FixWinAmpInModule();
		im_fixed = true;
	}
	return &im;
}

void
InputModule::FixWinAmpInModule
(void)
{
}

const char *
InputModule::GetModuleDescription
(void)
{
	return "InputModule";
}

bool
InputModule::GetModuleVersion
(int &major, int &minor)
{
	major = 1;
	minor = 0;
	return true;
}

const char *
InputModule::GetAcceptFileList
(void)
{
	return "";
}

void
InputModule::ConfigDialog
(HWND hParentWnd)
{
}

void
InputModule::AboutDialog
(HWND hParentWnd)
{
	MessageBox(hParentWnd, im.description, "ABOUT", MB_OK);
}

const char *
InputModule::GetTitle
(const char *fileName)
{
	return "UNKNOWN";
}

bool
InputModule::InfoDialog
(const char *fileName, HWND hParentWnd)
{
	MessageBox(hParentWnd, GetTitle(fileName), "MUSIC INFORMATION", MB_OK);
	return true;
}

bool
InputModule::CheckFormat
(const char *fileName)
{
	return false;
}

bool
InputModule::PlayMusic
(const char *fileName)
{
	return false;
}

void
InputModule::StopMusic
(void)
{
}

bool
InputModule::StreamUpdate
(short *buffer, int count)
{
	ZeroMemory(buffer, count * 2);
	return false;
}

bool
InputModule::SetVisualData
(unsigned char [76], int mode)
{
	return false;
}

void
InputModule::Config
(HWND hParentWnd)
{
	if (NULL == instance) return;
	instance->ConfigDialog(hParentWnd);
}

void
InputModule::About
(HWND hParentWnd)
{
	if (NULL == instance) return;
	instance->AboutDialog(hParentWnd);
}

void
InputModule::Init
(void)
{
}

void
InputModule::Quit
(void)
{
}

void
InputModule::GetFileInfo
(char *fileName, char *title, int *lengthInMs)
{
	*lengthInMs = -1000;
	if (NULL == instance) *title = 0;
	else strcpy(title, instance->GetTitle(fileName));
}

int
InputModule::InfoBox
(char *fileName, HWND hParentWnd)
{
	return instance->InfoDialog(fileName, hParentWnd)? 0: -1;
}

int
InputModule::IsOurFile
(char *fileName)
{
	return instance->CheckFormat(fileName)? 0: -1;
}

int
InputModule::Play
(char *fileName)
{
	Stop();
	if (NULL == instance) return -1;
	instance->paused = false;
	int rate = 44100;
	int channel = 2;
	int bits = 16;
	int maxLatency = instance->im.outMod->Open(rate, channel, bits, -1, -1);
	if (maxLatency < 0) return -1;
	instance->im.SetInfo(rate * channel * bits / 1000, rate / 1000, channel, 1);
	instance->im.SAVSAInit(maxLatency, rate);
	instance->im.VSASetInfo(rate, channel);
	instance->im.SetVolume(-666);
	if (!instance->PlayMusic(fileName)) return -1;
	instance->kill_thread = false;
	DWORD id;
	instance->thread_handle = CreateThread(NULL, 0, PlayThread, (LPVOID)&(instance->kill_thread), 0, &id);
	if (INVALID_HANDLE_VALUE == instance->thread_handle) return -1;
	return 0;
}

void
InputModule::Pause
(void)
{
	if (NULL != instance) {
		instance->im.outMod->Pause(1);
		instance->paused = true;
	}
}

void
InputModule::UnPause
(void)
{
	if (NULL != instance) {
		instance->im.outMod->Pause(0);
		instance->paused = false;
	}
}

int
InputModule::IsPaused
(void)
{
	if (NULL != instance) return instance->paused? 1: 0;
	return 0;
}

void
InputModule::Stop
(void)
{
	if ((NULL == instance) || (INVALID_HANDLE_VALUE == instance->thread_handle)) return;
	instance->kill_thread = true;
	if (WaitForSingleObject(instance->thread_handle, INFINITE) == WAIT_TIMEOUT) TerminateThread(instance->thread_handle, 0);
	CloseHandle(instance->thread_handle);
	instance->thread_handle = INVALID_HANDLE_VALUE;
	instance->im.outMod->Close();
	instance->im.SAVSADeInit();
	instance->StopMusic();
}

int
InputModule::GetLength
(void)
{
	return -1000;
}

int
InputModule::GetOutputTime
(void)
{
	if (NULL == instance) return -1000;
	return instance->im.outMod->GetOutputTime();
}

void
InputModule::SetOutputTime
(int timeInMs)
{
}

void
InputModule::SetVolume
(int volume)
{
	if (NULL != instance) instance->im.outMod->SetVolume(volume);
}

void
InputModule::SetPan
(int pan)
{
	if (NULL != instance) instance->im.outMod->SetPan(pan);
}

void
InputModule::EQSet
(int on, char data[10], int preAmp)
{
}

DWORD WINAPI
InputModule::PlayThread
(LPVOID param)
{
	if (NULL == instance) return 1;
	bool *kill_thread = (bool *)param;

	int channel = 2;
	int bits = 16;
	int rate = 441000;
	bool loop = true;

	while (!*kill_thread) {
		if (loop && (instance->im.outMod->CanWrite() >= CIM_PLAY_BUFFER_SIZE << (instance->im.DSPIsActive()? 1: 0))) {
			loop = instance->StreamUpdate((short *)instance->buffer, CIM_PLAY_BUFFER_SIZE / 2);
			int l = CIM_PLAY_BUFFER_SIZE;
			int t = instance->im.outMod->GetWrittenTime();
			unsigned char vis[76];
			int mode = instance->im.SAGetMode();
			if (instance->SetVisualData(vis, mode)) instance->im.SAAdd(vis, t, mode);
			else instance->im.SAAddPCMData((char *)instance->buffer, channel, bits, t);
			instance->im.VSAAddPCMData((char *)instance->buffer, channel, bits, t);
			if (instance->im.DSPIsActive()) l = instance->im.DSPDoSamples((short *)instance->buffer, l / channel / (bits / 8), bits, channel, rate * channel * (bits / 8));
			instance->im.outMod->Write((char *)instance->buffer, l);
		} else {
			Sleep(1000 * CIM_PLAY_BUFFER_SIZE / (44100 * 2 * (16 / 8)) / 2);
		}
		if (!loop && (0 == instance->im.outMod->IsPlaying())) PostMessage(instance->im.hMainWnd, WM_USER + 2, 0, 0);
	}
	return 0;
}
