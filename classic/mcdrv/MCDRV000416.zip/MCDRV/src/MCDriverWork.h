/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [MCDriverWork.h]
 *   MCDRV�Ŏg���郏�[�N�G���A�̍\�����`����B���̃��[�N�G���A��X68k��
 *  �I���W�i���Ɠ����\�����Ƃ��Ă���A����MCDRV�R�[�����������₷���悤��
 *  �Ȃ��Ă���B
 * -------------------------------------------------------------------------------------------- */
#if !defined(__MCDriverWork_h__)
#	define	__MCDriverWork_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(_b)
#		define	_b	unsigned char
#	endif	// !defined(_b)

#	if !defined(_w)
#		define	_w	unsigned short
#	endif	// !defined(_w)

#	if !defined(_l)
#		define	_l	unsigned long
#	endif	// !defined(_l)

#	define	TRACK_EVENT_PLFO_MASK	0x8000
#	define	TRACK_EVENT_ALFO_MASK	0x4000
#	define	TRACK_EVENT_PORT_MASK	0x2000
#	define	TRACK_EVENT_FPOR_MASK	0x1000

typedef struct _system_work{
	_b *inf_midiinbuf[8];
	_w inf_play;
	_w inf_fades;
	_w inf_fadem;
	_w inf_ksfts;
	_w inf_ksftm;
	_w inf_ksft;
	_w inf_trnum;
	_w inf_truse;
	_w inf_loop;
	_w inf_temposns;
	_w inf_division;
	_w inf_tempo;
	_l inf_endclock;
	_l inf_nowclock;
	_l inf_interval;
	_l inf_passc;
	_w inf_passmin;
	_w inf_passsec;
	_l inf_tract;
} SYSTEM_WORK, *LPSYSTEM_WORK;

#	if !defined(__SYSTEM_WORK__)
#		define	__SYSTEM_WORK__
#	endif	// !defined(__SYSTEM_WORK__)

typedef struct _track_work{
	_b active;
	_b waitsignal;
	_b mutemark;
	_b curch;
	_w nowpitch;
	_b undef1;
	_b nowvolume;
	_w event;
	_w undef2;
	_l paramchgjobadr;

	_w paramchg;
	_w waspitch;
	_w wasvolume;
	_w nexttrlink;
	_l undef3;
	_l mmlptr;

	_b bankmsb;
	_b program;
	_b volmst;
	_b panmst;
	_w bend;
	_b creverb;
	_b cchorus;
	_w nowbar;
	_b nowstep;
	_b mvolmst;
	_b banklsb;
	_b bendrange;
	_w undef4;

	_l undef5;
	_l undef6;
	_l undef7;
	_l wasparamchg;
} TRACK_WORK, *LPTRACK_WORK;

#	if !defined(__TRACK_WORK__)
#		define	__TRACK_WORK__
#	endif	// !defined(__TRACK_WORK__)

#endif	// !defined(__MCDriverWork_h__)
