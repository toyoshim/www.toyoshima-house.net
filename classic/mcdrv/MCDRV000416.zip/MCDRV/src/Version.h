/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [Version.h]
 *   MCDRV�̃o�[�W������`
 * -------------------------------------------------------------------------------------------- */
#if !defined(__Version_h__)
#	define	__Version_h__

//	music creative driver version
#	define	DRIVER_VERSION_MAJOR	0
#	define	DRIVER_VERSION_MINOR	60

//	MCDRV.exe version
#	define	PLAYER_VERSION_MAJOR	0
#	define	PLAYER_VERSION_MINOR	60

//	in_mdc.dll version
#	define	MODULE_VERSION_MAJOR	0
#	define	MODULE_VERSION_MINOR	50

//	npmdc.dll version
#	define	PLUGIN_VERSION_MAJOR	0
#	define	PLUGIN_VERSION_MINOR	50

#	define	MAKE_FULL_VERSION(major, minor) ((double)(major.0 + (double)minor.0 / 100.0))

#endif	// !defined(__Version_h__)
