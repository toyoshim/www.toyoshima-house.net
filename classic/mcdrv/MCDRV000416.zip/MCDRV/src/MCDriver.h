/* --------------------------------------------------------------------------------------------
 *  music creative driver for Win32 (Netscape Plug-in / WinAmp Plug-in)
 *  (C) 1999,2000 �Ƃ悵��
 * --------------------------------------------------------------------------------------------
 *  [MCDriver.h]
 *   SoundDriver�N���X�ɏ�������MCDRV�𑀍삷��N���X
 * -------------------------------------------------------------------------------------------- */
#if !defined(__MCDriver_h__)
#	define	__MCDriver_h__

#	if !defined(__Common_h__)
#		include "Common.h"
#	endif	// !defined(__Common_h__)

#	if !defined(__MCDriverWork_h__)
#		include "MCDriverWork.h"
#	endif	// !defined(__MCDriverWork_h__)

#	if !defined(__SoundDriver_h__)
#		include "SoundDriver.h"
#	endif	// !defined(__SoundDriver_h__)

#	if !defined(__DeviceX68Sound_h__)
#		include "DeviceX68Sound.h"
#	endif	// !defined(__DeviceX68Sound_h__)

#	if !defined(__DeviceOPM__)
class DeviceOPM;
#		define	__DeviceOPM__
#	endif	// !defined(__DeviceOPM__)

#	if !defined(__SoundDevice__)
class SoundDevice;
#		define	__SoundDevice__
#	endif	// !defined(__SoundDevice__)

#	if !defined(__SoundStream__)
class SoundStream;
#		define	__SoundStream__
#	endif	// !defined(__SoundStream__)

#	if !defined(__File__)
class File;
#		define	__File__
#	endif	// !defined(__File__)

typedef struct _ext_track_work{
	int step;
	int gate;
	int tune;
	bool tie;
	int quo;
	int por_step;
	int por_target;
	int por_count;
	int repeat_count;
	int key_trans;
	int loop;
	int volume16;
	int fulltime_por;
	int pitch_lfo_type;
	int pitch_lfo_speed;
	int pitch_lfo_amp;
	int pitch_lfo_delay;
	int pitch_lfo_delay_count;
	int pitch_lfo_vector;
	int pitch_lfo_delta;
	int pitch_lfo_delta_high;
	int pitch_lfo_delta_low;
	int amp_lfo_type;
	int amp_lfo_speed;
	int amp_lfo_amp;
	int amp_lfo_delay;
	int amp_lfo_delay_count;
	int amp_lfo_vector;
	int amp_lfo_delta;
	int amp_lfo_delta_high;
	int amp_lfo_delta_low;
	bool hard_lfo_sync;
	int hard_lfo_pms_ams;
	int key_on;
	unsigned long mml;
	SoundDevice *sd;
} EXT_TRACK_WORK, *LPEXT_TRACK_WORK;

class MCDriver: public SoundDriver{
private:
	int major_version;
	int minor_version;
	unsigned char *title;
	int num_of_track;
	unsigned char **track_data;
	unsigned char *data;
	int datasize;
	unsigned char *work;
	LPSYSTEM_WORK system_work;
	LPTRACK_WORK track_work;
	LPEXT_TRACK_WORK ext_track_work;
	unsigned char *voice_data;
	unsigned char *adpcm_data;
	DeviceOPM *fm;
	DeviceX68Sound::DevicePCM8 *pcm8;
	SoundStream *stream;
	File *file;
	bool sleep;
public:
	static bool CheckFormat(const unsigned char *data, int datasize);
	static const unsigned char *GetTitle(const unsigned char *data, int datasize);
#	if defined(_DEBUG)
private:
	static void DisTrack(const unsigned char *data);
public:
#	endif	// defined(_DEBUG)

	MCDriver(SoundStream *stream = NULL, File *file = NULL);
	~MCDriver(void);

	bool SetData(const unsigned char *data, int datasize);	// SoundDriver
	bool Play(void);	// SoundDriver
	bool Stop(void);	// SoundDriver
	bool Pause(bool pause = true);	// SoundDriver

	const unsigned char *GetTitle(void);	// SoundDriver
	int GetCurrentLoopCount(void);	// SoundDriver

	void TimerCallback(void);	// SoundDriver
	void Update(short *buffer, int count);	// SoundDriver

	LPSYSTEM_WORK GetSystemWork(void);
	LPTRACK_WORK GetTrackWork(void);
	LPEXT_TRACK_WORK GetExtTrackWork(void);
private:
	void WorkInit(void);
	double CalcTimerCount(int division, int tempo);
	bool CheckFormat();
#	if defined(_DEBUG)
	void DumpTrackWork(int track);
#	endif	// defined(_DEBUG)
	void Eval(LPTRACK_WORK, LPEXT_TRACK_WORK);
};

#	if !defined(__MCDriver__)
#		define	__MCDriver__
#	endif	// !defined(__MCDriver__)

#endif	// !defined(__MCDriver_h__)
