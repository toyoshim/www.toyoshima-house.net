#ifndef __elisa_h__
#define __elisa_h__

typedef struct _elisa_str {
  unsigned short code;
  char font[8];
} elisa_str;

int elisa_init_char(elisa_str *str);
int elisa_init_string(elisa_str str[]);
int elisa_gv_draw_char(int x, int y, elisa_str *str, int lop);
int elisa_gv_draw_string(int x, int y, elisa_str str[], int gap, int lop);

#endif /* __elisa_h__ */
