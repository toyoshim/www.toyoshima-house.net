#include "elisa.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ELISA_PATH "b:\\system\\apps\\elisaR10.fon"

static unsigned short
sjis2elisa
(unsigned short sjis)
{
  unsigned short c;
  int u = (sjis >> 8) & 0xff;
  int d = sjis & 0xff;
  if (d > 0x7f) d--;
  d -= 0x40;
  u -= 0x81;
  c = u * 0xbc + d;

  if (c >= 4375) return 0x6c;
  else if (c >= 1410) return c + (0x20c - 1410);
  else if (c >= 690) return 0x6c;
  else if (c >= 658) return c + (0x1ec - 658);
  else if (c >= 612) return c + (0x1cb - 612);
  else if (c >= 564) return c + (0x1aa - 564);
  else if (c >= 502) return c + (0x192 - 502);
  else if (c >= 470) return c + (0x17a - 470);
  else if (c >= 376) return c + (0x124 - 376);
  else if (c >= 282) return c + (0xd1 - 282);
  else if (c >= 252) return c + (0xb7 - 252);
  else if (c >= 220) return c + (0x9d - 220);
  else if (c >= 203) return c + (0x93 - 203);
  else if (c >= 187) return 0x92;
  else if (c >= 175) return c + (0x8a - 203);
  else if (c >= 153) return c + (0x7b - 153);
  else if (c >= 135) return c + (0x74 - 135);
  else if (c >= 119) return c + (0x6c - 119);
  return c;
}

int
elisa_init_char
(elisa_str *str)
{
  unsigned short code;
  long offset;
  int fh = dos_open(ELISA_PATH, 0);
  if (-1 == fh) return -1;
  code = sjis2elisa(str->code);
  offset = code * 8;
  if ((offset != dos_seek(fh, 0, offset)) ||
      (8 != dos_read(fh, str->font, 8))) {
    dos_close(fh);
    return -1;
  }
  return dos_close(fh);
}

int
elisa_init_string
(elisa_str str[])
{
  int i;
  int fh = dos_open(ELISA_PATH, 0);
  if (-1 == fh) return -1;
  for (i = 0; str[i].code != 0; i++) {
    unsigned short code = sjis2elisa(str[i].code);
    long offset = code * 8;
    if ((offset != dos_seek(fh, 0, offset)) ||
	(8 != dos_read(fh, str[i].font, 8))) {
      dos_close(fh);
      return -1;
    }
  }
  return dos_close(fh);
}

int
elisa_gv_draw_char
(int x, int y, elisa_str *str, int lop)
{
  return gv_aput(x, y, 8, 8, str->font, lop);
}

int
elisa_gv_draw_string
(int x, int y, elisa_str str[], int gap, int lop)
{
  int i;
  int rc;
  for (i = 0; str[i].code != 0; i++) {
    gv_aput(x, y, 8, 8, str[i].font, lop);
    x += 8 + gap;
  }
}
