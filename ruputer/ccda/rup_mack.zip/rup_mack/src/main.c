#include <stdio.h>
#include "wbios.h"
#include "psdos.h"
#include "lcdbios.h"
#include "rupsys.h"

#include "elisa.h"

static char screen_data[13 * 64 + 4];

static void
save_screen
(void)
{
  gv_get(0, 0, 101, 63, screen_data);
}

static void
load_screen
(void)
{
  gv_put(0, 0, screen_data, 0);
}

enum {
  STR_M = 0,
  STR_A,
  STR_P,
  STR_HOUR,
  STR_MIN,
  STR_SEC,
  STR_YEAR,
  STR_MON,
  STR_DAY,
};

static elisa_str str_now[] = { {'��'}, {'��'}, {0} };
static elisa_str str_etc[] = { {'��'}, {'�O'}, {'��'}, {'��'}, {'��'}, {'�b'},
			       {'�N'}, {'��'}, {'��'}, {0} };
static elisa_str str_week[] = { {'��'}, {'��'}, {'��'}, {'��'}, {'��'}, {'��'}, {'�y'}, {0} };
static elisa_str str_mem[] = { {'��'}, {'��'}, {'��'}, {'��'}, {'��'}, {0} };
static elisa_str str_battery[] = { {'�o'}, {'�b'}, {'�e'}, {'��'}, {'��'}, {0} };
static elisa_str str_about[] = { {'��'}, {'��'}, {'��'}, {0} };

static char *grp_back = "���A���A.mmp";
static int base_x = 5;
static int base_y = 25;

static void
init_strings
(void)
{
  elisa_init_string(str_now);
  elisa_init_string(str_etc);
  elisa_init_string(str_week);
  elisa_init_string(str_mem);
  elisa_init_string(str_battery);
  elisa_init_string(str_about);
}

static int
draw_number
(int x, int y, int n, int comma)
{
  int rc = 6;
  char str[2] = { 0, 0 };
  int p;
  int first = 1;
  for (p = 1000;; p /= 10) {
    if ((0 == first) || (n >= p) || (p == 1)) {
      first = 0;
      str[0] = '0' + n / p;
      gv_kput(x, y, str, 2, 0, 1);
      if ((1000 == p) && (0 != comma)) {
	x += 6;
	rc += 6;
	gv_kput(x, y, ",", 2, 0, 1);
      } else if (1 == p) break;
      x += 6;
      rc += 6;
      n %= p;
    }
  }
  return rc;
}

static void
display_time
(void)
{
  char hour;
  char min;
  char sec;
  char hund;

  int x = base_x;
  int y = base_y;

  dos_gettime(&hour, &min, &sec, &hund);
  lcdfreeze(1);
  load_screen();

  elisa_gv_draw_string(x, y, str_now, 0, 1);
  x += 8 * 2;
  elisa_gv_draw_char(x, y, &str_etc[STR_M], 1);
  x += 8;
  if (hour < 12) elisa_gv_draw_char(x, y, &str_etc[STR_A], 1);
  else elisa_gv_draw_char(x, y, &str_etc[STR_P], 1);
  x += 8;
  hour %= 12;
  x += draw_number(x, y, hour, 0);
  elisa_gv_draw_char(x, y, &str_etc[STR_HOUR], 1);
  x += 8;

  x = base_x;
  y += 12;

  x += draw_number(x, y, min, 0);
  elisa_gv_draw_char(x, y, &str_etc[STR_MIN], 1);
  x += 8;
  x += draw_number(x, y, sec, 0);
  elisa_gv_draw_char(x, y, &str_etc[STR_SEC], 1);

  lcdfreeze(0);
}

static void
display_date
(void)
{
  char *comma = ",";
  char wday;
  char mon;
  char mday;
  int year;

  int x = base_x;
  int y = base_y;

  dos_getdate(&wday, &mon, &mday, &year);
  lcdfreeze(1);
  load_screen();

  elisa_gv_draw_string(x, y, str_now, 0, 1);
  x += 8 * 2;
  x += draw_number(x, y, year, 0);
  elisa_gv_draw_char(x, y, &str_etc[STR_YEAR], 1);

  x = base_x;
  y += 12;

  x += draw_number(x, y, mon, 0);
  elisa_gv_draw_char(x, y, &str_etc[STR_MON], 1);
  x += 8;
  x += draw_number(x, y, mday, 0);
  elisa_gv_draw_char(x, y, &str_etc[STR_DAY], 1);
  x += 8;
  gv_kput(x, y, comma, 2, 0, 1);
  x += 6;
  elisa_gv_draw_char(x, y, &str_week[wday], 1);

  lcdfreeze(0);
}

static void
display_memory
(void)
{
  int x = base_x;
  int y = base_y;

  int data[4];
  long mem;
  dos_dfspace(2, data);
  mem = (long)data[1] * (long)data[0] * (long)data[2] / 1024;
  lcdfreeze(1);
  load_screen();

  elisa_gv_draw_string(x, y, str_mem, 0, 1);
  y += 12;
  x += draw_number(x, y, mem, 1);
  gv_kput(x, y, "KB", 2, 0, 1);

  lcdfreeze(0);
}

static void
display_battery
(void)
{
  int x = base_x;
  int y = base_y;

  unsigned long pow = bi_getpower() - 32000000;
  lcdfreeze(1);
  load_screen();
  pow = pow * 100 / (160000000 - 32000000);

  elisa_gv_draw_string(x, y, str_battery, 0, 1);
  y += 12;
  x += draw_number(x, y, pow, 0);
  gv_kput(x, y, "%", 2, 0, 1);
  x += 6;
  elisa_gv_draw_string(x, y, str_about, 0, 1);

  lcdfreeze(0);
}

static void
timeout_on
(void)
{
  pSystemCtl->EventManager->eventReq |= EVENT_SEC;
}

static void
timeout_off
(void)
{
  pSystemCtl->EventManager->eventReq &= ~EVENT_SEC;
}

int
main
(void)
{
  int key;
  int mode = 0;
 
  init_strings();
  endWaiting();
  lcdon(0);
  screen(1);
  cls(4);
  gv_place(0, 0);
  timeout_on();

  gv_mmap(0, 0, grp_back, 0);
  save_screen();
  lcdon(1);

  do {
    int rc;
    switch (mode) {
    case 0:
      display_time();
      break;
    case 1:
      display_date();
      break;
    case 2:
      display_memory();
      break;
    case 3:
      display_battery();
      break;
    }
    key = Keyin(0, -1);
    if (0 != (key & (Bkey_dw | Bkey_rg))) mode++;
    else if (0 != (key & (Bkey_up | Bkey_lf))) mode--;
    if (mode < 0) mode = 3;
    if (mode > 3) mode = 0;
    rc = EventCall(key);
    if (1 == rc) {
      timeout_off();
      rc = EventExec();
      if (-1 == rc) dos_exit(rc);
      timeout_on();
    } else if (-1 == rc) {
      dos_exit(rc);
    }
  } while (0 == (key & Bkey_D));

  cls(4);
  return 0;
}
